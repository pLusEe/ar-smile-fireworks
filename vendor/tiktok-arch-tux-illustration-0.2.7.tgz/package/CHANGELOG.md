# Change Log

## 0.2.7
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6945)

## 0.2.6
### 🐛 Fixed

- fix: type error on illustration on rlynx [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5993)

## 0.2.5
### 🌟 Feature

- fix: fix id match color token issue on illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5572)

## 0.2.4
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5622)

## 0.2.3
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5340)

## 0.2.2
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5321)

## 0.2.1
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3629)

## 0.2.0
### 🌟 Feature

- feat: add illustration react version for web [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2848)

## 0.1.3
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2968)

## 0.1.2
### 🌟 Feature

- feat:update illustration [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2278)

### 🐛 Fixed

- feat:fix some illustration color issue [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2278)

## 0.1.1

### Feature
- update illustration [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165722)

## 0.1.0

### Feature

- 🌟 initial version [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/147471)
