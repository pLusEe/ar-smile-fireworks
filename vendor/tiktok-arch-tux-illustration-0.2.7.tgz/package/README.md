[][][# Overview
describe how to import and initialize

# [API references](docs/references/)

# Maintenance quick start

## dev

    "dev": "edenx dev",
    "build:watch": "edenx build -w",

## testing

    "test": "jest",
    "test:report": "gen-report pathFeatureInput=./docs/features/index.feature",
    "test:coverage": "jest --coverage",
    "test:gen-comments": "gen-comments pathTestsInput=./tests/",
    "test:gen-doc": "gen-doc pathTestsInput=./tests/",
    "test:gen-test": "gen-test pathTestInput=./tests/index.test.ts pathGherkinInput=./docs/features/index.feature",

## build

[New integration to 5.3 Build-rules with EdenX](https://bytedance.sg.larkoffice.com/docx/UsMadezm9oiW6SxyNWJloP4XgUg)

    "build": "edenx build",

## distribute

[New integration to 5.4.1 Monorepo Luban](https://bytedance.sg.larkoffice.com/docx/SixkdtutPo2GAJxq1T6lO0Wcgzf)

# ChangeLog

[CHANGELOG.md](CHANGELOG.md)

# FAQ and Contact us.
