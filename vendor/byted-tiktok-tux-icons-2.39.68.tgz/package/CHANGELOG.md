# @byted-tiktok/tux-icons

## 2.39.68
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10923)


## 2.39.67
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10587)

## 2.39.66
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9743)

## 2.39.65
### 🌟 Feature

- feat: update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9476)

## 2.39.64
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9257)


## 2.39.63
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9104)


## 2.39.62
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8857)

## 2.39.61
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8725)

## 2.39.60
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8614)

## 2.39.59
### 🌟 Feature

- feat:update icon


## 2.39.58
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8050)

## 2.39.57
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7747)


## 2.39.56
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7714)

## 2.39.55
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7529)

## 2.39.54
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6943)
- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6947)

## 2.39.53
### 🌟 Feature

- feat: update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6792)

## 2.39.52
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6620)

## 2.39.51
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6374) 
- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6516)
- feat: optimize build output, that width and height can be overwritten by input. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6426)

## 2.39.50
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6202)

## 2.39.49
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6032)

## 2.39.48
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5796)

## 2.39.47
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5718)

## 2.39.46
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5618)

## 2.39.45
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5500)

## 2.39.44
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5407)

## 2.39.43
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5318)

## 2.39.42
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5091)

## 2.39.41
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4887)

## 2.39.40
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4688)

## 2.39.39
### 🌟 Feature
- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4535)

## 2.39.38
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4265)

## 2.39.37
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4133)

## 2.39.36
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3861)

## 2.39.35
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3704)

## 2.39.34
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3576)

## 2.39.33
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3444)

## 2.39.32
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3295)

## 2.39.31
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3188)

## 2.39.30
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3061)

## 2.39.29
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2959)

## 2.39.28
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2842)
- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2798)

## 2.39.27
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2729)

## 2.39.26
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2545)
- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2629)

## 2.39.25
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2424)

## 2.39.24
### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/176015)
- feat:update icon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2278)

## 2.39.23

### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174570)

## 2.39.22

### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173513)

## 2.39.21

### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172766)
- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172894)

## 2.39.20

### 🌟 Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172646)
- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172049)
- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172143)

## 2.39.19

### Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171423)

## 2.39.18

### Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170162)

## 2.39.17

### Feature

- feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167771)

## 2.39.16

### Feature

- 🌟 feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166477)

## 2.39.15

### Feature

- 🌟 feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164961)

## 2.39.14

### Feature

- 🌟 feat:update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162313)
- 🌟 feat: update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/161615)

## 2.39.13

### Fixes

- add type declaration for testId prop [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156925)

## 2.39.12

### Feature

- 🌟 update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156237)
- 🌟 update icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156692)
- 🌟 add testId prop to TUXIcon react components [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/155158)

## 2.39.11

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/151227)

## 2.39.10

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/149413)
- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150448)

## 2.39.9

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/148301/)

## 2.39.8

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/147241)

## 2.39.7

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/143795)

## 2.39.6

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141104)
- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142876)

## 2.39.5

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/139156)
- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/140413)

## 2.39.4

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/137015)
- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/137854)

## 2.39.3

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136302)
- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136765)

## 2.39.2

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/132337)
- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134425)

## 2.39.1

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/131035)

## 2.39.0

### Feature

- 🌟 update icons [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/128937)

## 2.38.0

### Minor Changes

- 6f3d871e043e: 🌟 update icons
- 03262f527f4f: 🌟 update icons
- 597950124806: 🌟 update icons
- 501680a6387d: 🌟 update icons
- 62a3fb3b433d: 🌟 update icons
- 7033dce954db: 🌟 update icons
- 2fb535e3cf09: 🌟 update icons
- 8d1749e68515: 🌟 update icons
- 67507f6c81e2: 🌟 update icons

## 2.37.0

### Minor Changes

- 56b4ae6d9f05: 🌟 update icons
- 9e3b7d633834: 🌟 update icons
- 7e55577e70c2: 🌟 update icons
- a954775b6d40: 🌟 update icons
- 5d1428a12487: 🌟 update icons

## 2.36.0

### Minor Changes

- 9cb5673d8e82: 🌟 update icons
- 75dd3ecbd5c3: 🌟 update icons
- a326336db7c5: 🌟 update icons
- 66ce2bb3d1f9: 🌟 update icons

## 2.35.0

### Minor Changes

- ce6adc10a86: 🌟 update icons
- 41c0d272866: 🌟 update icons
- 6197eb78d3b: 🌟 update icons
- 1380235c6a2: 🌟 update icons
- 4a71d448c9e: 🌟 update icons

## 2.34.0

### Minor Changes

- d89327d0594: 🌟 update icons

## 2.33.0

### Minor Changes

- 014e557d069: 🌟 update icons

## 2.32.0

### Minor Changes

- 0170cd2d711: 🌟 update icons
- 624f1262abc: 🌟 update icons
- 15d87e3c467: 🌟 update icons
- d29e37be3b1: 🌟 update icons

## 2.31.0

### Minor Changes

- 188934e8012: 🌟 update icons

## 2.30.0

### Minor Changes

- f5bb4db9f94: 🌟 update icons

## 2.29.0

### Minor Changes

- f3835ff8476: 🌟 update icons
- de2254d24d7: 🌟 update icons

## 2.28.0

### Minor Changes

- 27bb1bc4b34: 🌟 update icons
- de077a58b43: 🌟 update icons
- caa65707a55: 🌟 update icons

## 2.27.0

### Minor Changes

- d0857a4c657: 🌟 update icons
- ed72dde92ef: 🌟 update icons
- f755dc497a7: 🌟 update icons

## 2.26.0

### Minor Changes

- eb1f5d9de63: 🌟 update icons
- 4f11bddfc88: 🌟 update icons

## 2.25.0

### Minor Changes

- 1710f6442d5: 🌟 update icons
- c904816b34e: 🌟 update icons

## 2.24.0

### Minor Changes

- e84ae936468: 🌟 update icons

## 2.23.0

### Minor Changes

- b6a63f9a0df: 🌟 update icons

## 2.22.0

### Minor Changes

- 15cfe5abec6: 🌟 update icons

## 2.21.0

### Minor Changes

- 98f8073cd11: 🌟 update icons

## 2.20.0

### Minor Changes

- b7d0a914085: 🌟 update icons
- a836ad9068f: 🌟 update icons
- afb28bcff99: 🌟 update icons

## 2.19.0

### Minor Changes

- 3decfdd2a40: 🌟 update icons

### Patch Changes

- 6718028f220: 💥 This release fixes an issue where the content of `IconChevronRightOffsetSmallLTR` was mistaken to be the same as `IconChevronRightOffsetLTR`. If you find something unexpected where `IconChevronRightOffsetSmallLTR` is used, please change to `IconChevronRightOffsetLTR` instead.

## 2.18.0

### Minor Changes

- 0c756f77c26: 🌟 update icons

## 2.17.0

### Minor Changes

- 0fc8d8727d7: 🌟 update icons

## 2.16.0

### Minor Changes

- 8dc785e1af3: 🌟 update icons
- db64ae576c2: 🌟 update icons

## 2.15.0

### Minor Changes

- 2a516ac9fff: 🌟 update icons
- 4ad24ea1ebe: 🌟 update icons
- 6ccc94fcae4: 🌟 update icons
- 5709a3ee973: 🌟 update icons

## 2.14.0

### Minor Changes

- 7b166045fe6: 🌟 update icons
- 717d9f99752: 🌟 update icons

## 2.13.0

### Minor Changes

- 53ba91d81d9: 🌟 update icons

## 2.12.0

### Minor Changes

- 9942c79e25f: 🌟 update icons

## 2.11.0

### Minor Changes

- 9462f285c53: 🌟 update icons
- fc1943deb2f: 🌟 update icons

## 2.10.0

### Minor Changes

- 765cc30f89c: 🌟 update icons

## 2.9.0

### Minor Changes

- 7494f140899: 🌟 update icons

## 2.8.0

### Minor Changes

- b85a84b8d09: 🌟 update icons
- acc81b7d205: 🌟 update icons
- a372ef9e091: 🌟 update icons

## 2.7.0

### Minor Changes

- eddaf3b8b1e: 🌟 update icons
- d5c2d6d7db7: 🌟 update icons

## 2.6.0

### Minor Changes

- 9672a2224d8: 🌟 update icons
- 553ec8856b9: 🌟 update icons

## 2.5.0

### Minor Changes

- 3f5aa7eb985: 🌟 update icons

## 2.4.0

### Minor Changes

- 86216169b52: 🌟 update icons

## 2.3.0

### Minor Changes

- 9aab53ccffe: 🌟 update icons
- 8fd1a89af2a: 🌟 update icons

## 2.2.0

### Minor Changes

- d5c6bab9813: 🌟 update icons

## 2.1.0

### Minor Changes

- afeb37bbdf8: 🌟 update icons
- 3bf0f72d186: 🌟 update icons

## 2.0.0

### Major Changes

- 7640e5b2a50: 💥 Update icons and change Folderarrowdown to FolderArrowDown

### Minor Changes

- 0500adb6225: 🌟 update icons

## 1.8.2

### Patch Changes

- f8939c0e0b4: 🌟 update icons

## 1.8.1

### Patch Changes

- 8f55db7c95f: 🌟 update icons
- 7705f59457b: 🌟 Update icons and change Calendarstar to CalendarStar

## 1.8.0

### Minor Changes

- aee8f797ec9: 🌟 update icons

## 1.7.0

### Minor Changes

- 31b2d54a432: 🌟 update icons
- aa65efdfbf6: 🌟 update icons

## 1.6.0

### Minor Changes

- 6e0ba64f30d: 🌟 Add new icons:
  - Icon/Arrows_To_Center.svg
  - Icon/Bubble_Curve_Right.svg
  - Icon/Bubble_Lines_Filled.svg
  - Icon/Ellipsis_Single.svg
  - Icon/Hand_Nudge.svg
  - Icon/Head_Star.svg
  - Icon/LIVE_Academy.svg
  - Icon/Light_Bulb_Play.svg
  - Icon/List_Music_Note.svg
  - Icon/Message_Request_v2_Filled.svg
  - Icon/Message_Request_v2_Outline.svg
  - Icon/Message_Request_v3_Filled.svg
  - Icon/Message_Request_v3_Outline.svg
  - Icon/Meter_0_3_Fill.svg
  - Icon/Meter_0_5_Fill.svg
  - Icon/Paperplane_Circle_Fill.svg
  - Icon/Person_Double_Star_Filled.svg
  - Icon/Phone_Book_Fill.svg
  - Icon/Series_Dollar.svg
  - Icon/Series_Euro.svg
  - Icon/Smart_Video.svg
  - Icon/Sticker_Round_Filled.svg
  - Icon_2pt/Closed_Caption.svg
  - Icon_2pt/Closed_Caption_Fill.svg
  - Icon_2pt/Info_Circle.svg
  - Icon_2pt/Series_Dollar.svg
  - Icon_2pt/Series_Euro.svg
  - Icon_3pt/Bubble_Curve_Right.svg
  - Icon_3pt/Heart_Filled.svg
  - Icon_Anchor/Series_Dollar.svg
  - Icon_Anchor/Series_Euro.svg
  - Icon_Anchor/TTS.svg
  - Icon_Color/Clock_Gray.svg
  - Icon_Color/Comment_Off_Shadow.svg
  - Icon_Color/DM_Icon_Experiment_V1.svg
  - Icon_Color/DM_Icon_Experiment_V10.svg
  - Icon_Color/DM_Icon_Experiment_V11.svg
  - Icon_Color/DM_Icon_Experiment_V2.svg
  - Icon_Color/DM_Icon_Experiment_V3.svg
  - Icon_Color/DM_Icon_Experiment_V6.svg
  - Icon_Color/DM_Icon_Experiment_V7.svg
  - Icon_Color/DM_Icon_Experiment_V8.svg
  - Icon_Color/DM_Icon_Experiment_V9.svg
  - Icon_Color/Like_Red_Shadow_2.svg
  - Icon_Color/Like_Shadow_2.svg
  - Icon_Color/Repost.svg
  - Icon_Color/Story_Circle.svg
  - Icon_Color/Tick_Circle_Green.svg
  - Icon_Color/Warning_Red.svg
  - Icon_Large/Hand_Nudge.svg
  - Icon_Large/Tasks.svg
  - Icon_Tab/Shop.svg
  - Icon_Tab/Shop_Fill.svg
- cb007bccc9b: - 🌟Add new icons:
  - svg/Icon/Arrow_Left_Right_1.svg
  - svg/Icon/Book_Ribbon.svg
  - svg/Icon/Chevron_Collapse.svg
  - svg/Icon/Chevron_Expand.svg
  - svg/Icon/Facebook_Circle.svg
  - svg/Icon/Video_1_Fill.svg
  - svg/Icon_Color/Bookmark_Shadow.svg
  - svg/Icon_Color/Bookmark_Yellow_Shadow.svg
  - svg/Icon_Color/Tick_Circle.svg

## 1.5.0

### Minor Changes

- 8db9bc773b:
  - 🌟 Add new icons:
    - svg/Icon/Arrow_Circle_Fill.svg
    - svg/Icon/Arrow_Counter_Clockwise.svg
    - svg/Icon/Arrow_Turn_Left.svg
    - svg/Icon/Arrow_Turn_Right.svg
    - svg/Icon/Arrow_Turn_Right_Rectangle.svg
    - svg/Icon/Arrow_Up_Left_And_Arrow_Down_Right.svg
    - svg/Icon/Beauty_Fill.svg
    - svg/Icon/Camera_Clockwise_Fill.svg
    - svg/Icon/Chevron_In_Rec_Fill.svg
    - svg/Icon/Control_fill.svg
    - svg/Icon/Counter_10s_Fill.svg
    - svg/Icon/Counter_3s_Fill.svg
    - svg/Icon/Doc_On_Doc_Fill.svg
    - svg/Icon/Effects_Fill.svg
    - svg/Icon/Emoji_Plus.svg
    - svg/Icon/EnhancePhoto_Fill.svg
    - svg/Icon/Filter_Fill.svg
    - svg/Icon/Fire_3.svg
    - svg/Icon/Fire_3_Fill.svg
    - svg/Icon/Flash_Auto_Fill.svg
    - svg/Icon/Flash_Fill.svg
    - svg/Icon/Flash_Slash_Fill.svg
    - svg/Icon/Human_Soundwave_Fill.svg
    - svg/Icon/Image.svg
    - svg/Icon/Layout_Above_Fill.svg
    - svg/Icon/Layout_Horizontal_Fill.svg
    - svg/Icon/Layout_Vertical_2_Fill.svg
    - svg/Icon/Layout_Vertical_3_Fill.svg
    - svg/Icon/Meter_1_Fill.svg
    - svg/Icon/Meter_2_Fill.svg
    - svg/Icon/Meter_3_Fill.svg
    - svg/Icon/Microphone_Fill.svg
    - svg/Icon/Microphone_Slash_Fill.svg
    - svg/Icon/Music_Note_Fill_Scissors.svg
    - svg/Icon/Music_Note_S.svg
    - svg/Icon/Play_Circle_Fill.svg
    - svg/Icon/Plus_In_Rec_Fill.svg
    - svg/Icon/Q&A_1_Fill.svg
    - svg/Icon/Quadrilateral_Fill.svg
    - svg/Icon/Rec_In_Rec_Fill.svg
    - svg/Icon/Shield_Exclamation.svg
    - svg/Icon/Shield_Exclamation_Filled.svg
    - svg/Icon/Sound_Plus.svg
    - svg/Icon/Speed_Meter_Fill.svg
    - svg/Icon/Split_Fill.svg
    - svg/Icon/Split_Half_Fill.svg
    - svg/Icon/Sticker_Fill.svg
    - svg/Icon/Store_Gear.svg
    - svg/Icon/Text_Latin.svg
    - svg/Icon/Text_Plus.svg
    - svg/Icon/Text_To_Speech.svg
    - svg/Icon/Trash_Bin_Filled.svg
    - svg/Icon/Two_Person_1_Fill.svg
    - svg/Icon/Two_Person_Large_Fill.svg
    - svg/Icon/Unblock.svg
    - svg/Icon/Video_Split_Fill.svg
    - svg/Icon/Voice_Effects_Fill.svg
    - svg/Icon/Watch_history.svg
    - svg/Icon/Waveform.svg
    - svg/Icon_2pt/Film_Star.svg
    - svg/Icon_3pt/Bookmark_Eye_Slash.svg
    - svg/Icon_3pt/Person_Arrow_Left_Right.svg
    - svg/Icon_3pt/Two_Person.svg
    - svg/Icon_3pt/Video_Play.svg
    - svg/Icon_3pt/Watch_history.svg
    - svg/Icon_Color/Discord_Circle.svg
    - svg/Icon_Large/Watch_History.svg
  - 🐛 Fix existing icons:
    - svg/Icon_Tab/LIVE_Fill.svg

## 1.4.0

### Minor Changes

- 74ed41e5bf: 🌟 Add new icons:
  - Icon/Letter.svg

## 1.3.0

### Minor Changes

- 9e8363e453: 🌟 Add new icons:

  - Icon/Camera_Fill.svg
  - Icon/Music_Note_Fill.svg
  - Icon_Color/Comment_Circle.svg
  - Icon_Color/Like_Circle_Inbox.svg
  - Icon_Color/Music_Tab.svg
  - Icon_Color/Paperplane_Circle.svg
  - Icon_Color/Two_Person_Circle.svg
  - Icon_Large/Person_Eye.svg

  🐛 Fix existing icons:

  - Icon/Spinner_Thin.svg

## 1.2.0

### Minor Changes

- 051109e4d1: 🌟 Add new icons:
  - Icon/Arrow_Up_Right_LTR.svg
  - Icon/Chevron_Up_Double_Fill.svg
  - Icon/Closed_Caption_Fill.svg
  - Icon/Library_Fill.svg
  - Icon/Magnifying_Glass_Fill.svg
  - Icon/Music_DSP1.svg
  - Icon/Music_DSP2.svg
  - Icon/Note_On_Video.svg
  - Icon/Shuffle.svg
  - Icon/Tick_On_Doc.svg
  - Icon_2pt/Advertisement.svg
  - Icon_2pt/Arrow_Clockwise.svg
  - Icon_2pt/Arrow_Down_HD.svg
  - Icon_3pt/Heart_Grid.svg
  - Icon_3pt/Library.svg
  - Icon_Anchor/Library.svg
  - Icon_Anchor/Music.svg
  - Icon_Color/Default_Avatar_Square.svg
  - Icon_Color/Queue.svg
  - Icon_Tab/Discover.svg
  - Icon_Tab/Discover_Fill.svg
    🌟 Update existing icons:
  - Icon/Gift.svg

## 1.1.0

### Minor Changes

- 88e49a9959: 🌟Add more icons

## 1.0.0

### Minor Changes

- 🌟Add the following icons:
  - A_Rectangle_On_Rectangle.svg
  - Arrow_Clockwise.svg
  - Arrow_To_Down_Fill.svg
  - Arrow_Turn_Up_Right_Fill.svg
  - Brush_And_Tube.svg
  - Chevron_Down_Double.svg
  - Chevron_Down_Double_Fill.svg
  - Chevron_Up_Fill.svg
  - Clock_Fill.svg
  - Comb.svg
  - Compass.svg
  - Disco_Ball.svg
  - Document_Umbrella.svg
  - Facebook.svg
  - Film.svg
  - Flag_Star.svg
  - Game_Controller.svg
  - Globe_Tick.svg
  - Heart_Small_Fill.svg
  - House_Building.svg
  - House_Play.svg
  - Instagram_Story.svg
  - Kakaotalk.svg
  - Line.svg
  - Medal.svg
  - Messages.svg
  - Messenger.svg
  - Paw.svg
  - Person_Pulse.svg
  - Person_Unlock.svg
  - Person_X_Mark.svg
  - Pizza.svg
  - Play_Circle.svg
  - Plus_Person.svg
  - Q&A_Fill_LTR.svg
  - Q&A_LTR.svg
  - Raising_Star.svg
  - Raising_Star_Fill.svg
  - Raising_Star_Slash.svg
  - Repost.svg
  - Repost_Tick.svg
  - Scissors.svg
  - Shoe.svg
  - Smile_Face.svg
  - Snapchat.svg
  - Star_Ring.svg
  - Thumbs_Down.svg
  - Twitter.svg
  - VK.svg
  - Video_Play.svg
  - Whatsapp.svg
  - Zalo.svg
  - Paperplane.svg
  - Person_Plus.svg
  - Plus_Person.svg
  - Q&A_LTR.svg
  - Flag_Star.svg
  - Lock_Keyhole.svg
  - Band_Circle.svg
  - Creator_Next.svg
  - EOY2021_Reply_LTR.svg
  - Fire.svg
  - Imgur_Circle.svg
  - LinkedIn_Circle.svg
  - Messenger_Lite_Circle.svg
  - NaverBlog_Circle.svg
  - NaverCafe_Circle.svg
  - Q&A_Fill_LTR.svg
  - QR_Code_Circle.svg
  - Shareplay_Circle.svg
  - TikTok_Dark_Square.svg
  - Zalo_Circle.svg
  - Contacts.svg

# [1.0.0-beta.10](https://code.byted.org/ies/tiktok_web_monorepo/compare/@byted-tiktok/tux-icons@1.0.0-beta.9...@byted-tiktok/tux-icons@1.0.0-beta.10) (2021-01-26)

### Features

- **tux:** sync figma icons ([0a71e77](https://code.byted.org/ies/tiktok_web_monorepo/commits/0a71e779e568af7f93896811b3b94a4fb005b6e7))

# [1.0.0-beta.9](https://code.byted.org/ies/tiktok_web_monorepo/compare/@byted-tiktok/tux-icons@1.0.0-beta.8...@byted-tiktok/tux-icons@1.0.0-beta.9) (2021-01-19)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# 1.0.0-beta.8 (2021-01-14)

### Features

- add eden pipeline. fix yarn lint ([21e62e6](https://code.byted.org/ies/tiktok_web_monorepo/commits/21e62e62de2a8d7d391e67b99a72d586d45a874c))
- consolidate dependencies. update scripts ([9dc2ac8](https://code.byted.org/ies/tiktok_web_monorepo/commits/9dc2ac8a97dd56a79534761e0d342909e35d040c))

# 1.0.0-beta.7 (2021-01-12)

### Features

- add eden pipeline. fix yarn lint ([21e62e6](https://code.byted.org/ies/tiktok_web_monorepo/commits/21e62e62de2a8d7d391e67b99a72d586d45a874c))
- consolidate dependencies. update scripts ([9dc2ac8](https://code.byted.org/ies/tiktok_web_monorepo/commits/9dc2ac8a97dd56a79534761e0d342909e35d040c))

# [1.0.0-beta.4](https://code.byted.org/ies/tux/compare/v1.0.0-beta.3...v1.0.0-beta.4) (2021-01-07)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [1.0.0-beta.3](https://code.byted.org/ies/tux/compare/v1.0.0-beta.2...v1.0.0-beta.3) (2021-01-06)

### Features

- add icon gallery ([657aa85](https://code.byted.org/ies/tux/commits/657aa853e38dd8515757666830b2f4ac4472db19))
- update toast and icon doc ([c3fa2fd](https://code.byted.org/ies/tux/commits/c3fa2fdf0c63f65985e6c8a774c41e455a74a0a1))

# [1.0.0-beta.0](https://code.byted.org/ies/tux/compare/v0.18.5...v1.0.0-beta.0) (2020-12-22)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.18.0](https://code.byted.org/ies/tux/compare/v0.17.0...v0.18.0) (2020-12-03)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.17.0](https://code.byted.org/ies/tux/compare/v0.16.0...v0.17.0) (2020-11-30)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.16.0](https://code.byted.org/ies/tux/compare/v0.15.1...v0.16.0) (2020-11-27)

**Note:** Version bump only for package @byted-tiktok/tux-icons

## [0.15.1](https://code.byted.org/ies/tux/compare/v0.15.0...v0.15.1) (2020-11-26)

### Bug Fixes

- bag icon ([09b9034](https://code.byted.org/ies/tux/commits/09b9034029f22222e39b69a76209e72c0c19c6a2))

# [0.15.0](https://code.byted.org/ies/tux/compare/v0.14.0...v0.15.0) (2020-11-25)

### Bug Fixes

- **tux-icons:** unique ids ([53535d5](https://code.byted.org/ies/tux/commits/53535d5784c111dad1f9537ce14124b65468a1a8))

### Features

- **tux-icons:** add large icon ([2a388ee](https://code.byted.org/ies/tux/commits/2a388ee69f7b2e59d0a878db2f467c40962b645a))

# [0.14.0](https://code.byted.org/ies/tux/compare/v0.13.0...v0.14.0) (2020-11-24)

### Features

- **tux-icons:** add cjs export ([c261283](https://code.byted.org/ies/tux/commits/c261283d4079aaa9b33299b4ce1dec8c1e0f2b2e))

# [0.14.0-alpha.1](https://code.byted.org/ies/tux/compare/v0.14.0-alpha.0...v0.14.0-alpha.1) (2020-11-24)

### Bug Fixes

- **tux-icons:** point mainFeild to cjs ([486d480](https://code.byted.org/ies/tux/commits/486d4808e96b499e9a60a176962bda93a16e2703))

# [0.14.0-alpha.0](https://code.byted.org/ies/tux/compare/v0.13.0...v0.14.0-alpha.0) (2020-11-24)

### Features

- **tux-icons:** output cjs format ([931314b](https://code.byted.org/ies/tux/commits/931314b80b637d80484bc1e3945b4e091245fbab))

# [0.13.0](https://code.byted.org/ies/tux/compare/v0.12.0...v0.13.0) (2020-11-24)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.12.0](https://code.byted.org/ies/tux/compare/v0.11.1...v0.12.0) (2020-11-23)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.11.0](https://code.byted.org/ies/tux/compare/v0.10.3...v0.11.0) (2020-11-22)

**Note:** Version bump only for package @byted-tiktok/tux-icons

## [0.10.3](https://code.byted.org/ies/tux/compare/v0.10.2...v0.10.3) (2020-11-20)

### Bug Fixes

- icon rtl ([adfd4f1](https://code.byted.org/ies/tux/commits/adfd4f1b29ae15022bd9dfd629b15f2a7ee5a548))

## [0.10.2](https://code.byted.org/ies/tux/compare/v0.10.1...v0.10.2) (2020-11-20)

### Bug Fixes

- rtl icon ([8da5cf4](https://code.byted.org/ies/tux/commits/8da5cf4d6d4dded2eda02c2e4cefdbf092e665cf))

## [0.10.1](https://code.byted.org/ies/tux/compare/v0.10.0...v0.10.1) (2020-11-18)

### Bug Fixes

- icon className ([0ad428c](https://code.byted.org/ies/tux/commits/0ad428c10fbb76bda00b3e857bd5e09fb3ca66da))

# [0.10.0](https://code.byted.org/ies/tux/compare/v0.9.1...v0.10.0) (2020-11-18)

**Note:** Version bump only for package @byted-tiktok/tux-icons

## [0.9.1](https://code.byted.org/ies/tux/compare/v0.9.0...v0.9.1) (2020-11-18)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.9.0](https://code.byted.org/ies/tux/compare/v0.8.2...v0.9.0) (2020-11-18)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.8.0](https://code.byted.org/ies/tux/compare/v0.7.0...v0.8.0) (2020-11-17)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.7.0](https://code.byted.org/ies/tux/compare/v0.6.0...v0.7.0) (2020-11-13)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.6.0](https://code.byted.org/ies/tux/compare/v0.5.2...v0.6.0) (2020-11-12)

**Note:** Version bump only for package @byted-tiktok/tux-icons

## [0.5.2](https://code.byted.org/ies/tux/compare/v0.5.1...v0.5.2) (2020-11-09)

### Bug Fixes

- **tux-icons:** rtl icon ([08af3bb](https://code.byted.org/ies/tux/commits/08af3bb42eec70ed86d6361d6222e2a48b64b4d2))

# [0.5.0](https://code.byted.org/ies/tux/compare/v0.4.1...v0.5.0) (2020-11-09)

**Note:** Version bump only for package @byted-tiktok/tux-icons

## [0.4.1](https://code.byted.org/ies/tux/compare/v0.4.1-alpha.0...v0.4.1) (2020-11-06)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.4.0](https://code.byted.org/ies/tux/compare/v0.3.0...v0.4.0) (2020-11-06)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.3.0](https://code.byted.org/ies/tux/compare/v0.2.0...v0.3.0) (2020-11-05)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# [0.2.0](https://code.byted.org/ies/tux/compare/v0.1.1...v0.2.0) (2020-11-05)

**Note:** Version bump only for package @byted-tiktok/tux-icons

## [0.1.1](https://code.byted.org/ies/tux/compare/v0.1.0...v0.1.1) (2020-11-04)

**Note:** Version bump only for package @byted-tiktok/tux-icons

# 0.1.0 (2020-11-04)

### Features

- initial commit ([2b1d08d](https://code.byted.org/ies/tux/commits/2b1d08de2f6dad695de9b22237a5a3b677b980be))
