# @byted-tiktok/tux-color

## 1.3.9
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10921)

## 1.3.8
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10516)

## 1.3.7
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10097)


## 1.3.6
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9256)

## 1.3.5
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8455)

## 1.3.4
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8202)

## 1.3.3
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7778)


## 1.3.2
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7679)

## 1.3.1
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7588)

## 1.3.0
### 🌟 Feature

- feat: add high contrast color maintainence and export [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7187)

## 1.2.26
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6941)

## 1.2.25
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6765)

## 1.2.24
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6401)

## 1.2.23
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5766)

## 1.2.22
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5736)

## 1.2.21
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5452)

## 1.2.20
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5128)

## 1.2.19
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5065)

## 1.2.18
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4653)

## 1.2.17
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4260)

## 1.2.16
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3573)

## 1.2.15
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3446)

## 1.2.14
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3343)

## 1.2.13
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3186)

## 1.2.12
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3025)

## 1.2.11
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2857)
- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2958)

## 1.2.10
### 🌟 Feature

feat: split colors to colors-v1, colors-v2, colors, add colors-rgba module [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2628)

## 1.2.9
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/2522)

## 1.2.8
### 🌟 Feature

- feat:update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/176014)
- feat:update color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2271)

## 1.2.7

### Feature

- feat:update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171642)

## 1.2.6

### Feature

- feat:update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170728)

## 1.2.5

### Feature

- feat:update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/169262)

## 1.2.4

### Feature

- feat:update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164672)

## 1.2.3

### Feature

- update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156748)

## 1.2.2

### Feature

- 🌟 update color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/155883)

## 1.2.1

### Feature

- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153512)
- 🌟 Support split color version type [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153512)

## 1.1.23

### Feature

- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150734)

## 1.1.22

### Feature

- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142116)
- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142284)

## 1.1.21

### Feature

- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138064)

## 1.1.20

### Feature

- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/133940)

## 1.1.19

### Feature

- 🌟 Update colors [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/131612)

## 1.1.18

### Patch Changes

- c63499cfd515: 🌟 Update colors
- 4048bfff8ebd: 🌟 Update colors
- bf7de84a3392: 🌟 Update colors
- 71bb74639878: 🌟 Update colors

## 1.1.17

### Patch Changes

- a11f229add9f: 🌟 Update colors

## 1.1.16

### Patch Changes

- 0bad6f122dcf: 🌟 Update colors
- dc671d1b6204: 🌟 Update colors
- a736d8c0f449: 🌟 Update colors
- a736d8c0f449: 🔨 change `UIShapeSecondary2` ~ `UIShapeSecondary5` color value

## 1.1.15

### Patch Changes

- 3b62cf7b2371: 🌟 Update colors
- 5ae1862f7c03: 🌟 Update colors

## 1.1.14

### Patch Changes

- d1b056f9fb2: 🌟 Update colors
- d1b056f9fb2: 🔨 change color BrandTikTokPhotos1 value #FF702CFF to #FF00C68C
- 98a8ebc01f7: 🌟 Update colors

## 1.1.13

### Patch Changes

- 8c15df542b2: 🌟 Update colors
- cb63a7076ab: 🌟 Update colors
- ebb555bff1d: 🌟 Update colors

## 1.1.12

### Patch Changes

- 4d3bff8ebb9: 🌟 Update colors
- 91e58992199: 🌟 Update colors

## 1.1.11

### Patch Changes

- e6605f2b6d4: 🌟 Update colors

## 1.1.10

### Patch Changes

- 10232e88753: 🐛 fix theme invert color value issue

## 1.1.9

### Patch Changes

- 0b396fdc5752: 🌟 Update colors
- 9476ab84bf86: 🌟 Update colors

## 1.1.8

### Patch Changes

- 8b5094e3256: 🌟 Support Color 2.0

## 1.1.7

### Patch Changes

- 8de2aad98d8: 🌟 Update colors

## 1.1.6

### Patch Changes

- 3494bb8cfe8: 🌟 Update colors
- 5fecd93bf98: 🔨 default support es5

## 1.1.5

### Patch Changes

- 95677904abd: 🌟 Update colors

## 1.1.4

### Patch Changes

- e6c753b5424: 🌟 Update colors

## 1.1.3

### Patch Changes

- 6c6f085aa12: 🌟 Update colors
- b69765d7a73: 🌟 Update colors

## 1.1.2

### Patch Changes

- adb42cbce14: 🌟 Update colors

## 1.1.1

### Patch Changes

- 3a200b03708: 🌟 Update colors
- 50ddef093e1: 🌟 Update colors
- 122038cf2e5: 🌟 Update colors
- 769bd12d77e: 🌟 Update colors

## 1.1.0

### Minor Changes

- 5332a5aa84: 🌟 Add `hasColor` to check if a color name has matching values.

### Patch Changes

- 80ad86d413: 🌟 Update colors

## 1.0.3

### Patch Changes

- d5fcdc62e7: 🌟 Update colors
- 🌟 Add lite version of colors.

## 1.0.2

### Patch Changes

- 1b35f1b959: 🐛 Fix ConstBGMat value

## 1.0.1

### Patch Changes

- 0a16685294: 🌟 Update colors
- 917d644673: 🌟 Update colors:
  - ConstBGSecondary
- a52c4e3c88: 🐛 Fix type name typo: `colorName` -> `ColorName`

## 1.0.0

### Major Changes

- Better build output
  - 💥Stop providing `colors.json`
  - 🌟Export colors in js file containing the following values:
    - hex without alpha
    - hex with alpha
    - alpha
    - rgba
  - 🌟Export a util function to help get the above color values

# [1.0.0-beta.10](https://code.byted.org/ies/tiktok_web_monorepo/compare/@byted-tiktok/tux-color@1.0.0-beta.9...@byted-tiktok/tux-color@1.0.0-beta.10) (2021-01-26)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [1.0.0-beta.9](https://code.byted.org/ies/tiktok_web_monorepo/compare/@byted-tiktok/tux-color@1.0.0-beta.8...@byted-tiktok/tux-color@1.0.0-beta.9) (2021-01-19)

**Note:** Version bump only for package @byted-tiktok/tux-color

# 1.0.0-beta.8 (2021-01-14)

### Features

- add eden pipeline. fix yarn lint ([21e62e6](https://code.byted.org/ies/tiktok_web_monorepo/commits/21e62e62de2a8d7d391e67b99a72d586d45a874c))

# 1.0.0-beta.7 (2021-01-12)

### Features

- add eden pipeline. fix yarn lint ([21e62e6](https://code.byted.org/ies/tiktok_web_monorepo/commits/21e62e62de2a8d7d391e67b99a72d586d45a874c))

# [1.0.0-beta.4](https://code.byted.org/ies/tux/compare/v1.0.0-beta.3...v1.0.0-beta.4) (2021-01-07)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [1.0.0-beta.0](https://code.byted.org/ies/tux/compare/v0.18.5...v1.0.0-beta.0) (2020-12-22)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.18.0](https://code.byted.org/ies/tux/compare/v0.17.0...v0.18.0) (2020-12-03)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.17.0](https://code.byted.org/ies/tux/compare/v0.16.0...v0.17.0) (2020-11-30)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.16.0](https://code.byted.org/ies/tux/compare/v0.15.1...v0.16.0) (2020-11-27)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.15.0](https://code.byted.org/ies/tux/compare/v0.14.0...v0.15.0) (2020-11-25)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.13.0](https://code.byted.org/ies/tux/compare/v0.12.0...v0.13.0) (2020-11-24)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.12.0](https://code.byted.org/ies/tux/compare/v0.11.1...v0.12.0) (2020-11-23)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.11.0](https://code.byted.org/ies/tux/compare/v0.10.3...v0.11.0) (2020-11-22)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.10.0](https://code.byted.org/ies/tux/compare/v0.9.1...v0.10.0) (2020-11-18)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.9.0](https://code.byted.org/ies/tux/compare/v0.8.2...v0.9.0) (2020-11-18)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.8.0](https://code.byted.org/ies/tux/compare/v0.7.0...v0.8.0) (2020-11-17)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.7.0](https://code.byted.org/ies/tux/compare/v0.6.0...v0.7.0) (2020-11-13)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.6.0](https://code.byted.org/ies/tux/compare/v0.5.2...v0.6.0) (2020-11-12)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.5.0](https://code.byted.org/ies/tux/compare/v0.4.1...v0.5.0) (2020-11-09)

**Note:** Version bump only for package @byted-tiktok/tux-color

## [0.4.1](https://code.byted.org/ies/tux/compare/v0.4.1-alpha.0...v0.4.1) (2020-11-06)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.4.0](https://code.byted.org/ies/tux/compare/v0.3.0...v0.4.0) (2020-11-06)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.3.0](https://code.byted.org/ies/tux/compare/v0.2.0...v0.3.0) (2020-11-05)

**Note:** Version bump only for package @byted-tiktok/tux-color

# [0.2.0](https://code.byted.org/ies/tux/compare/v0.1.1...v0.2.0) (2020-11-05)

**Note:** Version bump only for package @byted-tiktok/tux-color

## [0.1.1](https://code.byted.org/ies/tux/compare/v0.1.0...v0.1.1) (2020-11-04)

**Note:** Version bump only for package @byted-tiktok/tux-color

# 0.1.0 (2020-11-04)

### Features

- initial commit ([2b1d08d](https://code.byted.org/ies/tux/commits/2b1d08de2f6dad695de9b22237a5a3b677b980be))
