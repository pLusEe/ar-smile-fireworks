<!-- tux-web · guides/overview -->
> **TUX guide — overview** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/overview)

# Overview

TUX is short for *TikTok UX* — a family of front-end UI component libraries widely used across the TikTok ecosystem. The design team defines the TUX design system on top of the TikTok brand; product designers extend it; the TUX libraries ship components that fully implement the spec so engineers can build product surfaces against a single source of truth.

This page lists the currently maintained **TUX Web** packages. For Lynx packages, see the [Lynx overview](/lynx/docs/overview). For iOS and Android, see the [legacy TUX website](https://tux-website.fn.bytedance.net/).

## Web packages

### UI components

| Package | Summary | Status | Docs | Source |
| --- | --- | --- | --- | --- |
| `@byted-tiktok/tux-web` | TUX Web v1. The current TUX Web component library, fully aligned with TUX Design 2.0 responsive design. Covers nearly all legacy components. | LTS | [docs](/v1/docs/quick-start) | [source](https://code.byted.org/tiktok/arch_web_monorepo/tree/master/subspaces/tux/tux-web/src) |
| `@byted-tiktok/tux-web/deprecated` | TUX Web v0. Merged tux-h5 and tux-pc into a single component library. No longer maintained. | Deprecated | [docs](https://tux.bytedance.net/v0/docs/getting-started) | [source](https://code.byted.org/ies/tiktok_web_monorepo/tree/master/packages/libs/tux-web/src/components) |

### Ecosystem libraries

| Package | Summary | Status | Docs | Source |
| --- | --- | --- | --- | --- |
| `@byted-tiktok/tux-color` | Runtime color helper. Sourced from the design platform; covers TUX Design 1.0 and 2.0 tokens plus selected business colors. Used by Lynx too. Direct import is not recommended — prefer the component library. | LTS | [docs](/v1/docs/colors) | [source](https://code.byted.org/tiktok/arch_web_monorepo/tree/master/subspaces/tux/tux-h5-color) |
| `@byted-tiktok/tux-icons` | Icon SVGs and React components. Sourced from the design platform. Recommended import path for all icons — do not import from individual product packages. | LTS | [docs](/v1/docs/icons) | [source](https://code.byted.org/tiktok/arch_web_monorepo/tree/master/subspaces/tux/tux-h5-icons) |
| `@tiktok-arch/tux-illustration` | Illustration assets sourced from the design platform. | LTS | [docs](/v1/docs/illustrations) | [source](https://code.byted.org/tiktok/arch_web_monorepo/tree/master/subspaces/tux/tux-illustration) |

## Information channels

> For the latest official announcements, join the **TikTok Web Arch User Group** in Lark. Older TUX-only announcement groups have been merged into it (effective 2025-04-30).

### Reference docs

- [Static Resources (Web)](/v1/docs/static-resources) / [Static Resources (Lynx)](/lynx/docs/static-resources) — fonts, icons, illustrations, color packages.
- [TUX 问题自查手册 (self-service triage)](https://bytedance.larkoffice.com/wiki/U9YuwHTIAi6XhzkiKS0cXtXwngh) — Lark doc.

### FAQ

- [TUX Web FAQ](/v1/docs/faq) (and the canonical [Lark version](https://bytedance.larkoffice.com/wiki/Xeoowzn9ei44lYk30MXckTsanrb)).
- [TUX ReactLynx FAQ](/lynx/docs/faq) (and the canonical [Lark version](https://bytedance.larkoffice.com/wiki/W8wawBRTciz0oLkZhhDckpyFnQC)).

## Related

- [TUX Design official site](http://ttux.bytedance.net/) — maintained by the design team; index of every TUX-ecosystem resource.
- [TUX Context](https://bytedance.larkoffice.com/wiki/FRynw0wwDiLJKtkQR2jcJ8jvnMe) — internal tooling and deprecated assets.

## Source

This page is an English version of the internal [TUX FrontEnd One Pager](https://bytedance.larkoffice.com/wiki/NK0DwXlzGiGlEDk07W7cL1pcnIe). The team's internal roadmap is intentionally omitted here; for the canonical timeline see the Lark doc.
