<!-- tux-web · guides/ssr -->
> **TUX guide — ssr** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/ssr)

# SSR (Server Side Rendering)

If you are using SSR in your project, add rootAttributes to the highest node in the document that you can, eg `html` or `body`. This will set some global properties that are needed, or the first screen will flicker.

_See example: [SSR (Server Side Rendering)](#ssr-server-side-rendering)_

# SSR (Server Side Rendering)

If you are using SSR in your project, add rootAttributes to the highest node in the document that you can, eg `html` or `body`. This will set some global properties that are needed, or the first screen will flicker.

<a id="ssr-server-side-rendering"></a>

```tsx
import { genTUXSchemeAttributes } from '@byted-tiktok/tux-web';

const rootAttributes = genTUXSchemeAttributes({
  theme: "light",
  textDirection: "ltr",
});

<html lang="en" {...rootAttributes}>
  <head>
    {/* ... */}
  </head>
  <body>
    <YourApp />
  </body>
</html>
```
