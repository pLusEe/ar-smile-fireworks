<!-- tux-web · guides/d2c -->
> **TUX guide — d2c** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/d2c)

# TUX D2C

Converts Figma designs into React code. Only web scenarios are supported.

- First-party support for generating components from `@byted-tiktok/tux-web` >= 1.0.0.
- Also supports generating raw React code without a component library.

## Installation

Install it by following [tux-fe-helper](https://tux.bytedance.net/v1/docs/tux-fe-helper).

## Configuration

1. Add `.env` to `.gitignore`.
2. Follow [Get Figma Token](https://tux.bytedance.net/v1/docs/get-figma-token) to create a token, and store it in `.env` with the format `figmaToken=xxx`.

## Usage

1. Provide a Figma link in the agent and explicitly say that D2C is needed, or call `/tux-fe-helper` and provide the same information; additionally, specify whether it should run in `Local Mode` or `Remote Mode`.
2. Wait for the agent to execute and follow the prompts. **The agent collects and generates an input for the D2C execution. Modify it as needed; this helps improve the quality of the D2C output.**
3. Get the generated output after execution completes.

## Modes

TUX D2C provides two execution modes. If you want to use a specific mode, state it clearly in the initial prompt.

### Local Mode `(Default Mode)`

Uses your local agent capabilities to assist with D2C work. If no mode is specified, D2C starts in local mode.

```
- Advantages:
  - Faster execution.
  - The local agent has more repo context, so the generated code can better match the project.
- Disadvantages:
  - D2C relies heavily on AI assistance. If the local AI model is not strong enough, the generated code may be lower quality. Higher-version Opus and GPT models are currently recommended.
```

### Remote Mode

Uses the agent server provided by Tmates to execute D2C work.

```
- Advantages:
  - Tmates provides SOTA model capabilities and can produce high-quality output more reliably.
- Disadvantages:
  - Slower execution and longer runtime.
```
