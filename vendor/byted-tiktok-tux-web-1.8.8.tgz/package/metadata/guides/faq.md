<!-- tux-web · guides/faq -->
> **TUX guide — faq** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/faq)

# FAQ

Covers all out-of-app web scenarios: `tux-web`, `tux-h5`, and `tux-pc`.

> For font, icon, and other static-resource issues, see [Static Resources](/v1/docs/static-resources).
>
> If your question isn't answered here, please consult the [full FAQ document](https://bytedance.larkoffice.com/wiki/Xeoowzn9ei44lYk30MXckTsanrb) before filing an oncall.

## General

### I'm using @byted-tiktok/tux-components, @byted-tiktok/tux-pc, or @byted-tiktok/tux-web@0.y.z and running into problems.

Those libraries and versions are no longer maintained. Migrate to `@byted-tiktok/tux-web@1.y.z`. See [Update from v0](/v1/docs/migration-web) and [Update from h5 or pc](/v1/docs/migration-others).

### I'm getting context errors related to TUXProvider (v0) or TUXApp (v1) — e.g. TUXEnvironmentContext, TUXColorSchemeContext, TUXTextDirectionContext.

Several possible causes — work through them in order:

1. **`TUXProvider` / `TUXApp` not mounted correctly**, or only another library's provider (e.g. `tux-h5`) is mounted. Follow the [TUXProvider](/v0/docs/components/provider) and [TUXApp](/v1/docs/components/app) docs to wire it up properly.
2. **Multiple TUX copies in the bundle.** Common in monorepos or projects with complex dependency graphs where different dependencies each pull in TUX. Install one explicit TUX version at the project root and add an `alias` in your bundler (webpack, etc.) pointing every TUX import to that copy.
3. **Calling TUX hooks outside the provider scope.** Use the hooks/components inside the `children` of `TUXProvider` or `TUXApp`.
4. **Component rendered through a separate render function** (outside the normal React tree). Wrap it again with `TUXProvider` (v0) or `TUXConfigure` (v1).

### Multiple copies of the same TUX library are loaded, causing errors (context errors, singleton errors, etc.).

This happens when different dependencies each bundle their own copy of TUX. Install one explicit TUX version in your project, then configure an `alias` in your bundler (webpack, rollup, etc.) so all imports resolve to that single copy. The exact alias approach depends on your framework — see your framework's docs.

### Why doesn't TUXInput / TUXTextInput show the soft keyboard on mobile when I set autoFocus or call input.focus()?

Mobile browsers forbid programmatically opening the soft keyboard without a prior user interaction. This is a browser restriction, not a TUX limitation.

### I'm using TUX Web inside TTArk and running into issues.

Add `@byted-tiktok/tux-web` to `ttarkServerInternalPackages` in `remix.config.js`.

### I'm seeing 'Invalid hook call.'

Your bundle contains more than one copy of React. Configure an `alias` or `dedupe` for `react` and `react-dom` in your bundler so every import resolves to the version your project depends on.

### I'm using a relative-positioned popover component (menu, tooltip, etc.) with a custom trigger and it won't open.

Positioning is ref-based. A custom trigger may not forward the ref to a real DOM node. Wrap the custom trigger in a plain `` so the ref lands on something concrete.

### I need a component to accept style or className.

TUX is intentionally opinionated and does not expose `style`/`className` by default.

1. Check the component's docs — many already expose targeted customization props that may cover your case.
2. If not, file a request via **Oncall → Design** with the TUX designers. We'll add support once the design team signs off.

### Importing a subpath of @byted-tiktok/tux-web (e.g. /alias, /deprecated) errors out.

1. **TypeScript-only error.** Likely a TS version or config mismatch reading the file type. Options:
- Upgrade TS / adjust config per the error message.
- For low-volume use, suppress with `@ts-ignore`.
- `@byted-tiktok/tux-web/alias` ships without types and will error on some TS versions — `@ts-ignore` is the recommended workaround.
2. **Runtime error.** More involved:
- For component imports, the most common cause is incorrect alias config. First try *removing* any TUX aliases. If that doesn't work, use the alias helper TUX provides — see the *Typical Issue* section of [migration-web](/v1/docs/migration-web).
- If *every* subpath import fails, the cause is almost always your framework or bundler config. Talk to the team that maintains it.

### I set showTopSafeArea to true but it doesn't take effect on a particular device.

That device likely doesn't support `safe-area-inset-top` at the system level. Fall back to setting `topSafeAreaHeight` manually.

### TUXMenu, TUXPopover, TUXTooltip, and other trigger-anchored components position incorrectly.

These components attach a `ref` to the trigger and position from it. If the trigger doesn't accept a `ref`, or processes it in an unusual way, positioning breaks. Wrap the trigger in an outer `` to give the ref a stable target.

### TUXMenu, TUXPopover, TUXTooltip, or other floating components throw a JS error.

TUX depends on `floating-ui`, which depends on `tabbable`. `tabbable@6.4.0` shipped a regression that breaks these components. Pin `tabbable: 6.3.0` in your project to work around it.

### Our project is still on React 17 and @byted-tiktok/tux-web is now throwing errors.

TUX Web's own code supports both React 17 and 18. The error comes from the `framer-motion` dependency, introduced in `1.4.2`. Two ways out:

1. Downgrade to `= 1.4.1` (no `framer-motion` dependency).
2. Upgrade to `>= 1.6.3`, where the incompatible code path was replaced.

## Resolved Issues

### [Solved] After adding edenx's BFF feature, importing from @byted-tiktok/tux-web produces TS errors.

TS-only — no runtime impact. Pick any one of:

1. Suppress with `// @ts-ignore`.
2. Adjust the file:
- If it renders on the frontend, rename it to `.mtsx`.
- If it runs on Node, change the import to `import xxx from '@byted-tiktok/tux-web/dist/index.cjs'`.
3. Restructure your `tsconfig.json` (edenx has reported other issues with this approach — use with caution):
- Restore the root `tsconfig.json` to its original values.
- Create a new `tsconfig.json` inside the server directory that extends the root and re-applies edenx's changes, with an appropriate `include`.
- In the root `tsconfig.json`, `exclude` that server directory.

**Why it happens:** edenx's BFF feature rewrites `tsconfig` with:

```json
compilerOptions: module: "nodeNext",
"moduleResolution": "nodenext"
}
}
```

This switches resolution to Node's [Packages](https://nodejs.org/api/packages.html) rules (added in v12), which most business projects' file layouts don't follow — hence the breakage.

For the full write-up, see [tux-web Import Error Analysis](/v1/docs/tux-web-import-error-analysis).
