<!-- tux-web · guides/static-resources -->
> **TUX guide — static-resources** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/static-resources)

# Static Resources

Fonts, icons, illustrations, and colors are shared between TUX Web and TUX ReactLynx. This page documents the packages that ship those resources, the font versions and their CDNs, and a quick FAQ for the recurring static- resource questions.

## Fonts

Owned by TUX designer `qinyiyao@bytedance.com`. For visual or design questions, contact the design team directly. Download links and details: [TikTok Sans: Font Files Download](https://bytedance.us.larkoffice.com/docx/HQozdHCyJoGGj2xgTZjuWxeqs6d).

### Versions

|  | V4 | V3 | V2 |
| --- | --- | --- | --- |
| Label | TikTok Sans | TikTok Font / TikTok Display Font | Proxima |
| Status | LTS | Long-term maintenance — frozen once V4 is fully rolled out, CDN URLs preserved | Deprecated |
| Description | Fourth-generation TUX standard font. TikTok-owned. | Third-generation TUX standard font. TikTok-owned. | Second-generation TUX standard font. Third-party owned. |
| Support | CDN published. tux-web ≥ 1.4.1 supports it. Lynx side supports it. | Long-term maintenance, will be frozen once V4 finishes rollout. CDN URLs are preserved. | No further work. |

### V4 font files

| Family | Files |
| --- | --- |
| TikTokSans (variable) | TikTokSans-VF (woff2 \| ttf) |
| TikTokSans 16pt | Regular / SemiBold / Bold (woff2 \| otf \| ttf) |
| TikTokSans 36pt | Regular / SemiBold / Bold (woff2 \| otf \| ttf) |

The variable file is the primary asset; the static 16pt and 36pt files exist as fallbacks.

### CDN

Two regional CDN buckets host the V4 fonts. **Always include the full query string (e.g. `?_default_font=1&amp;v=2`)** — TikTok containers detect that flag and substitute the in-app font.

| Region | Base URL |
| --- | --- |
| RoW | https://sf16-website-login.neutral.ttwstatic.com/obj/tiktok_web_login_static/tiktok_fonts/ |
| US-TTP | https://lf16-tiktok-common.tiktokcdn-us.com/obj/tiktok-web-common-tx/tiktok_fonts/ |

Gecko channel for offline asset delivery: `tiktok_fonts` ( [channel 2820](https://tiktok-gecko-global.tiktok-row.net/gecko/site/channel/2820)) — supported on iOS and Android.

### Font-family mapping

The font-family names you write in code do not necessarily match the file names on disk. TikTok containers map TUX's declared families to the in-app font automatically.

#### Web

- TikTok Android **≥ 44.9** supports CDN-based mapping to the in-app font. Append `?_default_font=1&amp;v=2` to your CDN URL to opt in.
- TikTok iOS: use Gecko offline assets.

#### Lynx

- TikTok ≥ 44.6 (both platforms) supports the new family-name mapping with the in-app font bundle. Declare `TikTokSans`.
- Containers ship the V4 font and TUX maps legacy family names (`TikTokFont-*`, `TikTokDisplayFont-*`, `ProximaNova-*`) to it, so most projects do not need to change anything.
- For variable-font properties, check the prerequisites on the [Typography page](/lynx/docs/typography).

## Icons, illustration, and color packages

The TUX team does not provide CDN downloads, token maps, or other static endpoints for icons, illustrations, or colors. We only ship npm packages.

To add a new resource, route it through your business designer. Resources are synced from the design system to code asynchronously, and packages publish every **Wednesday**.

| Resource | Web package | Lynx package | Galleries |
| --- | --- | --- | --- |
| Icons | `@byted-tiktok/tux-icons` | `@byted-tiktok/tux-rlynx-icons` | [Web](/v1/docs/icons) · [Lynx](/lynx/docs/icons) · [Design](https://ttux.bytedance.net/icons) |
| Illustration | `@tiktok-arch/tux-illustration/web` | `@tiktok-arch/tux-illustration/rlynx` | [Web](/v1/docs/illustrations) · [Lynx](/lynx/docs/illustrations) · [Design](https://ttux.bytedance.net/illustration) |
| Color | `@byted-tiktok/tux-color` | `@byted-tiktok/tux-color` | [Web](/v1/docs/colors) · [Lynx](/lynx/docs/colors) · [Design](https://ttux.bytedance.net/color) |

> Color is rarely consumed directly. Prefer the color tokens exposed by the component library; pull the package in only when you need a raw value (e.g. for SVGs or canvas).

## FAQ

### Compliance requires swapping the font resources used in the TTP region.

Follow the refactor guide [Web compliance modification manual (Texas & Clover)](https://bytedance.sg.larkoffice.com/docx/KwaxdMmXHodTfKx2w63loBIlg3d). PnS provides a webpack plugin that does the swap automatically. For plugin issues, ask PnS oncall.

If the plugin doesn't fit your scenario, grab the TTP font CDN base URL from the table above and roll your own solution.

### Deployment blocked because the bundle contains a sensitive keyword (e.g. 'PayPal').

Apply for an exemption from the deployment platform owner. For Gecko, contact `zhangxiaoxiao.zxx@bytedance.com` or `liujinhe@bytedance.com`. The compliance team is also exploring a blanket exemption for TUX bundles.

### The font shown in the client doesn't match the design.

Common knowledge for both Web and Lynx:

1. TUX fonts only cover Latin letters and Arabic numerals. Other scripts (Chinese, Japanese, Korean, …) are outside the TUX font scope.
2. The font families declared by TUX CSS are mapped by the container to the in-app TikTok font (V2 Proxima, V3 TikTokFont, V4 TikTokSans).

Lynx-specific:

1. Custom `font-family` names are not mapped by the container. Use TUX-declared names — see the *Font-family mapping* section above.
2. If the issue persists, inspect the actually-rendered font with [Peephole](https://bytedance.larkoffice.com/docx/VQS4dZ3tAoFxiixvj9ZcRP0jnIQ).
3. Some test devices or app builds have known bugs. Try a different device or build.
4. Make sure font styles are set on the `&lt;text&gt;` node, or enable Lynx CSS inheritance.

### I can't find the color token I need.

1. Check the in-site references first: [TUX Web colors](/v1/docs/colors) or [TUX ReactLynx colors](/lynx/docs/colors).
2. If the token exists on the site, upgrade your component library (or for legacy users, `@byted-tiktok/tux-rlynx-foundation`) to the latest version.
3. If the site doesn't list it either, confirm with the business designer that it has been submitted to the TUX design system, then wait for the next Wednesday release.

### The design system has the icon / color / illustration, but I can't find it in tux-icons, tux-illustration, or the component library.

Pulling the latest assets from the resource platform and publishing the npm packages both run on a schedule. Adoption is not instantaneous.

- npm packages publish every Wednesday.
- Assets added on Monday or Tuesday usually miss that week's release — expect them in the following week.
- In a monorepo, `workspace:` versions do not necessarily track the latest code; pin the explicit latest version.
- If you need it now, copy the asset into your project and self-maintain it; swap to the package once the release lands.
- If a long-overdue asset is still missing, file an oncall.

### The rendered icon / color / illustration doesn't match the design.

1. Check the latest version in the site: [TUX Web icons](/v1/docs/icons) or [TUX ReactLynx icons](/lynx/docs/icons).
2. If the site looks correct, upgrade the corresponding package in your project.
3. If the site also looks wrong, confirm with the business designer that the latest version has been submitted to the TUX design system, then wait for the next Wednesday release.

### On Lynx Android, illustrations appear washed out / dimmer than expected.

A known bug in `@byted-tiktok/tux-rlynx-components`'s `TUXIllustration`. Fixed in version `2.4.20`. Upgrade both the component library and tux-illustration to their latest versions.

### The font flickers on screen during page load.

This is a font-loading problem. Use the platform's preload mechanism.

- Web:
  - Enable Gecko for the font channel.
  - Preload from HTML:
    ```tsx
    <link rel="preload" href="TikTokSans.woff2" as="font" type="font/woff2" crossorigin />
    ```
- Lynx reads font assets directly from the container, so this should not happen there. If it does, file an oncall.

### How do I use a bitmap icon on Lynx?

Lynx has problems rendering bitmaps, so the format isn't supported. Use a plain image, or ask the designer to deliver an SVG version of the icon.

## Source

This page is an English consolidation of [TUX Static Resources Info](https://bytedance.larkoffice.com/wiki/RowLwQLLNiB6bXkFhaecJbm2nch) and the [TUX Static Resources FAQ](https://bytedance.larkoffice.com/wiki/Tf16wpeUYiNTDZkhGTRcB7tfnLg).
