<!-- tux-web · guides/optimal-text-resize -->
> **TUX guide — optimal-text-resize** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/optimal-text-resize)

# Optimal Text Resize

Variable font size: the font size scales according to the length of the text. The basic principle is that when there are more characters, the font size becomes smaller, and when there are fewer characters, the font size becomes larger.

- We have two hook functions, `useSingleLineOptimalTextResize` and `useMultiLineOptimalTextResize`, for single line and multiple lines text solutions
- In order to use these two hooks, your browser/environment must support `ResizeObserver` and `MutationObserver`
  (check browser compatibility: [ResizeObserver](https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver), [MutationObserver](https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver))

## Single Line

- use `useSingleLineOptimalTextResize` hook to make text resizable
- set up the min font size by using `useSingleLineOptimalTextResize(optimalTextRef, { minSize: ${MIN_FONT_SIZE}})`
- if no `MIN_FONT_SIZE` is set up, the default `MIN_FONT_SIZE` is `12px`
- change text size to see `font-size` changes

_See example: [Single Line](#single-line)_

## Multi Line

- use `useMultiLineOptimalTextResize` hook to make text resizable
- there are three modes: default, min_font_size, and customize fontSizeRanges (reference: [OptimalTextResize Behavior](https://bytedance.larkoffice.com/wiki/OlArwLbVKi3LXskyzeAcvgIHngf))
- `const useMultiLineOptimalTextResize: (ref: React.RefObject<HTMLElement>, optimalResize: TMultiLineOptimalTextResize, onResize?: (el: HTMLElement) => void) => void`
- `type TMultiLineOptimalTextResize =
| boolean
| {
    minSize: number;
  }
| { fontSizeRanges: number[][] };`
- change text size to see `font-size` changes

_See example: [Multi Line](#multi-line)_

## Server Side Rendering

- To get a better user experience in ssr environment, set the ref element to `visibility: 'hidden'` initially and add it back when the resize callback is triggered.

_See example: [Server Side Rendering](#server-side-rendering)_

## Single Line

- use `useSingleLineOptimalTextResize` hook to make text resizable
- set up the min font size by using `useSingleLineOptimalTextResize(optimalTextRef, { minSize: ${MIN_FONT_SIZE}})`
- if no `MIN_FONT_SIZE` is set up, the default `MIN_FONT_SIZE` is `12px`
- change text size to see `font-size` changes

<a id="single-line"></a>

```tsx
// import { useRef } from 'react';
// import { useSingleLineOptimalTextResize, TUXText } from '@byted-tiktok/tux-web';

const Example = () => {
  const optimalTextRef = useRef<HTMLDivElement>(null);
  useSingleLineOptimalTextResize(optimalTextRef, { minSize: 10});
  return (
    <TUXText ref={optimalTextRef} typographyPreset="H1-Bold" textDisplay="truncate" as="div"
    style={{ maxWidth: '300px' }}>
      {'Lorem ipsum '.repeat(5)}
    </TUXText>
  )
}
```

## Multi Line

- use `useMultiLineOptimalTextResize` hook to make text resizable
- there are three modes: default, min_font_size, and customize fontSizeRanges (reference: [OptimalTextResize Behavior](https://bytedance.larkoffice.com/wiki/OlArwLbVKi3LXskyzeAcvgIHngf))
- `const useMultiLineOptimalTextResize: (ref: React.RefObject<HTMLElement>, optimalResize: TMultiLineOptimalTextResize, onResize?: (el: HTMLElement) => void) => void`
- `type TMultiLineOptimalTextResize =
| boolean
| {
    minSize: number;
  }
| { fontSizeRanges: number[][] };`
- change text size to see `font-size` changes

<a id="multi-line"></a>

```tsx
// import { useRef } from 'react';
// import { useMultiLineOptimalTextResize, TUXText } from '@byted-tiktok/tux-web';

const Example = () => {
  const optimalTextRef = useRef<HTMLDivElement>(null);
  useMultiLineOptimalTextResize(optimalTextRef, true);
  return (
    <TUXText typographyPreset="H1-Bold" ref={optimalTextRef} as="div">
      {'Lorem ipsum '.repeat(10)}
    </TUXText>
  )
}
```

## Server Side Rendering

- To get a better user experience in ssr environment, set the ref element to `visibility: 'hidden'` initially and add it back when the resize callback is triggered.

<a id="server-side-rendering"></a>

```tsx
// import { useRef } from 'react';
// import { useMultiLineOptimalTextResize, TUXText } from '@byted-tiktok/tux-web';

const Example = () => {
  const onResize = (el: HTMLElement): void => {
    el.style.visibility = 'visible';
  };
  const optimalTextRef = useRef<HTMLDivElement>(null);
  useMultiLineOptimalTextResize(optimalTextRef, true, onResize);
  return (
    <TUXText typographyPreset="H1-Bold" ref={optimalTextRef} as="div" style={{ visibility: 'hidden' }}>
      {'Lorem ipsum '.repeat(10)}
    </TUXText>
  )
}
```
