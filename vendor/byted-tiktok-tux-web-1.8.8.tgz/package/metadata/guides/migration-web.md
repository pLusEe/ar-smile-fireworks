<!-- tux-web · guides/migration-web -->
> **TUX guide — migration-web** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/migration-web)

# Migration from TUX WEB V0

> for more information, please refer to [TUX WEB V0 -> V1 Update Guideline](https://bytedance.larkoffice.com/wiki/HMoQwUJ3PiDvbKkO47vc1Mw5n7d).

## Info

1. `@byte-tiktok/tux-web@1.y.z` also export V0 components, that means you can do a progressive migration, changing one component at a time.
2. Icons are no longer exported in `@byte-tiktok/tux-web@1.y.z`, please import them from `@byte-tiktok/tux-icons`, please check [icons](/v1/docs/icons) to get new usage.
3. Components may have different names in different libs, please refer to [Component Map](/v1/docs/component-map) to find the component you need.

## Steps

1. Update `@byte-tiktok/tux-web` to `1.y.z`
2. Import V1 global resources, such as 'style.css' and 'TUXApp'

_See example: [Steps](#steps)_

3. Change the import of icons from `@byte-tiktok/tux-web` to `@byte-tiktok/tux-icons`
4. You can use V1 components together with V0 components, until you done the migration.

## Typical Issues

### Singleton Issues

If you encounter the singleton issue, such as errors like `Cannot get TUX theme, Make sure to wrap your app with the TUXApp`.  
Please add alias config to your bundler, such as webpack, rollup, etc.

_See example: [Singleton Issues](#singleton-issues)_

If you want to keep the import path same as v0 version, you can use `getTUXAliasCompatible` instead.

_See example: [Singleton Issues](#singleton-issues-1)_

## Steps

1. Update `@byte-tiktok/tux-web` to `1.y.z`
2. Import V1 global resources, such as 'style.css' and 'TUXApp'

<a id="steps"></a>

```tsx
// show case
import '@byted-tiktok/tux-web/styles.css' // v1 css
import '@byted-tiktok/tux-web/deprecated/styles.css' // v0 css

import { TUXApp, TUXButton as TUXButtonV1 } from '@byted-tiktok/tux-web';
import { TUXProvider, TUXButton as TUXButtonV0 } from '@byted-tiktok/tux-web/deprecated';

const theme = 'light';
const textDirection = 'ltr';

<TUXApp theme={theme} textDirection={textDirection} platform="Desktop">
  <TUXProvider colorSchemePreference={theme} textDirection={textDirection}>
    <TUXButtonV1 leadingIcon={<TUXIconStarRing />} text="Make your day" />
    <TUXButtonV0 leadingIcon={<TUXIconStarRing />} label="Make your day" />
  </TUXProvider>
</TUXApp>
```

### Singleton Issues

If you encounter the singleton issue, such as errors like `Cannot get TUX theme, Make sure to wrap your app with the TUXApp`.  
Please add alias config to your bundler, such as webpack, rollup, etc.

<a id="singleton-issues"></a>

```tsx
// need version 1.2.3 or higher
const { getTUXAlias } = require('@byted-tiktok/tux-web/alias');

// webpack.config.js
{
  ...,
  resolve: {
    alias: {
      ...getTUXAlias(__dirname),
    },
  },
};
```

### Singleton Issues

If you want to keep the import path same as v0 version, you can use `getTUXAliasCompatible` instead.

<a id="singleton-issues-1"></a>

```tsx
// need version 1.2.3 or higher
const { getTUXAliasCompatible } = require('@byted-tiktok/tux-web/alias');

// webpack.config.js
{
  ...,
  resolve: {
    alias: {
      ...getTUXAliasCompatible(__dirname),
    },
  },
};

// my-page.tsx
import '@byted-tiktok/tux-web/v1/styles.css'; // v1 styles
import '@byted-tiktok/tux-web/dist/styles.css'; // v0 styles

import { TUXButton as TUXButtonV1 } from '@byted-tiktok/tux-web/v1';
import { TUXButton as TUXButtonV0 } from '@byted-tiktok/tux-web';
```
