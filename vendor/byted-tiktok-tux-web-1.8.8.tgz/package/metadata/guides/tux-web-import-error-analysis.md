<!-- tux-web · guides/tux-web-import-error-analysis -->
> **TUX guide — tux-web-import-error-analysis** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/tux-web-import-error-analysis)

# tux-web Import Error Analysis

A deep dive into the recurring TypeScript import error reported by projects that use **both** `@byted-tiktok/tux-web` and **EdenX's BFF feature**. This page explains the technical background, isolates the root cause, and lists workable mitigations.

For the quick-fix workarounds, see the corresponding entry on the [FAQ page](/v1/docs/faq).

## Technical background

### Node.js packages spec

Node.js v12 introduced the [Modules: Packages](https://nodejs.org/api/packages.html) spec. The relevant rules:

1. A `package.json` can declare its **module system** via the `type` field: `"type": "module"` or `"type": "commonjs"`. When unset, the default is `"commonjs"`.
2. With `"type": "module"`, `.js` files are treated as ES modules. CommonJS syntax such as `require` is not available. To run a file as CommonJS, give it a `.cjs` extension.
3. With `"type": "commonjs"`, `.js` files are treated as CommonJS. Top-level `await` and other ESM-only syntax are not available. To run a file as ESM, give it a `.mjs` extension.
4. In an `import` specifier with the extension omitted, Node defaults to `.js`.
5. ESM files **may** import CommonJS files (with some runtime caveats) and vice versa.

These rules only apply when Node executes the code, and they propagate through the entire dependency-resolution chain.

### TypeScript's `nodeNext` module mode

TypeScript added a new resolver, [nodeNext](https://www.typescriptlang.org/tsconfig/#module), configured as:

_See example: [TypeScript's `nodeNext` module mode](#typescript-s-nodenext-module-mode)_

`nodeNext` follows Node's Packages spec with two small but important differences:

1. Resolution covers every TypeScript-supported extension — `.ts`, `.jsx`, `.tsx`, etc.
2. **ESM files are not allowed to `import` CommonJS files**, and vice versa.

Because this is configured in `tsconfig.json`, the rule applies wherever that config is consulted:

- The TypeScript Language Service in your IDE.
- `tsc` builds.

## Root cause

The error appears when these three parties combine:

1. **EdenX.** Enabling the BFF feature rewrites the project's root `tsconfig.json` and switches its module resolution to `nodeNext`.
2. **tux-web.** The package declares `"type": "module"` and is organised per Node's Packages spec.
3. **Your project.**
   - You use EdenX's BFF feature.
   - You are not a pure server project — you also have frontend page code and you import `@byted-tiktok/tux-web`.
   - Your project layout does not follow Node's Packages spec.

Given the three:

1. EdenX edits the **root** `tsconfig.json`, so its `nodeNext` setting affects the whole project.
2. Because your project does not follow the Packages spec:
   - `package.json` has no `type` field — the project is treated as CommonJS by default.
   - Page files (`.tsx`) are therefore treated as CommonJS modules.
3. A CommonJS page file importing the ESM `tux-web` triggers the `nodeNext` error.

## Solutions

In order of preference.

### Best: upgrade your project layout

Node v12 shipped in 2019 — these conventions have been mainstream for over five years, and large parts of the open-source ecosystem already follow them. Upgrade the monorepo to align with the Packages spec.

- Difficulty: **high**
- Risk: **low**

### Better: scope EdenX's edits

Have EdenX restrict its BFF-mode `tsconfig.json` edits to server-only directories instead of touching the project root.

- Difficulty: **unknown**
- Risk: **unknown**

### Already done: tux-web downgrades

tux-web has already done a "technical downgrade" — it no longer ships new features that depend on the Packages spec and presents itself as CommonJS-compatible.

- Difficulty: **low**
- Risk: **estimated low**

### Last resort: per-file workarounds

Apply the workarounds documented in the [FAQ](/v1/docs/faq) (`@ts-ignore`, rename to `.mtsx`, point the import at the CJS build, or split `tsconfig.json`).

- Difficulty: **already shipped**
- Risk: **none**

## Source

This page is an English version of [Analysis of tux-web import errors](https://bytedance.larkoffice.com/wiki/JO6pww7QSi3LxMkvC8zctD4UnIg).

### TypeScript's `nodeNext` module mode

TypeScript added a new resolver, [nodeNext](https://www.typescriptlang.org/tsconfig/#module), configured as:

<a id="typescript-s-nodenext-module-mode"></a>

```tsx
{
  "compilerOptions": {
    "module": "nodeNext",
    "moduleResolution": "nodenext"
  }
}
```
