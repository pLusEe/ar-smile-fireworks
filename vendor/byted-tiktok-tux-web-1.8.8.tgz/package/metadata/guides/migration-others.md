<!-- tux-web · guides/migration-others -->
> **TUX guide — migration-others** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/migration-others)

# Migration from other TUX libs

Many users may be using some other TUX libs, such as `@byted-tiktok/tux-components` & `@byted-tiktok/tux-pc`, this document will help you to migrate from those old libs.

## Info

1. `@byte-tiktok/tux-web@1.y.z` can be used together with other TUX libs, that means you can do a progressive migration, changing one component at a time.
2. Icons are no longer exported in `@byte-tiktok/tux-web@1.y.z`, please import them from `@byte-tiktok/tux-icons`, please check [icons](/v1/docs/icons) to get new usage.
3. Components may have different names in different libs, please refer to [Component Map](/v1/docs/component-map) to find the component you need.

## Steps

1. Refer to [Quick start](/v1/docs/quick-start) to import `@byte-tiktok/tux-web@1.y.z`
2. You can use new components together with other TUX libs, until you done the migration.

_See example: [Steps](#steps)_

3. Change the import of icons from `@byte-tiktok/tux-web` to `@byte-tiktok/tux-icons`

## Steps

1. Refer to [Quick start](/v1/docs/quick-start) to import `@byte-tiktok/tux-web@1.y.z`
2. You can use new components together with other TUX libs, until you done the migration.

<a id="steps"></a>

```tsx
// show case
import { TUXApp, TUXButton as TUXButtonV1 } from '@byted-tiktok/tux-web';
import {TUXProvider as TUXProviderH5, TUXButton as TUXButtonH5 } from '@byted-tiktok/tux-components';
import { TUXButton as TUXButtonPC } from '@byted-tiktok/tux-pc';

const theme = 'light';
const textDirection = 'ltr'

<TUXApp theme={theme} textDirection={textDirection} platform="Desktop">
  <TUXProviderH5 theme={theme} dir={textDirection}>
    <TUXButtonV1 leadingIcon={<TUXIconStarRing />} text="Make your day" />
    <TUXButtonH5 icon={<TUXIconStarRing />} text="Make your day" />
    <TUXButtonPC icon={<TUXIconStarRing />} label="Make your day" />
  </TUXProviderH5>
</TUXApp>
```
