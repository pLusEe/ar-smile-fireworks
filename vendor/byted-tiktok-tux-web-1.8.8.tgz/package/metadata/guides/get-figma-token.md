<!-- tux-web · guides/get-figma-token -->
> **TUX guide — get-figma-token** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/get-figma-token)

# Get Figma Token

Figma is now rate-limiting Open API access for normal accounts, so please use an account with Dev Mode enabled.

Please follow the following steps to create a figma access token
1. Click the Back to files button in the top-left corner to go back to the homepage.

2. Find your email (username), open the dropdown, and select Settings.

3. In the popup window, go to the Security tab. Scroll down to the Personal access tokens section and click Generate new token to create a new token.

4. Fill in the fields as follows:
```
- Token name: Enter any name you like, for example `my-token-[date]`.
- Expiration: It’s recommended to set the validity period to 90 days, so you don’t need to regenerate tokens too often.
- Under Scopes, select the following permissions:
 - file_content:read (required) — allows reading file content.
 - file_variables:read (required) — allows access to reusable component variables.
 - library_assets:read (required) — allows access to shared library assets.
 - library_content:read (required) — allows access to shared library content.
```

5. After clicking Generate token, a yellow box will appear containing your token. You only have one chance to copy it. Once you leave the page, you won’t be able to view it again, and you’ll need to generate a new token.
