<!-- tux-web · guides/breakpoint -->
> **TUX guide — breakpoint** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/breakpoint)

# Breakpoint

Breakpoint defines viewport size levels. It does not represent the available space remaining after safe areas, navigation bars, or other occupied regions are excluded. It is a two-dimensional value with horizontal and vertical levels:

```ts
type TUXBreakpoint = horizontal: 'small' | 'medium' | 'large' | 'xlarge';
vertical: 'small' | 'medium' | 'large';
};
```

See the [`TUXApp` documentation](/v1/docs/components/app) for usage.

## Horizontal levels

| Level | Viewport width |
| --- | --- |
| `small` | ` 600px` |
| `medium` | `600px–899px` |
| `large` | `900px–1199px` |
| `xlarge` | `≥ 1200px` |

## Vertical levels

| Level | Viewport height |
| --- | --- |
| `small` | ` 700px` |
| `medium` | `700px–949px` |
| `large` | `≥ 950px` |

Horizontal and vertical levels are calculated independently. A short, wide viewport can therefore be `xlarge` horizontally and `small` vertically.

## Default values

When `TUXApp.breakpoint` is omitted, the following default is selected from `TUXApp.platform`:

| Platform | Horizontal | Vertical |
| --- | --- | --- |
| `desktop` | `large` | `medium` |
| `iOS` | `small` | `medium` |
| `android` | `small` | `medium` |
