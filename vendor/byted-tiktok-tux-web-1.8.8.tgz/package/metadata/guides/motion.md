<!-- tux-web · guides/motion -->
> **TUX guide — motion** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/motion)

# TUX Motion Curve

TUX provide two motion curve models - spring model and pop model.

- We have two hook functions, `useSpringMotion` and `usePopMotion`, for spring model and pop model

## Spring Motion

- `useSpringMotion` uses `stiffness` and `damping` to construct the motion curve
- type TSpringMotionOptions = \{
  active?: boolean;
  from?: number;
  to?: number;
  stiffness: number;
  damping: number;
  \}

_See example: [Spring Motion](#spring-motion)_

## Pop Motion

- `usePopMotion` uses `bounciness` and `speed` to construct the motion curve
- type TPopMotionOptions = \{
  active?: boolean;
  from?: number;
  to?: number;
  bounciness: number;
  speed: number;
  \}

_See example: [Pop Motion](#pop-motion)_

## Spring Motion

- `useSpringMotion` uses `stiffness` and `damping` to construct the motion curve
- type TSpringMotionOptions = \{
  active?: boolean;
  from?: number;
  to?: number;
  stiffness: number;
  damping: number;
  \}

<a id="spring-motion"></a>

```tsx
// import { useState } from 'react';
// import { IconShoppingCartFill } from '@byted-tiktok/tux-icons';
// import { useSpringMotion } from '@byted-tiktok/tux-web';

const Example = () => {
  const [isActive, setIsActive] = useState(false);
  const scale = useSpringMotion({
    active: isActive,
    from: 0.5,
    to: 1,
    stiffness: 600,
    damping: 200
  });

  const translateX = useSpringMotion({
    active: isActive,
    from: 0,
    to: 150,
    stiffness: 600,
    damping: 200
  });

  return (
    <div>
      <div
        style={{
          width: '50px',
          height: '50px',
          fontSize: '50px',
          borderRadius: '50%',
          transform: `scale(${scale}) translateX(${translateX}px)`,
          marginBlockEnd: '10px'
        }}
      >
        <IconShoppingCartFill />
      </div>
      <TUXButton text="Click Me" onClick={() => { setIsActive(!isActive)} }/>
    </div>
  )
}
```

## Pop Motion

- `usePopMotion` uses `bounciness` and `speed` to construct the motion curve
- type TPopMotionOptions = \{
  active?: boolean;
  from?: number;
  to?: number;
  bounciness: number;
  speed: number;
  \}

<a id="pop-motion"></a>

```tsx
// import { useState } from 'react';
// import { IconShoppingCartFill } from '@byted-tiktok/tux-icons';
// import { usePopMotion } from '@byted-tiktok/tux-web';

const Example = () => {
  const [isActive, setIsActive] = useState(false);
  const scale = usePopMotion({
    active: isActive,
    from: 0.5,
    to: 1,
    bounciness: 10,
    speed: 5
  });

  const translateX = usePopMotion({
    active: isActive,
    from: 0,
    to: 150,
    bounciness: 10,
    speed: 5
  });

  return (
    <div>
      <div
        style={{
          width: '50px',
          height: '50px',
          fontSize: '50px',
          borderRadius: '50%',
          transform: `scale(${scale}) translateX(${translateX}px)`,
          marginBlockEnd: '10px'
        }}
      >
        <IconShoppingCartFill />
      </div>
      <TUXButton text="Click Me" onClick={() => { setIsActive(!isActive)} }/>
    </div>
  )
}
```
