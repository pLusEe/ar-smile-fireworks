<!-- tux-web · guides/tux-fe-helper -->
> **TUX guide — tux-fe-helper** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/tux-fe-helper)

# TUX FE Helper

TUX FE Helper is an AI-assisted toolkit provided by the TUX Team. It provides TUX FE capabilities across different agents.

## Capabilities

TUX FE Helper currently provides two categories of capabilities:

1. Knowledge for using TUX component libraries, including the following three component libraries:
   - `@byted-tiktok/tux-web` >= 1.0.0
   - `@tiktok-arch/tux-react-lynx`
   - `@byted-tiktok/tux-rlynx-components`
2. D2C capability support, which converts designs into React code. Only web support is provided.

## Contents

TUX FE Helper includes one skill and one MCP. Install both to get the complete experience.

### Skill: tux-fe-helper

Assists with MCP discovery and usage. It is not expected to change frequently.

Installation:

_See example: [Skill: tux-fe-helper](#skill-tux-fe-helper)_

### MCP

The core AI tool wrapper for TUX, maintained and iterated over the long term.

Installation:
Add the following configuration to your AI agent client. **Do not change the MCP name.**

_See example: [MCP](#mcp)_

## Usage

See the documentation for each capability:

- [tux-knowledge](https://tux.bytedance.net/v1/docs/tux-knowledge)
- [d2c](https://tux.bytedance.net/v1/docs/d2c)

### Skill: tux-fe-helper

Assists with MCP discovery and usage. It is not expected to change frequently.

Installation:

<a id="skill-tux-fe-helper"></a>

```tsx
# install
npx -y skills@latest add git@code.byted.org:tiktok/tux_skills.git --skill tux-fe-helper

# update
npx -y skills update git@code.byted.org:tiktok/tux_skills.git --skill tux-fe-helper
```

### MCP

The core AI tool wrapper for TUX, maintained and iterated over the long term.

Installation:
Add the following configuration to your AI agent client. **Do not change the MCP name.**

<a id="mcp"></a>

```tsx
{
  "mcpServers": {
    "tux-fe": {
      "command": "npx",
      "args": [
        "-y",
        "--registry=https://bnpm.byted.org/",
        "@tiktok-mcp/tux@latest"
      ]
    }
  }
}
```
