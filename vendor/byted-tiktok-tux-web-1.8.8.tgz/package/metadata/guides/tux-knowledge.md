<!-- tux-web · guides/tux-knowledge -->
> **TUX guide — tux-knowledge** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/tux-knowledge)

# TUX Knowledge

Provides intelligent Q&A for TUX knowledge.

## Local

1. Install [tux-fe-helper](https://tux.bytedance.net/v1/docs/tux-fe-helper) first.
2. Ask TUX questions in your local agent chat, or let the agent call it automatically when TUX knowledge is needed.
   - tux-fe-helper provides the most suitable knowledge based on the versions used in your project.

**Note**: If your project has no TUX component library installed, or has multiple TUX component libraries installed, provide the specific package name and version number to get an accurate answer. Otherwise, the agent will handle the situation based on the actual context.

## Online

Visit [TUX-Pert](/chatbot) for online consultation.
