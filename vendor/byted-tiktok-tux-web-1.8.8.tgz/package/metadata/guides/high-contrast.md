<!-- tux-web · guides/high-contrast -->
> **TUX guide — high-contrast** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/high-contrast)

# High Contrast Colors

TUX ships an **accessibility-oriented high contrast palette** as a first-class, opt-in feature.
When enabled, both the CSS side (global variables) and the JS side (color map consumed by TUX components) switch to the high contrast values atomically — no "half on" state is possible.

## Enabling high contrast

Two pieces must be wired up together at the app root. They are kept as two explicit inputs so that apps that never enable high contrast pay no bundle cost — neither the CSS bundle nor `colorsV2HighContrastRgba` is pulled in unless you reference it:

1. Import `@byted-tiktok/tux-web/colors-v2-high-contrast.css` alongside the base stylesheet.
2. Pass a color map to `TUXApp`'s `highContrastColors` prop — the single source of truth for whether high contrast is active.

_See example: [Enabling high contrast](#enabling-high-contrast)_

Passing the map turns high contrast **on** (CSS attribute + context override); passing `undefined` (or omitting the prop) turns it **off**. There is no separate boolean flag.

_See example: [Global toggle via `TUXApp`](#global-toggle-via-tuxapp)_

_See example: [Scoped toggle via `TUXConfigure`](#scoped-toggle-via-tuxconfigure)_

## Following the system preference

Most apps tie the flag to `prefers-contrast: more`. `tux-web` ships `useSystemHighContrast` so you can wire it up in one line — it subscribes to the media query and cleans up automatically:

_See example: [Following the system preference](#following-the-system-preference)_

## Reading the merged colors at runtime

When you read TUX color tokens **from JavaScript**, always go through the context so the value tracks high contrast:

_See example: [Reading the merged colors at runtime](#reading-the-merged-colors-at-runtime)_

The legacy utilities `getColorCSSVar` / `resolveColor` / `getRgbaFromToken` (and `HOVERED_OVERLAY_COLOR_RGBA` / `getHoveredTextColor` / `getHoveredBackgroundColorToken`) still work and are kept for backward compatibility, but they read the static v2 base palette only and **do not follow high contrast**. They are marked `@deprecated`; prefer the `*FromMap` variants for any new code.

## Notes

- **Single source of truth.** Do not set `data-tux-high-contrast` by hand — let `TUXApp` / `TUXConfigure` manage it. Setting the attribute without providing `highContrastColors` will desync the CSS and JS sides.
- **Tree-shakable.** Neither the CSS bundle nor `colorsV2HighContrastRgba` is pulled in unless your app imports them explicitly.
- **SSR.** The CSS targets a DOM attribute, so the first paint is correct as long as `TUXApp` renders with the right `highContrastColors` value during SSR.

## Enabling high contrast

Two pieces must be wired up together at the app root. They are kept as two explicit inputs so that apps that never enable high contrast pay no bundle cost — neither the CSS bundle nor `colorsV2HighContrastRgba` is pulled in unless you reference it:

1. Import `@byted-tiktok/tux-web/colors-v2-high-contrast.css` alongside the base stylesheet.
2. Pass a color map to `TUXApp`'s `highContrastColors` prop — the single source of truth for whether high contrast is active.

<a id="enabling-high-contrast"></a>

```tsx
// app entry
import '@byted-tiktok/tux-web/styles.css';
import '@byted-tiktok/tux-web/colors-v2-high-contrast.css'; // IMPORTANT

import { TUXApp } from '@byted-tiktok/tux-web';
import { colorsV2HighContrastRgba } from '@byted-tiktok/tux-web/color';

const App = () => (
  <TUXApp
    theme="light"
    textDirection="ltr"
    platform="desktop"
    highContrastColors={colorsV2HighContrastRgba}
  >
    <YourApp />
  </TUXApp>
);
```

## Enabling high contrast

Passing the map turns high contrast **on** (CSS attribute + context override); passing `undefined` (or omitting the prop) turns it **off**. There is no separate boolean flag.

## Global toggle via `TUXApp`

<a id="global-toggle-via-tuxapp"></a>

```tsx
import { FC, useState } from 'react';
import { TUXApp, TUXButton, TUXText } from '@byted-tiktok/tux-web';
import { colorsV2HighContrastRgba } from '@byted-tiktok/tux-web/color';

const Example: FC = () => {
  const [enabled, setEnabled] = useState(false);

  return (
    <TUXApp
      theme="light"
      textDirection="ltr"
      platform="desktop"
      highContrastColors={enabled ? colorsV2HighContrastRgba : undefined}
    >
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBlockEnd: 12 }}>
        <TUXButton
          themePreset="primary"
          text={enabled ? 'Disable high contrast' : 'Enable high contrast'}
          onClick={() => setEnabled((prev) => !prev)}
        />
        <TUXText>high contrast: {enabled ? 'on' : 'off'}</TUXText>
      </div>
    </TUXApp>
  );
};

export default Example;
```

## Enabling high contrast

## Scoped toggle via `TUXConfigure`

<a id="scoped-toggle-via-tuxconfigure"></a>

```tsx
import { FC } from 'react';
import { TUXApp, TUXConfigure, TUXTag, TUXText } from '@byted-tiktok/tux-web';
import { colorsV2HighContrastRgba } from '@byted-tiktok/tux-web/color';

const Tags: FC = () => (
  <div style={{ display: 'flex', gap: 8 }}>
    <TUXTag text="Label" textSizePreset="H3" themePreset="primary" />
    <TUXTag text="Label" textSizePreset="H3" themePreset="neutral" />
    <TUXTag text="Label" textSizePreset="H3" themePreset="subtle" />
    <TUXTag text="Label" textSizePreset="H3" themePreset="overlayWhite" />
    <TUXTag text="Label" textSizePreset="H3" themePreset="overlayGray" />
  </div>
);

const Example: FC = () => (
  <TUXApp theme="light" textDirection="ltr" platform="desktop">
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        <TUXText typographyPreset="P2-Regular">Outside TUXConfigure — base palette</TUXText>
        <Tags />
      </div>

      <TUXConfigure highContrastColors={colorsV2HighContrastRgba}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <TUXText typographyPreset="P2-Regular">Inside TUXConfigure — scoped high contrast palette</TUXText>
          <Tags />
        </div>
      </TUXConfigure>
    </div>
  </TUXApp>
);

export default Example;
```

## Following the system preference

Most apps tie the flag to `prefers-contrast: more`. `tux-web` ships `useSystemHighContrast` so you can wire it up in one line — it subscribes to the media query and cleans up automatically:

<a id="following-the-system-preference"></a>

```tsx
import { TUXApp, useSystemHighContrast } from '@byted-tiktok/tux-web';
import { colorsV2HighContrastRgba } from '@byted-tiktok/tux-web/color';

const App = () => {
  const isHighContrast = useSystemHighContrast();

  return (
    <TUXApp
      theme="light"
      textDirection="ltr"
      platform="desktop"
      highContrastColors={isHighContrast ? colorsV2HighContrastRgba : undefined}
    >
      <YourApp />
    </TUXApp>
  );
};
```

## Reading the merged colors at runtime

When you read TUX color tokens **from JavaScript**, always go through the context so the value tracks high contrast:

<a id="reading-the-merged-colors-at-runtime"></a>

```tsx
import { useColor, getColorCSSVarFromMap, getTokenRgbaFromMap, useTheme } from '@byted-tiktok/tux-web';

const Example = () => {
  const colors = useColor();
  const { theme } = useTheme();

  const textVar = getColorCSSVarFromMap('UITextPrimary', colors);
  const textRgba = getTokenRgbaFromMap('UITextPrimary', theme, colors);

  return <span style={{ color: textVar }}>Lorem ipsum</span>;
};
```
