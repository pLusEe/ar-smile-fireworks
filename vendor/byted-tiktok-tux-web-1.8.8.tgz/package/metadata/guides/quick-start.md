<!-- tux-web · guides/quick-start -->
> **TUX guide — quick-start** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/quick-start)

# Introduction

TUX WEB is a brand new component library that replace the old TUX component libraries `@byted-tiktok/tux-components` and `@byted-tiktok/tux-pc` with better UX support and features.

## Installation

_See example: [Installation](#installation)_

## Setup

1. Import the the tux CSS in the root file of your project, after any CSS reset you may be applying.

_See example: [Setup](#setup)_

2.  Set react type in your `tsconfig.json`

_See example: [Setup](#setup-1)_

3. Wrap your app with `TUXApp`

_See example: [Setup](#setup-2)_

4. Then you can start use TUX Components in your app.

## Installation

<a id="installation"></a>

```tsx
npm i @byted-tiktok/tux-web@latest
```

## Setup

1. Import the the tux CSS in the root file of your project, after any CSS reset you may be applying.

<a id="setup"></a>

```tsx
import "@byted-tiktok/tux-web/styles.css";
```

## Setup

2.  Set react type in your `tsconfig.json`

<a id="setup-1"></a>

```tsx
{
  ...,
  "compilerOptions": {
    ...,
    "paths": {
      ...,
      // change the [version] to the major version you want to use, like react@18
      "react": ["./node_modules/@types/react@[version]"],
      "react-dom": ["./node_modules/@types/react-dom@[version]"]
    }
  }
}
```

## Setup

3. Wrap your app with `TUXApp`

<a id="setup-2"></a>

```tsx
import { TUXApp } from '@byted-tiktok/tux-web';

<TUXApp theme="light" textDirection="ltr" platform="desktop">
  <YourApp />
</TUXApp>
```
