<!-- tux-web · components/horizontal-steps/examples -->
> **TUX `horizontal-steps` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/horizontal-steps)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { IconTruckMovingFillLTR } from '@byted-tiktok/tux-icons';
import { TUXHorizontalSteps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const items = [
    { text: 'Step 1' },
    { text: 'Step 2' },
    { text: 'Step 3', icon: <IconTruckMovingFillLTR /> },
    { text: 'Step 4' },
    { text: 'Step 5' },
  ];
  return <TUXHorizontalSteps items={items} current={2} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { IconTruckMovingFillLTR } from '@byted-tiktok/tux-icons';
import { TUXHorizontalSteps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const items = [
    { text: 'Step 1' },
    { text: 'Step 2' },
    { text: 'Step 3', icon: <IconTruckMovingFillLTR /> },
    { text: 'Step 4' },
    { text: 'Step 5' },
  ];
  return (
    <TUXHorizontalSteps
      items={items}
      current={2}
      completedStrokeColor="UIShapePrimary"
      completedDotColor="UIShapeSuccess"
      incompleteStrokeColor="UIShapePrimary4"
      incompleteDotColor="UIShapeSuccess3"
    />
  );
};

export default Example;
```
