<!-- tux-web · components/horizontal-steps/props -->
> **TUX `horizontal-steps` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/horizontal-steps)

## `TUXHorizontalSteps` props _(version: v1)_

_Props type: `TUXHorizontalStepsProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TTUXHorizontalStepItem[]` |  | Items of the horizontal step panel. |
| `current` | `number` |  | Index of the current step. |
| `showDot?` | `boolean` | `true` | Whether to show the dot or not. If false, only shows current dot. |
| `showText?` | `boolean` | `true` | Whether to show the text or not. |
| `completedDotColor?` | `TColorWithToken` |  | Custom node dot color(completed node). |
| `incompleteDotColor?` | `TColorWithToken` |  | Custom node dot color(incomplete node). |
| `completedStrokeColor?` | `TColorWithToken` |  | Custom stroke color(completed node). |
| `incompleteStrokeColor?` | `TColorWithToken` |  | Custom stroke color(incomplete node). |
| `itemWidth?` | `string` |  | Custom item width of each step item. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `completedDotColor`, `incompleteDotColor`, `completedStrokeColor`, `incompleteStrokeColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TTUXHorizontalStepItem`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | Text of the horizontal step item. |
| `icon?` | `React.ReactNode` |  | Icon of the horizontal step item. (Will only be rendered when the step is current.) |
