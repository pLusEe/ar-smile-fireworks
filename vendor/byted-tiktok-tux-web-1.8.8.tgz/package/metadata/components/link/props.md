<!-- tux-web · components/link/props -->
> **TUX `link` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/link)

## `TUXLink` props _(version: v1)_

_Props type: `TUXLinkProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text` | `string` |  | Text to be displayed in the link |
| `leadingIcon?` | `React.ReactNode` |  | Icon to be displayed before the text |
| `trailingIcon?` | `React.ReactNode` |  | Icon to be displayed after the text |
| `href?` | `string` |  | Link URL |
| `onClick?` | `(e: React.MouseEvent<HTMLAnchorElement>) => void` |  | Callback function when the link is clicked |
| `typographyPreset?` | `TTUXTypographyPreset` |  | Typography preset of the link. Controls both the text style and paired icon size. |
| `size?` | `number` |  | Custom size of the link |
| `weight?` | `number` |  | Custom font weight of the link |
| `colorPreset?` | `TTUXLinkColorPreset` |  | Preset color of the link. |
| `color?` | `TColorWithToken` |  | Custom color of the link. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `disabled?` | `boolean` |  | Whether the link is disabled |
| `display?` | `'block' \| 'inline'` |  | Display type of the link |
| `hoveredColor?` | `TColorWithToken` |  | Text color to be displayed when the link is hovered. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |

_Also extends: `TPropsWithoutCustomStyle<React.AnchorHTMLAttributes<HTMLAnchorElement>>`_

#### Detailed notes

> `typographyPreset` — @remarks
>
> Format is `{Size}-{Weight}` (e.g., `'P1-Regular'` = 14px regular with 14px icon,
> `'H1-Bold'` = 24px bold with 24px icon). See TTUXTypographyPreset for the
> full list of valid combinations and their font sizes.

> `typographyPreset` — TTUXTypographyPreset
>
> Valid typography preset combinations in `{Size}-{Weight}` format.
> 
> Combines a size preset with a weight preset (e.g., `'H1-Bold'`, `'P1-Regular'`).
> Not all combinations are valid:
> - Body/small sizes (P1–P3, SmallText1–2) do **not** support `Bold`
> - Large sizes (H1, LargeTitle) do **not** support `Regular`
> 
> Common presets and their visual meaning:
> - `'H1-Bold'` — 24px bold, for top-level headings
> - `'H2-Semibold'` — 20px semibold, for section headings
> - `'H3-Semibold'` — 17px semibold, for sub-headings
> - `'Headline-Semibold'` — 16px semibold, for emphasized inline text
> - `'Headline-Regular'` — 16px regular, for standard inline text at headline size
> - `'P1-Regular'` — 14px regular, standard body text
> - `'P2-Regular'` — 13px regular, secondary body text
> - `'SmallText1-Regular'` — 11px regular, captions and labels

> `colorPreset` — @remarks
>
> - `primary` — UIText1 (standard text color)
> - `secondary` — UIText2 (muted text color)
> - `tertiary` — UIText3 (subtle text color)
> - `highlight` — UITextPrimaryDisplay (brand color)
> - `info` — UITextInfo (info color)

> `color`, `hoveredColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
