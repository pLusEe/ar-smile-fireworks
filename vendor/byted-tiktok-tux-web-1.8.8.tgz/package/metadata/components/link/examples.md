<!-- tux-web · components/link/examples -->
> **TUX `link` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/link)

## Example example-1

<a id="example-1"></a>

```tsx
import { TUXLink } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return <TUXLink text="basic link" href="https://example.com" typographyPreset="P1-Regular" />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { TUXLink, TUXLinkProps } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const COLOR_PRESET: TUXLinkProps['colorPreset'][] = ['primary', 'secondary', 'tertiary', 'highlight', 'info'];
const Example: FC = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      {COLOR_PRESET.map((color) => (
        <TUXLink
          key={color}
          href="https://example.com"
          text={`${color} Link`}
          typographyPreset="P3-Semibold"
          colorPreset={color}
        />
      ))}
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { TUXLink } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return (
    <TUXLink
      text="basic link"
      href="https://example.com"
      typographyPreset="P1-Regular"
      colorPreset="highlight"
      disabled
    />
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { IconAutocut, IconPersonFill } from '@byted-tiktok/tux-icons';
import { TUXLink } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return (
    <TUXLink
      text="full link"
      href="https://example.com"
      onClick={() => console.log('click')}
      typographyPreset="P1-Semibold"
      display="block"
      colorPreset="info"
      leadingIcon={<IconPersonFill />}
      trailingIcon={<IconAutocut />}
    />
  );
};

export default Example;
```
