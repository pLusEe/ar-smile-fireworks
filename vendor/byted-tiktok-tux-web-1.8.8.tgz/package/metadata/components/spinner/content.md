<!-- tux-web · components/spinner/content -->
> **TUX `spinner` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/spinner)

_See example: [example example-1](./examples.md#example-1)_
