<!-- tux-web · components/spinner/props -->
> **TUX `spinner` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/spinner)

## `TUXSpinner` props _(version: v1)_

_Props type: `TUXSpinnerProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'small' \| 'medium' \| 'large' \| 'huge'` | `small` | Preset size of the spinner. |
| `thickness?` | `'regular' \| 'thin'` |  | Preset thickness of the spinner  @default "regular" |
| `size?` | `number` |  | Size of the spinner |
| `color?` | `TColorWithToken` |  | Custom color of the spinner. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `display?` | `'inline-block' \| 'block'` |  | Display type of the spinner |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `small` — 14px
> - `medium` — 20px
> - `large` — 32px
> - `huge` — 48px

> `color` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
