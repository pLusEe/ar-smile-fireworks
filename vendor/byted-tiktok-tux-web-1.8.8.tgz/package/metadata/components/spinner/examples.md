<!-- tux-web · components/spinner/examples -->
> **TUX `spinner` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/spinner)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXSpinner } from '@byted-tiktok/tux-web';

<TUXSpinner sizePreset="small" thickness="thin"/>
```
