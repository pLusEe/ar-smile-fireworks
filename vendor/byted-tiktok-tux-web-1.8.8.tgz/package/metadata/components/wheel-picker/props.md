<!-- tux-web · components/wheel-picker/props -->
> **TUX `wheel-picker` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/wheel-picker)

## `TUXWheelPickerColumn` props _(version: v1)_

_Props type: `TUXWheelPickerColumnProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` |  | Current value of the picker column |
| `onValueChange` | `(value: string) => void` |  | Callback fired when the selected value changes |
| `options` | `TUXWheelPickerOption[]` |  | Array of options to display in the wheel |
| `visibleItemsPerHalf?` | `number` |  | The number of options on the visible half of the wheel @default 5 |
| `unit?` | `string` |  | The unit of the wheel picker column |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `options` — TUXWheelPickerOption
>
> Represents a single option in the wheel picker

#### Referenced types

#### `TUXWheelPickerOption`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` |  | The value that will be returned when this option is selected |
| `content` | `ReactNode` |  | The content displayed for this option |

## `TUXWheelPickerWrapper` props _(version: v1)_

_Props type: `TUXWheelPickerWrapperProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `className?` | `string` |  | Additional CSS class name for the wheel picker wrapper |
| `children` | `ReactNode` |  | WheelPicker components to be rendered inside the wrapper |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

## `useDateWheelPicker` props _(version: v1)_

_Props type: `UseDateWheelPickerProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `initialDate` | `Date` |  | The initial date to display in the picker |
| `minDate` | `Date` |  | The minimum date that can be selected |
| `maxDate` | `Date` |  | The maximum date that can be selected |
| `use12HourTime?` | `boolean` |  | Whether to use 12-hour time format @default false |
