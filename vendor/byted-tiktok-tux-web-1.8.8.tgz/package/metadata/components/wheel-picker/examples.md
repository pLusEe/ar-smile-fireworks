<!-- tux-web · components/wheel-picker/examples -->
> **TUX `wheel-picker` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/wheel-picker)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXWheelPickerColumn, TUXWheelPickerWrapper, TUXText, TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const createArray = (length: number, add = 0): { value: string; content: string }[] =>
    Array.from({ length }, (_, i) => {
      const value = i + add;
      return {
        value: value.toString().padStart(2, '0'),
        content: value.toString().padStart(2, '0'),
      };
    });

  const hourOptions = createArray(12, 1);
  const minuteOptions = createArray(60);
  const meridiemOptions = [
    { value: 'AM', content: 'AM' },
    { value: 'PM', content: 'PM' },
  ];

  const [hour, setHour] = useState(hourOptions[0].value);
  const [minute, setMinute] = useState(minuteOptions[0].value);
  const [meridiem, setMeridiem] = useState(meridiemOptions[0].value);

  return (
    <>
      <TUXText typographyPreset="H1-Semibold">
        {hour}:{minute} {meridiem}
      </TUXText>
      <TUXWheelPickerWrapper>
        <TUXWheelPickerColumn options={hourOptions} value={hour} onValueChange={setHour} unit="Hour" />
        <TUXWheelPickerColumn options={minuteOptions} value={minute} onValueChange={setMinute} unit="Minute" />
        <TUXWheelPickerColumn options={meridiemOptions} value={meridiem} onValueChange={setMeridiem} />
      </TUXWheelPickerWrapper>
      <TUXButton
        text="Reset"
        onClick={() => {
          setHour(hourOptions[0].value);
          setMinute(minuteOptions[0].value);
          setMeridiem(meridiemOptions[0].value);
        }}
      />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React from 'react';
import {
  TUXText,
  TUXButton,
  TUXWheelPickerColumn,
  TUXWheelPickerWrapper,
  useDateWheelPicker,
} from '@byted-tiktok/tux-web';

// Date Range
const minDate = new Date(2022, 5, 5, 12, 5); // June 5, 2022 12:05 PM
const maxDate = new Date(2032, 10, 10, 22, 10); // November 10, 2032 10:10 PM

const DateWheelPickerExample = (): React.ReactElement => {
  const {
    year,
    month,
    day,
    hour,
    minute,
    meridiem,
    yearOptions,
    monthOptions,
    dayOptions,
    hourOptions,
    minuteOptions,
    meridiemOptions,
    onYearChange,
    onMonthChange,
    onDayChange,
    onHourChange,
    onMinuteChange,
    onMeridiemChange,
    date,
    setDate,
  } = useDateWheelPicker({
    initialDate: minDate,
    minDate,
    maxDate,
    use12HourTime: true,
  });

  return (
    <>
      <TUXText typographyPreset="H1-Semibold">
        {date.toDateString()} {date.toLocaleTimeString()}
      </TUXText>
      <TUXWheelPickerWrapper>
        <TUXWheelPickerColumn options={monthOptions} value={month} onValueChange={onMonthChange} />
        <TUXWheelPickerColumn options={dayOptions} value={day} onValueChange={onDayChange} />
        <TUXWheelPickerColumn options={yearOptions} value={year} onValueChange={onYearChange} />
        <TUXWheelPickerColumn options={hourOptions} value={hour} onValueChange={onHourChange} />
        <TUXWheelPickerColumn options={minuteOptions} value={minute} onValueChange={onMinuteChange} />
        <TUXWheelPickerColumn options={meridiemOptions} value={meridiem} onValueChange={onMeridiemChange} />
      </TUXWheelPickerWrapper>
      <TUXButton onClick={() => setDate(minDate)}>Reset</TUXButton>
    </>
  );
};

const Example = (): React.ReactElement => {
  return (
    <>
      <DateWheelPickerExample />
    </>
  );
};

export default Example;
```
