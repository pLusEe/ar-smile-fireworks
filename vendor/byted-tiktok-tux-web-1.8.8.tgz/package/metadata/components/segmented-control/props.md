<!-- tux-web · components/segmented-control/props -->
> **TUX `segmented-control` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/segmented-control)

## `TUXSegmentedControl` props _(version: v1)_

_Props type: `TUXSegmentedControlProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TUXSegmentedItemProps[]` |  | Array of segment props data. |
| `activeKey?` | `string` |  | Specify the current active segment by key. |
| `defaultActiveKey?` | `string` |  | Specify the initial active segment. |
| `sizePreset?` | `'tiny' \| 'small'` | `small` | Preset size of the segment. |
| `shapePreset?` | `'capsule' \| 'rectangle'` | `capsule` | Preset shape of the segment. |
| `fitContent?` | `boolean` | `true` | Whether the segment width to fit content instead of equal width. |
| `disabled?` | `boolean` | `false` | Whether the segment is disabled. |
| `width?` | `string` |  | Custom width of the segmented control. |
| `onChange?` | `(activeKey: string) => void` |  | Callback triggered when a segment is switched. |
| `onItemClick?` | `(event: React.MouseEvent<HTMLButtonElement>, key: string) => void` |  | Callback triggered when a segment is clicked. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `small` — 15px semibold text with 3px padding
> - `tiny` — 13px semibold text with 2px padding

> `shapePreset` — @remarks
>
> - `capsule` — fully rounded
> - `rectangle` — standard corners

#### Referenced types

#### `TUXSegmentedItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `itemKey` | `string` |  | Unique identifier for the segment. |
| `title?` | `string` |  | Title of the segment. |
| `subtitle?` | `string` |  | Subtitle of the segment, only available when sizePreset = "small". |
| `leading?` | `React.ReactNode` |  | Custom content before the title. |
| `trailing?` | `React.ReactNode` |  | Custom content after the title. |
| `disabled?` | `boolean` | `false` | Whether the segment is disabled. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
