<!-- tux-web · components/segmented-control/examples -->
> **TUX `segmented-control` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/segmented-control)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';
import { TUXSegmentedControl, TUXSegmentedItemProps } from '@byted-tiktok/tux-web';

const items: TUXSegmentedItemProps[] = [
  { itemKey: 'days', title: '60 days' },
  { itemKey: 'long', title: 'A really really long title' },
  { itemKey: 'icon', leading: <IconInfoCircle /> },
];

const Example: FC = () => {
  return <TUXSegmentedControl items={items} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC, useState } from 'react';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';
import { TUXSegmentedControl, TUXSegmentedItemProps } from '@byted-tiktok/tux-web';

const items: TUXSegmentedItemProps[] = [
  { itemKey: 'days', title: '60 days' },
  { itemKey: 'long', title: 'A really really long title' },
  { itemKey: 'icon', leading: <IconInfoCircle /> },
];

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXSegmentedControl items={items} sizePreset={'small'} shapePreset={'capsule'} />
      <TUXSegmentedControl items={items} sizePreset={'small'} shapePreset={'rectangle'} />
      <TUXSegmentedControl items={items} sizePreset={'tiny'} shapePreset={'capsule'} />
      <TUXSegmentedControl items={items} sizePreset={'tiny'} shapePreset={'rectangle'} />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC, useState } from 'react';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';
import { TUXSegmentedControl, TUXSegmentedItemProps } from '@byted-tiktok/tux-web';

const items: TUXSegmentedItemProps[] = [
  { itemKey: 'days', title: '60 days' },
  { itemKey: 'long', title: 'A really really long title' },
  { itemKey: 'icon', leading: <IconInfoCircle /> },
];

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXSegmentedControl items={items} fitContent />
      <TUXSegmentedControl items={items} fitContent={false} />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC, useState } from 'react';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';
import { TUXSegmentedControl, TUXSegmentedItemProps } from '@byted-tiktok/tux-web';

const items: TUXSegmentedItemProps[] = [
  { itemKey: 'days', title: '60 days' },
  { itemKey: 'long', title: 'A really really long title' },
  { itemKey: 'icon', leading: <IconInfoCircle /> },
];

const Example: FC = () => {
  const [activeKey, setActiveKey] = useState<string>(items[0].itemKey);

  return (
    <TUXSegmentedControl
      items={items}
      activeKey={activeKey}
      onChange={(key) => {
        setActiveKey(key);
      }}
    />
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import React, { FC } from 'react';
import { TUXSegmentedControl, TUXSegmentedItemProps } from '@byted-tiktok/tux-web';

const items: TUXSegmentedItemProps[] = [
  {
    itemKey: '30',
    title: '30 days',
    subtitle: 'Subtitle',
  },
  {
    itemKey: '60',
    title: '60 days',
    subtitle: 'Subtitle',
  },
  {
    itemKey: 'always',
    title: 'All-time',
    subtitle: 'Subtitle',
  },
];

const Example: FC = () => {
  return <TUXSegmentedControl items={items} shapePreset={'rectangle'} />;
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import React, { FC, useState } from 'react';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';
import { TUXSegmentedControl, TUXSegmentedItemProps } from '@byted-tiktok/tux-web';

const items: TUXSegmentedItemProps[] = [
  { itemKey: 'days', title: '60 days' },
  { itemKey: 'long', title: 'A really really long title' },
  { itemKey: 'icon', leading: <IconInfoCircle /> },
];

const Example: FC = () => {
  return <TUXSegmentedControl items={items} fitContent={false} width={'50%'} />;
};

export default Example;
```
