<!-- tux-web · components/pin/props -->
> **TUX `pin` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/pin)

## `TUXPin` props _(version: v1)_

_Props type: `TUXPinProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `inputType` | `'alphabetic' \| 'numeric' \| 'alphanumeric'` |  | The input type of the pin. |
| `values` | `string[]` |  | The input values of the pin. |
| `onChange` | `(     e:       \| React.ChangeEvent<HTMLInputElement>       \| React.KeyboardEvent<HTMLInputElement>       \| React.ClipboardEvent<HTMLInputElement>,     newValues: string[],   ) => void` |  | Triggers onChange when the input changes. |
| `disabled?` | `boolean` |  | Whether the pin is in a disabled(not interactive) state. |
| `invalid?` | `boolean` |  | Whether the pin is in an invalid state. |
| `mask?` | `boolean` |  | Whether to put the mask on the input or not. |
| `onComplete?` | `(value: string) => void` |  | Triggers onComplete when all the inputs are valid. |
| `fitContent?` | `boolean` | `true` | Whether the pin should hug its content. |
| `separatorMode?` | `'dash' \| 'gap'` |  | The separator mode of the pin. Set this and separatorIndex to apply the separator. |
| `separatorIndex?` | `number[]` |  | Where to apply the separator. Index starts from 0. |
