<!-- tux-web · components/pin/examples -->
> **TUX `pin` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/pin)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [values, setValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [alphaValues, setAlphaValues] = useState<string[]>(['', '', '', '', '', '']);
  const [numericValues, setNumericValues] = useState<string[]>(['', '', '', '', '', '']);
  const [alphanumericValues, setAlphanumericValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXPin
        inputType="alphabetic"
        values={alphaValues}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setAlphaValues(newValues);
        }}
      />
      <TUXPin
        inputType="numeric"
        values={numericValues}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setNumericValues(newValues);
        }}
      />
      <TUXPin
        inputType="alphanumeric"
        values={alphanumericValues}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setAlphanumericValues(newValues);
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [values, setValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
        disabled
      />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [values, setValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
        invalid
      />
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [values, setValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
        mask
      />
    </div>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [values, setValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
        fitContent={false}
      />
    </div>
  );
};

export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import { FC, useState } from 'react';
import { TUXPin } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [values, setValues] = useState<string[]>(['', '', '', '', '', '']);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
        separatorMode="dash"
        separatorIndex={[0, 2]}
      />
      <TUXPin
        inputType="numeric"
        values={values}
        onChange={(
          e: React.ChangeEvent<HTMLInputElement> | React.KeyboardEvent<HTMLInputElement>,
          newValues: string[],
        ) => {
          setValues(newValues);
        }}
        separatorMode="gap"
        separatorIndex={[0, 2]}
      />
    </div>
  );
};

export default Example;
```
