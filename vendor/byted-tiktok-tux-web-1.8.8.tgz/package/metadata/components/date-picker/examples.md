<!-- tux-web · components/date-picker/examples -->
> **TUX `date-picker` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/date-picker)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXDatePicker, TDateValue } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);

  return <TUXDatePicker value={value} onValueChange={setValue} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXDatePicker, TDateValue } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);

  return <TUXDatePicker mode="range" value={value} onValueChange={setValue} confirmText="OK" />;
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import { TUXDatePicker, TDateValue } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);
  const selectableDateRange: [Date, Date] = [new Date(2025, 0, 16), new Date(2025, 5, 20)];

  return (
    <TUXDatePicker
      value={value}
      onValueChange={setValue}
      selectableDateRange={selectableDateRange}
      disableDate={(date) => date.getDay() === 6}
    />
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC, useState } from 'react';
import { TUXDatePicker, TDateValue, TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);
  const customTrigger = <TUXButton text="Select Date" />;
  const renderFooter = ({ internalValue, setInternalValue, isInternalValueValid, setVisible }) => (
    <div style={{ display: 'flex', gap: '8px' }}>
      <div style={{ flex: 1 }}>
        <TUXButton themePreset="secondary" text="Reset" onClick={() => setInternalValue([])} width="100%" />
      </div>
      <div style={{ flex: 1 }}>
        <TUXButton
          text="Apply"
          disabled={!isInternalValueValid}
          onClick={() => {
            setVisible(false);
            setValue(internalValue);
          }}
          width="100%"
        />
      </div>
    </div>
  );

  return (
    <>
      {value?.[0]?.toDateString()}
      <br />
      <TUXDatePicker value={value} onValueChange={setValue} customTrigger={customTrigger} renderFooter={renderFooter} />
    </>
  );
};

export default Example;
```
