<!-- tux-web · components/date-picker/props -->
> **TUX `date-picker` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/date-picker)

## `TUXDatePicker` props _(version: v1)_

_Props type: `TUXDatePickerProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `formatTriggerValue?` | `(value: TDateValue) => string` |  | Customized the display string on the trigger element. |
| `confirmText?` | `string` | `'Confirm'` | Confirm button text. |
| `renderFooter?` | `(innerData: {     internalValue: TDateValue;     setInternalValue: (dateValue: TDateValue) => void;     isInternalValueValid: boolean;     visible: boolean;     setVisible: (visible: boolean) => void;   }) => React.ReactNode` |  | Customized the footer. |
| `customTrigger?` | `ReactElement` |  | Customized the trigger element. |
| `value` | `TDateValue` |  | confirmed value, which is [] \| [Date] \| [Date, Date]. |
| `disableDate?` | `(date: Date) => boolean` |  | The function to disable a date. |
| `onDayClick?` | `(e: React.MouseEvent<HTMLDivElement>, date: Date) => void` |  | The function to handle day click. |
| `mode?` | `'single' \| 'range'` | `'single'` | Date picker mode. |
| `onValueChange` | `(dateValue: TDateValue) => void` |  | Value change callback. |
| `selectableDateRange?` | `[Date, Date]` |  | Selectable date range. |
| `onConfirm?` | `(internalValue: TDateValue) => void` |  | Confirm callback. |
| `locale?` | `string` |  | The locale to use. |
| `showToday?` | `boolean` | `false` | Whether to show today. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus popover when open |
| `id?` | `string` |  | id of the popover, used to identify the popover when use together with other popover in same TUXFloatingRoot |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | Text direction of the popover |
| `visible?` | `boolean` | `false` | Whether the popover is open |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback when the popover is open or closed |
| `triggerMode?` | `TTriggerMode \| TTriggerMode[]` | `'click'` | Trigger mode, can be one of the following: 'click' \| 'hover' \| 'focus' |
| `placement?` | `TPopoverPlacement` | `'BlockStart'` | Placement of the popover relative to the trigger element, the value can be one of the following: 'BlockStart' \| 'BlockStart-Start' \| 'BlockStart-End' \| 'BlockEnd' \| 'BlockEnd-Start' \| 'BlockEnd-End' \| 'InlineStart' \| 'InlineStart-Start' \| 'InlineStart-End' \| 'InlineEnd' \| 'InlineEnd-Start' \| 'InlineEnd-End' |
| `root?` | `Parameters<typeof FloatingPortal>['0']['root']` | `null` | Root element of the popover, default is null, which means the popover will be rendered in the body element |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether to dismiss the popover when click outside |
| `autoFlip?` | `boolean` | `false` | Whether to flip the popover when it is out of the viewport |
| `matchTriggerWidth?` | `boolean` | `false` | Whether the popover width should match the trigger width. Takes precedence over `width`. |
| `minWidth?` | `string` |  | Custom minimum width of the popover. |
| `maxWidth?` | `string` |  | Custom maximum width of the popover. |
| `minHeight?` | `string` |  | Custom minimum height of the popover. |
| `maxHeight?` | `string` |  | Custom maximum height of the popover. |
| `zIndex?` | `number` | `2200` | Z-index of the popover |
| `offsetOptions?` | `OffsetOptions` |  | Offset between the trigger element and the popover |
| `theme?` | `TTUXContextValue['theme']` |  | Color theme of the popover |
| `platform?` | `TTUXContextValue['platform']` |  | Platform preset of the popover |
| `openDelay?` | `number` | `0` | Open delay duration(ms) when hovered. |
| `closeDelay?` | `number` | `0` | Close delay duration(ms) when hovered. |
| `safeArea?` | `{ x?: number; y?: number }` |  | Safe area at the edges of the screen, that the popover will not overlap with. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `triggerMode` — TTriggerMode
>
> Trigger interaction(s) that open a floating element such as a popover or
> tooltip. Pass an array to enable multiple triggers at once.
> 
> - `click` — opens on click of the trigger; closes on outside click
> - `hover` — opens while the pointer hovers over the trigger
> - `focus` — opens while the trigger has keyboard focus

> `placement` — TPopoverPlacement
>
> Logical placement of a floating element relative to its trigger.
> 
> Names use logical (writing-direction-aware) axes so the same value renders
> correctly under both LTR and RTL:
> - `Block*` — vertical axis. `BlockStart` is above the trigger;
>   `BlockEnd` is below.
> - `Inline*` — horizontal axis. `InlineStart` is the leading side
>   (left in LTR, right in RTL); `InlineEnd` is the trailing side.
> - Plain `BlockStart` / `BlockEnd` / `InlineStart` / `InlineEnd` center the
>   floating element along the cross axis of the trigger.
> - `-Start` / `-End` suffixes pin the floating element to the start or end of
>   the cross axis instead (e.g. `BlockEnd-Start` opens below the trigger,
>   aligned to its leading edge).

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
