<!-- tux-web · components/input/props -->
> **TUX `input` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/input)

## `TUXInput` props _(version: v1)_

_Props type: `TUXInputProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `large` | Preset sizes of the input, corresponding to different heights. |
| `value?` | `string` |  | Value of the input. Uses this prop with 'onChange' to make it in a controlled mode. |
| `defaultValue?` | `string` |  | Default initial value of the input. Uses this prop in an uncontrolled mode. |
| `onChange?` | `(e: React.ChangeEvent<HTMLInputElement>, value: string) => void` |  | Change event handler of the input. Uses this prop with 'value' to make it in a controlled mode. |
| `leading?` | `React.ReactNode` |  | Custom leading action area of the input. |
| `trailing?` | `React.ReactNode` |  | Custom trailing action area of the input. |
| `leadingIcon?` | `React.ReactNode` |  | Leading icon of the input. |
| `trailingIcon?` | `React.ReactNode` |  | Trailing icon of the input. |
| `leadingText?` | `string` |  | Leading text of the input. |
| `trailingText?` | `string` |  | Trailing text of the input. |
| `placeholder?` | `string` |  | A short hint that describes the expected value of the input. |
| `disabled?` | `boolean` |  | Whether the input is in a disabled(not interactive) state. |
| `showClearButton?` | `boolean` |  | Whether the input show a clear button or not. |
| `onClear?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Clear handler of the input. Triggers when the clear button is clicked. |
| `showMaskButton?` | `boolean` |  | Whether the input show a mask button or not. |
| `status?` | `'error' \| 'invalid' \| 'valid' \| 'validating'` |  | Status of the input. |
| `allowExceedMaxLength?` | `boolean` | `true` | Whether to allow the input characters to exceed the counter max length. |
| `width?` | `string` |  | Custom width of the input. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `message?` | `string` |  | Message of the input footer. |
| `maxLengthExceededMessage?` | `string` |  | Message displayed when counterLength exceeds counterMaxLength. |
| `messageIcon?` | `React.ReactNode` |  | Custom message icon of the input footer, if set to null, there is no message icon |
| `showCounter?` | `boolean` |  | Whether to show the counter or not. |
| `counterMaxLength?` | `number` |  | The max length of the input value for the counter. |

_Also extends: `TPropsWithoutCustomStyle<Omit<React.InputHTMLAttributes<HTMLInputElement>, 'children' | 'onChange'>>`_

#### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 28px height
> - `small` — 32px height
> - `medium` — 40px height
> - `large` — 48px height

## `TUXInputIconAction` props _(version: v1)_

_Props type: `TUXInputIconActionProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `icon` | `React.ReactNode` |  | Icon displayed in the action button. |
| `sizePreset` | `'tiny' \| 'small' \| 'medium' \| 'large'` |  | Preset sizes of the input action, matching the sibling input's `sizePreset`. |
| `color?` | `TColorWithToken` |  | Custom color of the icon. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> Controls the action button's outer touch target and icon size:
> - `tiny` — 20×20px button, 14px icon
> - `small` — 24×24px button, 16px icon
> - `medium` — 30×30px button, 20px icon
> - `large` — 30×30px button, 20px icon (same as `medium`)

> `color` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

## Additional exports



## `TUXInputLike` props

_Props type: `TUXInputLikeProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `large` | Preset sizes of the input, corresponding to different heights. |
| `value?` | `string` |  | Value of the input. Uses this prop with 'onChange' to make it in a controlled mode. |
| `leadingIcon?` | `React.ReactNode` |  | Leading icon of the input. |
| `trailingIcon?` | `React.ReactNode` |  | Trailing icon of the input. |
| `leadingText?` | `string` |  | Leading text of the input. |
| `trailingText?` | `string` |  | Trailing text of the input. |
| `disabled?` | `boolean` |  | Whether the input is in a disabled(not interactive) state. |
| `invalid?` | `boolean` |  | Whether the input is in an error state. |
| `activeMode?` | `'opacity' \| 'overlay'` |  | Controls the active mode. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

_Also extends: `Omit<React.HTMLAttributes<HTMLDivElement>, 'children'>`_

### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 28px height
> - `small` — 32px height
> - `medium` — 40px height
> - `large` — 48px height
