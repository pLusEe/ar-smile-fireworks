<!-- tux-web · components/input/examples -->
> **TUX `input` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/input)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXInput } from '@byted-tiktok/tux-web';

<div style={{ display: 'flex', width: '200px' }}>
  <TUXInput defaultValue="" />
</div>
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXInput } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXInput defaultValue="" sizePreset="tiny" />
      <TUXInput defaultValue="" sizePreset="small" />
      <TUXInput defaultValue="" sizePreset="medium" />
      <TUXInput defaultValue="" sizePreset="large" />
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXInput } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', width: '200px' }}>
      <TUXInput defaultValue="" disabled />
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXInput } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', width: '200px' }}>
      <TUXInput defaultValue="" showClearButton />
    </div>
  );
};
export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXInput } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', width: '200px' }}>
      <TUXInput defaultValue="" showMaskButton />
    </div>
  );
};
export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXInput } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXInput defaultValue="" status="error" />
      <TUXInput defaultValue="" status="invalid" />
      <TUXInput defaultValue="" status="valid" />
      <TUXInput defaultValue="" status="validating" />
    </div>
  );
};
export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import { FC, useState } from 'react';
import { TUXInput, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<string>('');
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Uncontrolled Mode</TUXText>
        <TUXInput defaultValue="" />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Controlled Mode</TUXText>
        <TUXInput
          value={value}
          onChange={(e: React.ChangeEvent<HTMLInputElement>, inputValue: string) => {
            setValue(inputValue);
            console.log(inputValue);
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-8

<a id="example-8"></a>

```tsx
import { FC } from 'react';
import { TUXInput, TUXInputIconAction } from '@byted-tiktok/tux-web';
import {
  IconBellFill,
  IconBookmarkFill,
  IconBubbleEllipsisRightFill,
  IconFacebookCircle,
} from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', width: '500px' }}>
      <TUXInput
        defaultValue=""
        leading={<TUXInputIconAction icon={<IconFacebookCircle />} sizePreset="large" />}
        trailing={
          <div style={{ display: 'flex' }}>
            <TUXInputIconAction icon={<IconBellFill />} sizePreset="large" />
            <TUXInputIconAction icon={<IconBookmarkFill />} sizePreset="large" />
            <TUXInputIconAction icon={<IconBubbleEllipsisRightFill />} sizePreset="large" />
          </div>
        }
      />
    </div>
  );
};
export default Example;
```

## Example example-9

<a id="example-9"></a>

```tsx
import { FC, useState } from 'react';
import { TUXInput } from '@byted-tiktok/tux-web';
import { IconExclamationMarkTriangleInline } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [value, setValue] = useState<string>('');
  return (
    <div style={{ display: 'flex', width: '200px' }}>
      <TUXInput
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
        }}
        message="Message here"
        maxLengthExceededMessage="Word count exceeded limit"
        messageIcon={<IconExclamationMarkTriangleInline />}
        showCounter
        counterMaxLength={25}
      />
    </div>
  );
};

export default Example;
```
