<!-- tux-web · components/intro-panel/props -->
> **TUX `intro-panel` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/intro-panel)

## `TUXIntroPanel` props _(version: v1)_

_Props type: `TUXIntroPanelProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether clicking the overlay closes the intro panel. |
| `height?` | `string` |  | Custom height of the intro panel. |
| `maxHeight?` | `string` |  | Custom maximum height of the intro panel. |
| `width?` | `string` |  | Width of the intro panel. |
| `zIndex?` | `number` | `2100` | Z-index of the intro panel. |
| `overlayVisible?` | `boolean` | `true` | Whether to make the overlay visible or not. |
| `platform?` | `TTUXContextValue['platform']` |  | Platform preset of the intro panel. |
| `showCloseButton?` | `boolean` | `false` | Whether to have close button or not. |
| `closeButtonColor?` | `TColorWithToken` |  | Custom color of the close button. |
| `onClose?` | `(e: React.MouseEvent<HTMLElement>) => void` |  | The handler of dismiss event, used in close button. |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `closeButtonColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
