<!-- tux-web · components/intro-panel/examples -->
> **TUX `intro-panel` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/intro-panel)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXIntroPanel } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Intro Panel"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXIntroPanel visible={visible} onVisibleChange={setVisible}>
        <div
          style={{
            height: '400px',
          }}
        />
      </TUXIntroPanel>
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXIntroPanel } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Intro Panel"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXIntroPanel
        visible={visible}
        onVisibleChange={setVisible}
        showCloseButton
        onClose={() => {
          setVisible(false);
          console.log('close button click');
        }}
      >
        <div
          style={{
            height: '400px',
          }}
        />
      </TUXIntroPanel>
    </>
  );
};

export default Example;
```
