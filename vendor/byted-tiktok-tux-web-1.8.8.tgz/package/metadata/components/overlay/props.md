<!-- tux-web · components/overlay/props -->
> **TUX `overlay` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md)

## `TUXOverlay` props

_Props type: `TUXOverlayProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `id` | `string` |  | The id of the overlay. |
| `floatingContext` | `UseFloatingReturn['context']` |  | The context shared with the floating children. |
| `children` | `React.ReactElement` |  | The content of the overlay. |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether closes the overlay when clicking inside. |
| `lockScroll?` | `boolean` | `true` |  |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
