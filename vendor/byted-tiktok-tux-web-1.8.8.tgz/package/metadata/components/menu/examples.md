<!-- tux-web · components/menu/examples -->
> **TUX `menu` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/menu)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXMenu, TUXMenuProps } from '@byted-tiktok/tux-web';
import { IconArrowDoubleDirectionCircle, IconPersonFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const menuItems: TUXMenuProps['items'] = [
    {
      type: 'group',
      groupTitle: 'Account',
      groupItems: [
        {
          type: 'item',
          text: 'Profile',
          leadingIcon: <IconPersonFill />,
          trailingIcon: <IconArrowDoubleDirectionCircle />,
          onClick: () => console.log('first'),
        },
        {
          type: 'item',
          text: 'Settings',
          onClick: () => console.log('second'),
        },
      ],
    },
    {
      type: 'item',
      text: 'option 1',
      onClick: () => console.log('Edit clicked'),
    },
    {
      type: 'item',
      text: 'option 2',
      onClick: () => console.log('Delete clicked'),
    },
  ];

  return <TUXMenu items={menuItems} trigger={<TUXButton>Click me</TUXButton>} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXMenu, TUXMenuProps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const menuItems: TUXMenuProps['items'] = [
    {
      type: 'item',
      text: 'This is a very long menu item that will be truncated, long long long',
      onClick: () => console.log('Edit clicked'),
      textDisplay: 'truncate',
    },
    {
      type: 'item',
      text: 'This is a very long menu item that will be break into two lines',
      onClick: () => console.log('Delete clicked'),
      textDisplay: 'lineBreak',
    },
  ];

  return <TUXMenu items={menuItems} trigger={<TUXButton>Click me</TUXButton>} />;
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXMenu, TUXMenuProps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const menuItems: TUXMenuProps['items'] = [
    {
      type: 'group',
      groupTitle: 'Account',
      configForAll: {
        themePreset: 'normal',
      },
      groupItems: [
        {
          type: 'item',
          text: 'Profile',
          onClick: () => {},
        },
        {
          type: 'item',
          text: 'Settings',
          onClick: () => {},
        },
      ],
    },
    {
      type: 'item',
      text: 'option 1',
      onClick: () => console.log('Edit clicked'),
    },
    {
      type: 'item',
      text: 'option 2',
      onClick: () => console.log('Delete clicked'),
      disabled: true,
    },
  ];

  return (
    <TUXMenu
      items={menuItems}
      trigger={<TUXButton>Click me</TUXButton>}
      configForAll={{
        showSeparator: true,
        themePreset: 'destructive',
      }}
    />
  );
};

export default Example;
```
