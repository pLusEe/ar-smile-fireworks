<!-- tux-web · components/menu/props -->
> **TUX `menu` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/menu)

## `TUXMenu` props _(version: v1)_

_Props type: `TUXMenuProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `Array<TUXMenuItemProps \| TUXMenuItemGroupProps>` |  | items of the menu |
| `configForAll?` | `TConfigForAll` |  | config for all items in the menu |
| `maxHeight?` | `string` |  | set max height of the menu |
| `placement?` | `TPopoverPlacement` | `'BlockEnd-Start'` | where to place the menu |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus popover when open |
| `id?` | `string` |  | id of the popover, used to identify the popover when use together with other popover in same TUXFloatingRoot |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | Text direction of the popover |
| `visible?` | `boolean` | `false` | Whether the popover is open |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback when the popover is open or closed |
| `width?` | `string` |  | Custom width of the popover |
| `showArrow?` | `boolean` | `false` | Whether to show arrow |
| `trigger?` | `ReactElement` |  | Trigger element |
| `triggerMode?` | `TTriggerMode \| TTriggerMode[]` | `'click'` | Trigger mode, can be one of the following: 'click' \| 'hover' \| 'focus' |
| `root?` | `Parameters<typeof FloatingPortal>['0']['root']` | `null` | Root element of the popover, default is null, which means the popover will be rendered in the body element |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether to dismiss the popover when click outside |
| `autoFlip?` | `boolean` | `false` | Whether to flip the popover when it is out of the viewport |
| `matchTriggerWidth?` | `boolean` | `false` | Whether the popover width should match the trigger width. Takes precedence over `width`. |
| `minWidth?` | `string` |  | Custom minimum width of the popover. |
| `maxWidth?` | `string` |  | Custom maximum width of the popover. |
| `minHeight?` | `string` |  | Custom minimum height of the popover. |
| `zIndex?` | `number` | `2200` | Z-index of the popover |
| `offsetOptions?` | `OffsetOptions` |  | Offset between the trigger element and the popover |
| `theme?` | `TTUXContextValue['theme']` |  | Color theme of the popover |
| `platform?` | `TTUXContextValue['platform']` |  | Platform preset of the popover |
| `openDelay?` | `number` | `0` | Open delay duration(ms) when hovered. |
| `closeDelay?` | `number` | `0` | Close delay duration(ms) when hovered. |
| `safeArea?` | `{ x?: number; y?: number }` |  | Safe area at the edges of the screen, that the popover will not overlap with. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `placement` — TPopoverPlacement
>
> Logical placement of a floating element relative to its trigger.
> 
> Names use logical (writing-direction-aware) axes so the same value renders
> correctly under both LTR and RTL:
> - `Block*` — vertical axis. `BlockStart` is above the trigger;
>   `BlockEnd` is below.
> - `Inline*` — horizontal axis. `InlineStart` is the leading side
>   (left in LTR, right in RTL); `InlineEnd` is the trailing side.
> - Plain `BlockStart` / `BlockEnd` / `InlineStart` / `InlineEnd` center the
>   floating element along the cross axis of the trigger.
> - `-Start` / `-End` suffixes pin the floating element to the start or end of
>   the cross axis instead (e.g. `BlockEnd-Start` opens below the trigger,
>   aligned to its leading edge).

> `triggerMode` — TTriggerMode
>
> Trigger interaction(s) that open a floating element such as a popover or
> tooltip. Pass an array to enable multiple triggers at once.
> 
> - `click` — opens on click of the trigger; closes on outside click
> - `hover` — opens while the pointer hovers over the trigger
> - `focus` — opens while the trigger has keyboard focus

#### Referenced types

#### `TUXMenuItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `type` | `'item'` |  | use to identify the menu item |
| `text` | `string` |  | text of the menu item |
| `textDisplay?` | `'truncate' \| 'lineBreak'` | `'truncate'` | text overflow strategy |
| `leadingIcon?` | `React.ReactNode` |  | leading icon of the menu item |
| `leading?` | `React.ReactNode` |  | leading custom element of the menu item |
| `trailingIcon?` | `React.ReactNode` |  | trailing icon of the menu item |
| `trailing?` | `React.ReactNode` |  | trailing custom element of the menu item |
| `disabled?` | `boolean` |  | whether the menu item is disabled |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | click event of the menu item |
| `themePreset?` | `'normal' \| 'destructive'` | `'normal'` | theme preset of the menu item |
| `showSeparator?` | `boolean` |  | whether show separator under this item |
| `preventCloseOnClick?` | `boolean` | `false` | prevent close menu when click |

> `themePreset` — @remarks
>
> - `normal` — neutral foreground color (`UIText1`), for standard menu items
> - `destructive` — danger foreground color (`UITextDangerDisplay`), for destructive or irreversible menu items

#### `TUXMenuItemGroupProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `type` | `'group'` |  | use to identify the menu group |
| `groupTitle` | `string` |  | title of the menu group |
| `groupItems` | `TUXMenuItemProps[]` |  | items of the menu group |
| `showSeparator?` | `boolean` | `true` | use to control separator showing under the menu group |
| `configForAll?` | `TConfigForAll` |  | config for all items in the menu group |

#### `TConfigForAll`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `showSeparator?` | `TUXMenuItemProps['showSeparator']` |  | whether show separator |
| `textDisplay?` | `TUXMenuItemProps['textDisplay']` |  | text overflow strategy |
| `themePreset?` | `TUXMenuItemProps['themePreset']` |  | theme preset |
| `disabled?` | `TUXMenuItemProps['disabled']` |  | whether the menu item is disabled |
| `preventCloseOnClick?` | `boolean` |  | prevent close menu when click |

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
