<!-- tux-web · components/radio/props -->
> **TUX `radio` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/radio)

## `TUXRadio` props _(version: v1)_

_Props type: `TUXRadioProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'large' \| 'small'` | `large` | Preset sizes of the radio. |
| `name` | `string` |  | Name of the data that the radio is associated with. Radios with the same name are grouped and control the same set of data. |
| `value` | `string` |  | Value that the radio option represents. This should be unique for all radios with the same name. |
| `id?` | `string` |  | Identifier for the radio input. |
| `checked?` | `boolean` |  | Controls the checking state of the radio. Uses this prop with 'onChange' to make it in a controlled mode. |
| `defaultChecked?` | `boolean` |  | Controls the default checking state of the radio. Uses this prop in an uncontrolled mode. |
| `onChange?` | `(e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void` |  | Change event handler of the radio. Uses this prop with 'checked' to make it in a controlled mode. |
| `disabled?` | `boolean` |  | Whether the radio is in a disabled(not interactive) state. |
| `invalid?` | `boolean` |  | Whether the radio is in an error state. |
| `backgroundColor?` | `TColorWithToken` |  | Custom background color of the radio when checked. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `display?` | `'inline-block' \| 'block'` |  | Whether the radio is displayed as a block element. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `large` — 22px
> - `small` — 16px

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
