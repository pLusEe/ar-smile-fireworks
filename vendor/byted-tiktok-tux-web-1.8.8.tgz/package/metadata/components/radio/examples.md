<!-- tux-web · components/radio/examples -->
> **TUX `radio` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/radio)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXRadio, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const options = ['blue', 'green', 'red', 'yellow'];
  const [checkedItem, setCheckedItem] = useState<string>();
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    if (e.target.checked) {
      setCheckedItem(e.target.value);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', padding: '16px' }}>
      <TUXText typographyPreset="H3-Semibold">Select your favorite color</TUXText>
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          paddingInlineStart: '16px',
          paddingBlockStart: '5px',
        }}
      >
        {options.map((option) => (
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }} key={option}>
            <TUXRadio name="color" value={option} checked={checkedItem === option} onChange={handleChange} />
            <TUXText typographyPreset="H4-Semibold">{option}</TUXText>
          </div>
        ))}
      </div>
    </div>
  );
};
export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXRadio } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXRadio name="category" value="category_item" defaultChecked={false} sizePreset="large" />
      <TUXRadio name="category" value="category_item" defaultChecked={false} sizePreset="small" />
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXRadio } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXRadio name="category" value="category_item" defaultChecked={false} disabled />
      <TUXRadio name="category" value="category_item" defaultChecked disabled />
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXRadio } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXRadio name="category" value="category_item" defaultChecked={false} invalid />
    </div>
  );
};
export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC, useState } from 'react';
import { TUXRadio, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [checked, setChecked] = useState<boolean>(false);
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Uncontrolled Mode</TUXText>
        <TUXRadio name="category" value="category_item" defaultChecked={false} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Controlled Mode</TUXText>
        <TUXRadio
          name="category"
          value="category_item"
          checked={checked}
          onChange={(e) => {
            setChecked(e.target.checked);
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXRadio } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXRadio name="category" value="category_item" defaultChecked backgroundColor={'UITextSuccess'} />
      <TUXRadio name="category" value="category_item" defaultChecked backgroundColor={'UIShapeWarning'} />
    </div>
  );
};
export default Example;
```
