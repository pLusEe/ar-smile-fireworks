<!-- tux-web · components/icon-button/examples -->
> **TUX `icon-button` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/icon-button)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXIconButton } from '@byted-tiktok/tux-web';
import { IconThumbsUpFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXIconButton icon={<IconThumbsUpFill />} sizePreset="medium" />
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXIconButton } from '@byted-tiktok/tux-web';
import { IconThumbsUpFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <TUXIconButton icon={<IconThumbsUpFill />} sizePreset="tiny" />
      <TUXIconButton icon={<IconThumbsUpFill />} sizePreset="small" />
      <TUXIconButton icon={<IconThumbsUpFill />} sizePreset="medium" />
      <TUXIconButton icon={<IconThumbsUpFill />} sizePreset="large" />
      <TUXIconButton icon={<IconThumbsUpFill />} sizePreset="huge" />
    </div>
  );
};

export default Example;
```
