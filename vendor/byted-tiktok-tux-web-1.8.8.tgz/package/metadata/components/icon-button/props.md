<!-- tux-web · components/icon-button/props -->
> **TUX `icon-button` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/icon-button)

## `TUXIconButton` props _(version: v1)_

_Props type: `TUXIconButtonProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large' \| 'huge'` | `tiny` | Preset sizes of the icon button. |
| `icon` | `React.ReactNode` |  | Icon to be displayed in the middle of the icon button. |
| `disabled?` | `boolean` |  | Whether the icon button is in a disabled(not interactive) state. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click handler of the icon button. |
| `size?` | `number` |  | Size of the icon button. |
| `backgroundColor?` | `TColorWithToken` | `UIShapeNeutral4` | Background color of the icon button. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 20px button / 10px icon
> - `small` — 24px button / 12px icon
> - `medium` — 36px button / 17px icon
> - `large` — 56px button / 24px icon
> - `huge` — 64px button / 27px icon

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
