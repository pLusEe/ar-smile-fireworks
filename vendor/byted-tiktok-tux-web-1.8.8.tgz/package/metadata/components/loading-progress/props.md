<!-- tux-web · components/loading-progress/props -->
> **TUX `loading-progress` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/loading-progress)

## `TUXLoadingProgress` props _(version: v1)_

_Props type: `TUXLoadingProgressProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `tiny` | Preset size of the loading progress. |
| `progress` | `number` |  | The progress number of the loading progress( should between 0-100 ) |
| `progressColor?` | `TColorWithToken` | `UIShapeNeutral` | Custom progress stroke color of the loading progress. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 36px diameter
> - `small` — 48px diameter
> - `medium` — 64px diameter
> - `large` — 96px diameter

> `progressColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
