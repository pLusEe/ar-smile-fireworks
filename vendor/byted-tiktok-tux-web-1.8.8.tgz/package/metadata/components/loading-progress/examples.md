<!-- tux-web · components/loading-progress/examples -->
> **TUX `loading-progress` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/loading-progress)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXLoadingProgress } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <>
      <TUXLoadingProgress progress={40} />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXLoadingProgress } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXLoadingProgress progress={40} sizePreset="tiny" />
      <TUXLoadingProgress progress={50} sizePreset="small" />
      <TUXLoadingProgress progress={60} sizePreset="medium" />
      <TUXLoadingProgress progress={70} sizePreset="large" />
    </div>
  );
};

export default Example;
```
