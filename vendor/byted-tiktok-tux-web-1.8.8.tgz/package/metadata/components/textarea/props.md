<!-- tux-web · components/textarea/props -->
> **TUX `textarea` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/text-area)

## `TUXTextArea` props _(version: v1)_

_Props type: `TUXTextAreaProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `value?` | `string` |  | Value of the textarea. Uses this prop with 'onChange' to make it in a controlled mode. |
| `defaultValue?` | `string` |  | Default initial value of the textarea. Uses this prop in an uncontrolled mode. |
| `onChange?` | `(e: React.ChangeEvent<HTMLTextAreaElement>, value: string) => void` |  | Change event handler of the textarea. Uses this prop with 'value' to make it in a controlled mode. |
| `placeholder?` | `string` |  | A short hint that describes the expected value of the textarea. |
| `disabled?` | `boolean` |  | Whether the textarea is in a disabled(not interactive) state. |
| `invalid?` | `boolean` |  | Whether the textarea is in an error state. |
| `trailing?` | `React.ReactNode` |  | Custom trailing area of the textarea. |
| `autoSize?` | `boolean` | `true` | Whether the textarea is scalable or not. |
| `allowExceedMaxLength?` | `boolean` | `true` | Whether to allow the input characters to exceed the counter max length. |
| `height?` | `string` | `88px` | The height of the textarea. (applied when autoSize is 'false') |
| `minHeight?` | `string` | `88px` | The minimum height of the textarea. (applied when autoSize is 'true') |
| `maxHeight?` | `string` | `200px` | The maximum height of the textarea. (applied when autoSize is 'true') |
| `width?` | `string` | `358px` | Custom width of the textarea. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `message?` | `string` |  | Message of the input footer. |
| `maxLengthExceededMessage?` | `string` |  | Message displayed when counterLength exceeds counterMaxLength. |
| `messageIcon?` | `React.ReactNode` |  | Custom message icon of the input footer, if set to null, there is no message icon |
| `showCounter?` | `boolean` |  | Whether to show the counter or not. |
| `counterMaxLength?` | `number` |  | The max length of the input value for the counter. |

_Also extends: `TPropsWithoutCustomStyle<Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'children'>>`_
