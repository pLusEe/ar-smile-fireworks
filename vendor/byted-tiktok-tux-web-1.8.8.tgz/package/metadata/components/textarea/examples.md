<!-- tux-web · components/textarea/examples -->
> **TUX `textarea` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/text-area)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXTextArea } from '@byted-tiktok/tux-web';

<TUXTextArea defaultValue="" />
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXTextArea } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTextArea defaultValue="" disabled />
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXTextArea } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTextArea defaultValue="" invalid />
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC, useState } from 'react';
import { TUXTextArea, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<string>('');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Uncontrolled Mode</TUXText>
        <TUXTextArea defaultValue="" />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Controlled Mode</TUXText>
        <TUXTextArea
          value={value}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>, textAreaValue: string) => {
            setValue(textAreaValue);
            console.log(textAreaValue);
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXTextArea, TUXButton } from '@byted-tiktok/tux-web';
import { IconArrowUpRightAndArrowDownLeft } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTextArea
        defaultValue=""
        trailing={
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <TUXButton shapePreset={'borderless'} themePreset={'secondary'} height={'20px'}>
              <IconArrowUpRightAndArrowDownLeft />
            </TUXButton>
          </div>
        }
      />
    </div>
  );
};
export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXTextArea, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Non AutoSize</TUXText>
        <TUXTextArea defaultValue="" autoSize={false} height="200px" />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">AutoSize</TUXText>
        <TUXTextArea defaultValue="" autoSize minHeight="100px" maxHeight="500px" />
      </div>
    </div>
  );
};

export default Example;
```
