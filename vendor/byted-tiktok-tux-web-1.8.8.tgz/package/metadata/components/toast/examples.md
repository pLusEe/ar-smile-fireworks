<!-- tux-web · components/toast/examples -->
> **TUX `toast` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/toast)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { TUXTopToast, TUXButton, TUXTopToastConfig } from '@byted-tiktok/tux-web';
import { IconTickCircleFill } from '@byted-tiktok/tux-icons';

const Example: FC = (): React.ReactElement => {
  const toastConfig: TUXTopToastConfig = {
    text: 'Copied',
    leading: <IconTickCircleFill />,
    duration: 3000,
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXButton
        text="Open Toast Multiple Mode"
        onClick={(): void => {
          TUXTopToast.show({ ...toastConfig, displayMode: 'multiple' });
        }}
      />
      <TUXButton
        text="Open Toast Single Mode"
        onClick={(): void => {
          TUXTopToast.show({ ...toastConfig, displayMode: 'single' });
        }}
      />
      <TUXButton
        text="Open Toast Replace Mode"
        onClick={(): void => {
          TUXTopToast.show({ ...toastConfig, displayMode: 'replace' });
        }}
      />
      <TUXButton
        text="Destroy Toast"
        onClick={(): void => {
          TUXTopToast.destroy();
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXTopToast, TUXButton } from '@byted-tiktok/tux-web';
import { IconTickCircleFill } from '@byted-tiktok/tux-icons';

const Example: FC = (): React.ReactElement => {
  const [isVisible, setIsVisible] = useState(false);

  const onVisibleChange = (visible: boolean): void => {
    console.log('onVisibleChange ', visible);
  };

  return (
    <div>
      <TUXButton
        text={isVisible ? 'Close Toast' : 'Open Toast'}
        onClick={(): void => {
          setIsVisible((prev) => !prev);
        }}
      />

      <TUXTopToast
        visible={isVisible}
        onVisibleChange={onVisibleChange}
        text={'Copied'}
        leading={<IconTickCircleFill />}
      />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC } from 'react';
import { TUXTopToast, TUXButton, TUXTopToastConfig } from '@byted-tiktok/tux-web';
import { IconTickCircleFill } from '@byted-tiktok/tux-icons';

const Example: FC = (): React.ReactElement => {
  const toastConfig: TUXTopToastConfig = {
    text: 'Copied',
    leading: <IconTickCircleFill />,
    duration: 3000,
    topSafeAreaHeight: '16px',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXButton
        text="Custom Top Safe Area Height"
        onClick={(): void => {
          TUXTopToast.show(toastConfig);
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC } from 'react';
import { TUXBottomToast, TUXButton, TUXBottomToastConfig, useTextDirection } from '@byted-tiktok/tux-web';
import { IconTickCircleFill, IconChevronRightLTR } from '@byted-tiktok/tux-icons';

const Example: FC = (): React.ReactElement => {
  const textDirection = useTextDirection();

  const toastConfig: TUXBottomToastConfig = {
    textDirection,
    text: 'This is a title in line',
    leading: <IconTickCircleFill />,
    trailing: <IconChevronRightLTR />,
    duration: 3000,
    onClick: (): void => {
      console.log('bottom toast clicked');
    },
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXButton
        text="Open Toast Multiple Mode"
        onClick={(): void => {
          TUXBottomToast.show({ ...toastConfig, displayMode: 'multiple' });
        }}
      />
      <TUXButton
        text="Open Toast Single Mode"
        onClick={(): void => {
          TUXBottomToast.show({ ...toastConfig, displayMode: 'single' });
        }}
      />
      <TUXButton
        text="Open Toast Replace Mode"
        onClick={(): void => {
          TUXBottomToast.show({ ...toastConfig, displayMode: 'replace' });
        }}
      />
      <TUXButton
        text="Destroy Toast"
        onClick={(): void => {
          TUXBottomToast.destroy();
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXBottomToast, TUXButton, TUXAvatar, TUXLink, useTextDirection } from '@byted-tiktok/tux-web';
import { IconTickCircleFill, IconChevronRightLTR } from '@byted-tiktok/tux-icons';
import AvatarDemoImg from '../../../images/avatar-demo.svg';

const Example: FC = (): React.ReactElement => {
  const [arrowVisible, setArrowVisible] = useState(false);
  const [linkVisible, setLinkVisible] = useState(false);
  const textDirection = useTextDirection();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXButton
        text={arrowVisible ? 'Close Arrow Toast' : 'Open Arrow Toast'}
        onClick={(): void => {
          setArrowVisible((prev) => !prev);
          setLinkVisible(false);
        }}
      />
      <TUXButton
        text={linkVisible ? 'Close Link Toast' : 'Open Link Toast'}
        onClick={(): void => {
          setLinkVisible((prev) => !prev);
          setArrowVisible(false);
        }}
      />

      <TUXBottomToast
        textDirection={textDirection}
        visible={arrowVisible}
        onVisibleChange={setArrowVisible}
        text="This is a title in line"
        leading={<IconTickCircleFill />}
        trailing={<IconChevronRightLTR />}
        onClick={(): void => {
          console.log('bottom toast clicked');
        }}
      />

      <TUXBottomToast
        textDirection={textDirection}
        visible={linkVisible}
        onVisibleChange={setLinkVisible}
        text="This is a title in line"
        leading={<TUXAvatar src={AvatarDemoImg} sizePreset="small" alt="Avatar Demo Image" />}
        trailing={
          <TUXLink
            text="Link text"
            colorPreset="info"
            typographyPreset="H4-Semibold"
            trailingIcon={<IconChevronRightLTR />}
            onClick={(): void => {
              console.log('link clicked');
            }}
          />
        }
      />
    </div>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import React, { FC } from 'react';
import { TUXBottomToast, TUXButton, TUXBottomToastConfig, useTextDirection } from '@byted-tiktok/tux-web';
import { IconTickCircleFill, IconChevronRightLTR } from '@byted-tiktok/tux-icons';

const Example: FC = (): React.ReactElement => {
  const textDirection = useTextDirection();

  const toastConfig: TUXBottomToastConfig = {
    textDirection,
    text: 'This is a title in line',
    leading: <IconTickCircleFill />,
    trailing: <IconChevronRightLTR />,
    duration: 3000,
    bottomSafeAreaHeight: '80px',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px' }}>
      <TUXButton
        text="Custom Bottom Safe Area Height"
        onClick={(): void => {
          TUXBottomToast.show(toastConfig);
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXCenterToast } from '@byted-tiktok/tux-web';
import { IconTick } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text={visible ? 'Close Center Toast' : 'Open Center Toast'}
        onClick={(): void => {
          setVisible((prev) => !prev);
        }}
      />
      <TUXCenterToast icon={<IconTick />} text="Message" visible={visible} onVisibleChange={setVisible} />
    </>
  );
};

export default Example;
```
