<!-- tux-web · components/toast/props -->
> **TUX `toast` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/toast)

## `TUXTopToast` static methods

| Method | Signature | Description |
| --- | --- | --- |
| `show` | `(config: TUXTopToastConfig) => void` | Static method to show toasts. @param config - Toast config: { text?: string; leading?: React.ReactNode; displayMode?: 'single' \| 'replace' \| 'multiple'; duration?: number; topSafeAreaHeight?: string; zIndex?: number; textDirection?: 'ltr' \|'rtl'; }. @returns @i18n zh-CN 配置 `show`。 |
| `destroy` | `() => void` | Static method to destroy toasts. @returns void @i18n zh-CN 配置 `destroy`。 |

## `TUXTopToast` props _(version: v1)_

_Props type: `TUXTopToastProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `topSafeAreaHeight?` | `string` |  | Custom height of the top safe area, usually used on mobile devices. |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the specific scope. |
| `text?` | `string` |  | Text content of the toast. |
| `leading?` | `React.ReactNode` |  | Custom Area before the toast text. |
| `visible?` | `boolean` | `false` | Controls whether the toast is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the toast is shown or hidden. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |
| `zIndex?` | `number` | `2300` | Z-index of the toast. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root to which the toast are attached. |

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |

## `TUXBottomToast` static methods

| Method | Signature | Description |
| --- | --- | --- |
| `show` | `(config: TUXBottomToastConfig) => void` | Static method to show toasts. @param config - Toast config: { text?: string; leading?: React.ReactNode; trailing?: React.ReactNode; onClick?: (e: React.MouseEvent<HTMLDivElement>) => void; displayMode?: 'single' \| 'replace' \| 'multiple'; duration?: number; bottomSafeAreaHeight?: string; zIndex?: number; textDirection?: 'ltr' \|'rtl'; }. @returns @i18n zh-CN 配置 `show`。 |
| `destroy` | `() => void` | Static method to destroy toasts. @returns void @i18n zh-CN 配置 `destroy`。 |

## `TUXBottomToast` props _(version: v1)_

_Props type: `TUXBottomToastProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `bottomSafeAreaHeight?` | `string` |  | Custom height of the bottom safe area, usually used to keep the toast clear of a tab bar. |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the specific scope. |
| `text?` | `string` |  | Text content of the toast. |
| `leading?` | `React.ReactNode` |  | Custom area before the toast text, usually an icon or an avatar. |
| `trailing?` | `React.ReactNode` |  | Custom area after the toast text, usually an arrow or a link. |
| `visible?` | `boolean` | `false` | Controls whether the toast is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the toast is shown or hidden. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Callback event triggered when the toast is clicked, set this to make the toast to be interactive. |
| `zIndex?` | `number` | `2300` | Z-index of the toast. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root to which the toast are attached. |

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |

## `TUXCenterToast` props _(version: v1)_

_Props type: `TUXCenterToastProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `zIndex?` | `number` | `2300` | Z-index of the center toast. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root to which the center toast are attached. |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the specific scope. |
| `text?` | `string` |  | Text to be displayed under the top icon. |
| `icon?` | `React.ReactNode` |  | Top icon of the center toast. |
| `visible?` | `boolean` | `false` | Controls whether the center toast is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the center toast is shown or hidden. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |

## Additional exports



## `TUXToastPortal` props

_Props type: `TUXToastPortalProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `id?` | `string` |  |  |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  |  |
| `theme?` | `TTUXContextValue['theme']` |  | The theme for the specific scope. |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the specific scope. |
| `platform?` | `TTUXContextValue['platform']` |  | The platform information. |
| `breakpoint?` | `TTUXContextValue['breakpoint']` |  | The viewport breakpoint for the specific scope. |
| `highContrastColors?` | `Partial<TTUXColorMap>` |  | High-contrast color overrides scoped to this subtree. Merges on top of the colors inherited from the enclosing `TUXApp`/`TUXConfigure`. Requires importing `@byted-tiktok/tux-web/colors-v2-high-contrast.css` to apply the matching CSS variables. |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |

### Detailed notes

> `highContrastColors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
