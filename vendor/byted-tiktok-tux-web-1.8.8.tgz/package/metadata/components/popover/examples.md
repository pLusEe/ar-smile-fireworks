<!-- tux-web · components/popover/examples -->
> **TUX `popover` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/popover)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXPopover } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <TUXPopover trigger={<TUXButton>Click me</TUXButton>}>
      <div style={{ padding: 12 }}>Popover content</div>
    </TUXPopover>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXPopover } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <TUXPopover trigger={<TUXButton>Click me</TUXButton>} triggerMode="hover" showArrow placement="InlineEnd">
      <div style={{ padding: 12 }}>Hover content with arrow</div>
    </TUXPopover>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXPopover } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [open, setOpen] = useState(false);
  return (
    <TUXPopover trigger={<TUXButton>Click me</TUXButton>} visible={open} onVisibleChange={setOpen} placement="BlockEnd">
      <div style={{ padding: 12 }}>Controlled popover content</div>
    </TUXPopover>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXPopover } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <TUXPopover
      trigger={<TUXButton>Click me</TUXButton>}
      width="500px"
      height="40px"
      backgroundColor={'UIShapeWarning'}
      offsetOptions={30}
      showArrow
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%' }}>
        Custom styled popover
      </div>
    </TUXPopover>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC, useRef } from 'react';
import { TUXButton, TUXPopover, TUXNavBar, TUXNavBarIconAction } from '@byted-tiktok/tux-web';
import { IconChevronLeftOffsetLTR } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const portalRef = useRef<HTMLDivElement>(null);
  return (
    <>
      <TUXPopover trigger={<TUXButton>Click me</TUXButton>} root={portalRef}>
        <TUXNavBar
          title="Title"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} onClick={() => console.log('click')} />}
          showSeparator
        />
        <div style={{ padding: 12 }}>Popover content</div>
      </TUXPopover>
      <div ref={portalRef} />
    </>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXPopover, TUXFloatingRoot, TUXFloatingTrigger, TUXTooltip } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ height: 100, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <TUXFloatingRoot>
        <TUXFloatingTrigger>
          <TUXButton>Click me</TUXButton>
        </TUXFloatingTrigger>
        {/* id is needed when using several popovers or tooltips */}
        <TUXPopover id="popoverOne" placement="InlineStart" triggerMode="hover">
          <div style={{ padding: 12 }}>Popover content One</div>
        </TUXPopover>
        <TUXPopover id="popoverTwo" placement="InlineEnd" triggerMode="click">
          <div style={{ padding: 12 }}>Popover content Two</div>
        </TUXPopover>
        <TUXTooltip
          id="tooltipOne"
          placement="BlockEnd"
          triggerMode="click"
          text="Tooltip content down"
          offsetOptions={{ mainAxis: 60 }}
        />
      </TUXFloatingRoot>
    </div>
  );
};

export default Example;
```
