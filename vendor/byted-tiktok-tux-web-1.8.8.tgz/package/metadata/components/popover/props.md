<!-- tux-web · components/popover/props -->
> **TUX `popover` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/popover)

## `TUXPopover` props _(version: v1)_

_Props type: `TUXPopoverProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `trigger?` | `ReactElement` |  | Trigger element |
| `id?` | `string` |  | id of the popover, used to identify the popover when use together with other popover in same TUXFloatingRoot |
| `triggerMode?` | `TTriggerMode \| TTriggerMode[]` | `'click'` | Trigger mode, can be one of the following: 'click' \| 'hover' \| 'focus' |
| `placement?` | `TPopoverPlacement` | `'BlockStart'` | Placement of the popover relative to the trigger element, the value can be one of the following: 'BlockStart' \| 'BlockStart-Start' \| 'BlockStart-End' \| 'BlockEnd' \| 'BlockEnd-Start' \| 'BlockEnd-End' \| 'InlineStart' \| 'InlineStart-Start' \| 'InlineStart-End' \| 'InlineEnd' \| 'InlineEnd-Start' \| 'InlineEnd-End' |
| `root?` | `Parameters<typeof FloatingPortal>['0']['root']` | `null` | Root element of the popover, default is null, which means the popover will be rendered in the body element |
| `visible?` | `boolean` | `false` | Whether the popover is open |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback when the popover is open or closed |
| `showArrow?` | `boolean` | `false` | Whether to show arrow |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus popover when open |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether to dismiss the popover when click outside |
| `autoFlip?` | `boolean` | `false` | Whether to flip the popover when it is out of the viewport |
| `width?` | `string` |  | Custom width of the popover |
| `matchTriggerWidth?` | `boolean` | `false` | Whether the popover width should match the trigger width. Takes precedence over `width`. |
| `minWidth?` | `string` |  | Custom minimum width of the popover. |
| `maxWidth?` | `string` |  | Custom maximum width of the popover. |
| `height?` | `string` |  | Custom height of the popover |
| `minHeight?` | `string` |  | Custom minimum height of the popover. |
| `maxHeight?` | `string` |  | Custom maximum height of the popover. |
| `backgroundColor?` | `TColorWithToken` | `'UISheetFlat3'` | Background color of the popover |
| `zIndex?` | `number` | `2200` | Z-index of the popover |
| `offsetOptions?` | `OffsetOptions` |  | Offset between the trigger element and the popover |
| `theme?` | `TTUXContextValue['theme']` |  | Color theme of the popover |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | Text direction of the popover |
| `platform?` | `TTUXContextValue['platform']` |  | Platform preset of the popover |
| `openDelay?` | `number` | `0` | Open delay duration(ms) when hovered. |
| `closeDelay?` | `number` | `0` | Close delay duration(ms) when hovered. |
| `safeArea?` | `{ x?: number; y?: number }` |  | Safe area at the edges of the screen, that the popover will not overlap with. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `triggerMode` — TTriggerMode
>
> Trigger interaction(s) that open a floating element such as a popover or
> tooltip. Pass an array to enable multiple triggers at once.
> 
> - `click` — opens on click of the trigger; closes on outside click
> - `hover` — opens while the pointer hovers over the trigger
> - `focus` — opens while the trigger has keyboard focus

> `placement` — TPopoverPlacement
>
> Logical placement of a floating element relative to its trigger.
> 
> Names use logical (writing-direction-aware) axes so the same value renders
> correctly under both LTR and RTL:
> - `Block*` — vertical axis. `BlockStart` is above the trigger;
>   `BlockEnd` is below.
> - `Inline*` — horizontal axis. `InlineStart` is the leading side
>   (left in LTR, right in RTL); `InlineEnd` is the trailing side.
> - Plain `BlockStart` / `BlockEnd` / `InlineStart` / `InlineEnd` center the
>   floating element along the cross axis of the trigger.
> - `-Start` / `-End` suffixes pin the floating element to the start or end of
>   the cross axis instead (e.g. `BlockEnd-Start` opens below the trigger,
>   aligned to its leading edge).

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
