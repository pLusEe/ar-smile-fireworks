<!-- tux-web · components/form-item-header/examples -->
> **TUX `form-item-header` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-item-header)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXFormItemHeader, TUXInput, TUXTooltip } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXFormItemHeader
        title="Name"
        description="Description Field"
        showRequiredMark={true}
        infoIcon={
          <TUXTooltip
            trigger={
              <div>
                <IconInfoCircle />
              </div>
            }
            text="Hiding Info"
          />
        }
        optionalText="(Optional)"
      />
      <TUXInput />
    </div>
  );
};
export default Example;
```
