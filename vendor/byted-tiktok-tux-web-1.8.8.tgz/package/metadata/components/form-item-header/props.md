<!-- tux-web · components/form-item-header/props -->
> **TUX `form-item-header` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-item-header)

## `TUXFormItemHeader` props _(version: v1)_

_Props type: `TUXFormItemHeaderProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `string` |  | Title of the input label. |
| `description?` | `string` |  | The detailed description of the input label. |
| `showRequiredMark?` | `boolean` |  | Whether the input label has a required mark or not. |
| `infoIcon?` | `React.ReactNode` |  | Info icon of the input label. Usually used with tooltip/sheet to hide more information. |
| `optionalText?` | `string` |  | Additional descriptive text of the input label. |
| `width?` | `string` |  | Custom width of the input label. |
