<!-- tux-web · components/interaction-container/props -->
> **TUX `interaction-container` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md)

## `TUXInteractionContainer` props

_Props type: `TUXInteractionContainerProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `activeMode` | `'opacity' \| 'overlay'` |  | Controls the active mode. |
| `activeOverlayMode?` | `'light' \| 'strong'` | `light` | Controls the overlay mode of the overlay in the pressed state. |
| `disabled?` | `boolean` | `false` | Whether the interaction is disabled. |
| `role?` | `string` |  | role that tells browser what kind of element it should be treated as |
| `tabIndex?` | `number` |  | The tab index of the container. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Click event handler for the container. |
| `as?` | `'div' \| 'span'` | `div` | The element to render as the container. |
| `hoverMode?` | `'overlay'` |  | Hover mode of the container. |
| `hoveredOverlayColor?` | `THoveredOverlayColor` |  | Hover overlay color of the container. (Applied when hoverMode is overlay) |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

_Also extends: `Omit<React.ComponentPropsWithoutRef<'div'>, 'children'>`_

### Detailed notes

> `hoveredOverlayColor` — THoveredOverlayColor
>
> Overlay color applied on top of an interactive surface while hovered.
> 
> Choose the variant whose contrast matches the underlying surface:
> - `UIShapeNeutral4` — theme-aware neutral overlay (default fallback)
> - `UIShapeNeutral4Light` — light variant, for use on dark backgrounds
> - `UIShapeNeutral4Dark` — dark variant, for use on light or colorful backgrounds
> - `WhiteHoverColor` — `rgba(0, 0, 0, 0.07)`, a subtle dark wash for white surfaces
> - `BlackHoverColor` — `rgba(255, 255, 255, 0.16)`, a subtle light wash for black surfaces
