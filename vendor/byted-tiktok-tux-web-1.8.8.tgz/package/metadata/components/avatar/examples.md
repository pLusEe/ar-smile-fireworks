<!-- tux-web · components/avatar/examples -->
> **TUX `avatar` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/avatar)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXAvatar } from '@byted-tiktok/tux-web/canary';

<TUXAvatar src={AvatarDemoImg} alt="Avatar Demo Image" />
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXAvatar } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '../../../images/avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXAvatar src={AvatarDemoImg} sizePreset="tiny" />
      <TUXAvatar src={AvatarDemoImg} sizePreset="small" />
      <TUXAvatar src={AvatarDemoImg} sizePreset="medium" />
      <TUXAvatar src={AvatarDemoImg} sizePreset="large" />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXAvatar, TUXText } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '../../../images/avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXText typographyPreset="H3-Semibold">Non-interactive avatar</TUXText>
      <div style={{ display: 'flex', gap: '8px', padding: '16px' }}>
        <TUXAvatar src={AvatarDemoImg} />
        <TUXAvatar />
      </div>
      <TUXText typographyPreset="H3-Semibold">Interactive avatar</TUXText>
      <div style={{ display: 'flex', gap: '8px', padding: '16px' }}>
        <TUXAvatar
          src={AvatarDemoImg}
          onClick={(e) => {
            console.log('This is an interactive avatar');
          }}
        />
        <TUXAvatar
          onClick={(e) => {
            console.log('This is an interactive avatar');
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXAvatar } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '../../../images/avatar-demo.svg';
import { IconColorPaperplaneCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXAvatar src={AvatarDemoImg} sizePreset="tiny" badgeIcon={<IconColorPaperplaneCircle />} />
      <TUXAvatar src={AvatarDemoImg} sizePreset="small" badgeIcon={<IconColorPaperplaneCircle />} />
      <TUXAvatar src={AvatarDemoImg} sizePreset="medium" badgeIcon={<IconColorPaperplaneCircle />} />
      <TUXAvatar src={AvatarDemoImg} sizePreset="large" badgeIcon={<IconColorPaperplaneCircle />} />
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXAvatar } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '../../../images/avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXAvatar src={AvatarDemoImg} sizePreset="tiny" showDot />
      <TUXAvatar src={AvatarDemoImg} sizePreset="small" showDot />
      <TUXAvatar src={AvatarDemoImg} sizePreset="medium" showDot />
      <TUXAvatar src={AvatarDemoImg} sizePreset="large" showDot />
    </div>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXAvatar } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '../../../images/avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <TUXAvatar src={AvatarDemoImg} sizePreset="tiny" ringColor="UIShapeNeutral3" />
      <TUXAvatar src={AvatarDemoImg} sizePreset="small" ringColor="UIShapeNeutral3" />
      <TUXAvatar src={AvatarDemoImg} sizePreset="medium" ringColor="UIShapeNeutral3" />
      <TUXAvatar src={AvatarDemoImg} sizePreset="large" ringColor="UIShapeNeutral3" />
    </div>
  );
};

export default Example;
```
