<!-- tux-web · components/avatar/props -->
> **TUX `avatar` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/avatar)

## `TUXAvatar` props _(version: v1)_

_Props type: `TUXAvatarProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `src?` | `string` |  | Source image of the avatar. |
| `alt?` | `string` |  | Alternative texts to be displayed when the image fails to load. |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `medium` | Preset sizes of the avatar. |
| `size?` | `number` |  | Size of the avatar. |
| `showDot?` | `boolean` |  | Whether to show the dot or not. |
| `badgeIcon?` | `React.ReactNode` |  | The icon to be displayed on the badge. |
| `dotColor?` | `TColorWithToken` | `MiscOnlineShape` | The background color of the avatar dot. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Click event handler for the avatar, set this to make the avatar to be interactive. |
| `ringColor?` | `TColorWithToken` | `transparent` | The ring type of the avatar. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 24px
> - `small` — 32px
> - `medium` — 48px
> - `large` — 96px

> `dotColor`, `ringColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
