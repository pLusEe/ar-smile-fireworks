<!-- tux-web · components/switch/examples -->
> **TUX `switch` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/switch)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXSwitch } from '@byted-tiktok/tux-web';

<TUXSwitch
  name="category"
  value="category_item"
  defaultChecked
/>
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXSwitch } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXSwitch name="category" value="category_item" defaultChecked={false} sizePreset="large" />
      <TUXSwitch name="category" value="category_item" defaultChecked={false} sizePreset="small" />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXSwitch } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXSwitch name="category" value="category_item" defaultChecked={false} disabled />
      <TUXSwitch name="category" value="category_item" defaultChecked disabled />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXSwitch } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXSwitch name="category" value="category_item" defaultChecked={false} loading />
      <TUXSwitch name="category" value="category_item" defaultChecked loading />
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC, useState } from 'react';
import { TUXSwitch, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [checked, setChecked] = useState<boolean>(true);
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Uncontrolled Mode</TUXText>
        <TUXSwitch name="category" value="category_item" defaultChecked />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Controlled Mode</TUXText>
        <TUXSwitch
          name="category"
          value="category_item"
          checked={checked}
          onChange={(e) => {
            setChecked(e.target.checked);
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXSwitch } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXSwitch name="category" value="category_item" defaultChecked backgroundColor={'UIShapeDanger'} />
      <TUXSwitch name="category" value="category_item" defaultChecked backgroundColor={'UITextWarningDisplay'} />
    </div>
  );
};

export default Example;
```
