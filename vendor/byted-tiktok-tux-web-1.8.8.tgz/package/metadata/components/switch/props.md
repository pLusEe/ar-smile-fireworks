<!-- tux-web · components/switch/props -->
> **TUX `switch` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/switch)

## `TUXSwitch` props _(version: v1)_

_Props type: `TUXSwitchProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sizePreset?` | `'large' \| 'small'` | `large` | Preset sizes of the switch. |
| `name` | `string` |  | Name of the data that the switch is associated with. Switches with the same name are grouped and control the same set of data. |
| `value` | `string` |  | Value that the switch controls. This should be unique for all switches with the same name. |
| `id?` | `string` |  | Identifier for the switch input. |
| `checked?` | `boolean` |  | Controls the checking state of the switch. Uses this prop with 'onChange' to make it in a controlled mode. |
| `defaultChecked?` | `boolean` |  | Controls the default checking state of the switch. Uses this prop in an uncontrolled mode. |
| `onChange?` | `(e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void` |  | Change event handler of the switch. Uses this prop with 'checked' to make it in a controlled mode. |
| `disabled?` | `boolean` |  | Whether the switch is in a disabled(not interactive) state. |
| `loading?` | `boolean` |  | Whether the switch is in a loading state. |
| `backgroundColor?` | `TColorWithToken` |  | Custom background color of the checked switch. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `large` — 48x28px track with 22px indicator
> - `small` — 38x22px track with 16px indicator

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
