<!-- tux-web · components/tab-bar/examples -->
> **TUX `tab-bar` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/tab-bar)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { TUXTabBar, TUXTabBarItemProps } from '@byted-tiktok/tux-web';

const items: TUXTabBarItemProps[] = [
  { itemKey: 'Trending', title: 'Trending' },
  { itemKey: 'New', title: 'New' },
  { itemKey: 'Hot', title: 'Hot' },
  { itemKey: 'Tool', title: 'Tool' },
  { itemKey: 'Funny', title: 'Funny' },
  { itemKey: 'Appearance', title: 'Appearance' },
];

const Example: FC = () => {
  return <TUXTabBar items={items} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC } from 'react';
import { TUXTabBar, TUXTabBarItemProps } from '@byted-tiktok/tux-web';
import { IconBookmark, IconTwoPerson, IconInbox, IconPerson } from '@byted-tiktok/tux-icons';

const items: TUXTabBarItemProps[] = [
  { itemKey: 'Home', title: 'Home', leadingIcon: <IconBookmark /> },
  { itemKey: 'Friends', title: 'Friends', leadingIcon: <IconTwoPerson /> },
  { itemKey: 'Disabled', title: 'Disabled', disabled: true },
  { itemKey: 'Inbox', title: 'Inbox', leadingIcon: <IconInbox /> },
  { itemKey: 'Profile', title: 'Profile', leadingIcon: <IconPerson />, showTrailingArrow: true },
];

const Example: FC = () => {
  return <TUXTabBar items={items} />;
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXTabBar, TUXTabBarItemProps } from '@byted-tiktok/tux-web';
import {
  Icon3ptBookmarkEyeSlash,
  Icon3ptCollection,
  Icon3ptHeartEyeSlash,
  Icon3ptLockKeyhole,
  Icon3ptRepost,
} from '@byted-tiktok/tux-icons';

const items: TUXTabBarItemProps[] = [
  { itemKey: 'Collection', leadingIcon: <Icon3ptCollection />, showTrailingArrow: true },
  { itemKey: 'Lock', leadingIcon: <Icon3ptLockKeyhole /> },
  { itemKey: 'BookMark', leadingIcon: <Icon3ptBookmarkEyeSlash /> },
  { itemKey: 'Repost', leadingIcon: <Icon3ptRepost /> },
  { itemKey: 'Heart', leadingIcon: <Icon3ptHeartEyeSlash /> },
];

const Example: FC = () => {
  return <TUXTabBar items={items} />;
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXTabBar, TUXTabBarItemProps } from '@byted-tiktok/tux-web';

const items: TUXTabBarItemProps[] = [
  { itemKey: 'Trending', title: 'Trending' },
  { itemKey: 'New', title: 'New' },
  { itemKey: 'Hot', title: 'Hot' },
  { itemKey: 'Tool', title: 'Tool' },
  { itemKey: 'Funny', title: 'Funny' },
  { itemKey: 'Appearance', title: 'Appearance' },
];

const Example: FC = () => {
  const [activeKey, setActiveKey] = useState<string>(items[0].itemKey);

  return (
    <TUXTabBar
      items={items}
      activeKey={activeKey}
      onChange={(key) => {
        setActiveKey(key);
      }}
    />
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import React, { FC } from 'react';
import { TUXTabBar, TUXTabBarItemProps } from '@byted-tiktok/tux-web';

const items: TUXTabBarItemProps[] = [
  { itemKey: 'Trending', title: 'Trending' },
  { itemKey: 'New', title: 'New' },
  { itemKey: 'Hot', title: 'Hot' },
  { itemKey: 'Tool', title: 'Tool' },
  { itemKey: 'Funny', title: 'Funny' },
  { itemKey: 'Appearance', title: 'Appearance' },
];

const Example: FC = () => {
  return <TUXTabBar items={items} fitContent={true} />;
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import React, { FC } from 'react';
import { TUXTabBar, TUXTabBarItemProps } from '@byted-tiktok/tux-web';

const items: TUXTabBarItemProps[] = [
  { itemKey: 'Trending', title: 'Trending' },
  { itemKey: 'New', title: 'New' },
  { itemKey: 'Hot', title: 'Hot' },
  { itemKey: 'Tool', title: 'Tool' },
  { itemKey: 'Funny', title: 'Funny' },
  { itemKey: 'Appearance', title: 'Appearance' },
];

const Example: FC = () => {
  return <TUXTabBar items={items} fixedSpacing={true} />;
};

export default Example;
```
