<!-- tux-web · components/tab-bar/props -->
> **TUX `tab-bar` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/tab-bar)

## `TUXTabBar` props _(version: v1)_

_Props type: `TUXTabBarProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TUXTabBarItemProps[]` |  | Array of tab bar item props data. |
| `activeKey?` | `string` |  | Specify the current active tab bar item by key. |
| `defaultActiveKey?` | `string` |  | Specify the initial active tab bar item. |
| `fitContent?` | `boolean` | `false` | Whether the tab bar item width to fit content instead of equal width. |
| `fixedSpacing?` | `boolean` | `false` | Whether to specify fixed spacing in fit content display mode. |
| `showSeparator?` | `boolean` | `true` | Whether to show the separator. |
| `showFadingEdge?` | `boolean` | `true` | Whether to show the fading edge. |
| `onChange?` | `(activeKey: string) => void` |  | Callback triggered when a tab item item is switched. |
| `onItemClick?` | `(event: React.MouseEvent<HTMLButtonElement>, key: string) => void` |  | Callback triggered when a tab item is clicked. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Referenced types

#### `TUXTabBarItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `itemKey` | `string` |  | Unique identifier for the tab bar item. |
| `title?` | `string` |  | Title of the tab bar item. |
| `leadingIcon?` | `React.ReactNode` |  | Icon pure display or before the title. |
| `showTrailingArrow?` | `boolean` | `false` | Whether to show the arrow icon after the title. |
| `disabled?` | `boolean` | `false` | Whether the tab bar item is disabled. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
