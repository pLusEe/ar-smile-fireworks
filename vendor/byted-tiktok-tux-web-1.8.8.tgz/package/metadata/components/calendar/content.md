<!-- tux-web · components/calendar/content -->
> **TUX `calendar` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md)

_This component has no doc page. See props.md and examples.md for the full surface._
