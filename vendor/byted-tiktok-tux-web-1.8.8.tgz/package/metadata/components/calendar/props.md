<!-- tux-web · components/calendar/props -->
> **TUX `calendar` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md)

## `TUXCalendar` props

_Props type: `TUXCalendarProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `displayYearMonth` | `TYearMonthString` |  | The year and month to display. |
| `showMonth?` | `boolean` |  | Whether to show the year and month |
| `locale?` | `string` |  | The locale to use. |
| `showToday?` | `boolean` | `false` | Whether to show today. |
| `disableDate?` | `(date: Date) => boolean` |  | The function to disable a date. |
| `activeDates?` | `TDateValue` |  | The active dates. |
| `onDayClick?` | `(e: React.MouseEvent<HTMLDivElement>, date: Date) => void` |  | The function to handle day click. |
