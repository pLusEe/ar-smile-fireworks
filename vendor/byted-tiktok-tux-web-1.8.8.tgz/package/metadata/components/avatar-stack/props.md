<!-- tux-web · components/avatar-stack/props -->
> **TUX `avatar-stack` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/avatar-stack)

## `TUXAvatarStack` props _(version: v1)_

_Props type: `TUXAvatarStackProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `size?` | `TAvatarStackSize` | `'large'` | size of avatar stack |
| `avatars` | `Array<ImgHTMLAttributes<HTMLImageElement>>` |  | avatar list |
| `extraNumber?` | `number` |  | number show in the last |
| `stackMode?` | `'firstOnTop' \| 'lastOnTop'` | `'lastOnTop'` | avatar stack mode |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | avatar stack click event |
| `offset?` | `number` |  | offset between avatar stack item |
| `cutoutSize?` | `number` |  | cutout size of the avatar notch |

#### Detailed notes

> `size` — TAvatarStackSize
>
> Preset sizes of avatars in an avatar stack.
> 
> - `tiny` — 16×16px avatars, 9px badge text
> - `small` — 20×20px avatars, 10px badge text
> - `medium` — 24×24px avatars, 10px badge text
> - `large` — 32×32px avatars, 13px badge text
