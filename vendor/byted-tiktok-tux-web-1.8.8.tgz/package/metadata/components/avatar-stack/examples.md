<!-- tux-web · components/avatar-stack/examples -->
> **TUX `avatar-stack` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/avatar-stack)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXAvatarStack } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '~/images/avatar-demo.svg';

const AVATARS = [{ src: AvatarDemoImg }, { src: AvatarDemoImg }];

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} onClick={() => {}} size="tiny" />
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} onClick={() => {}} size="small" />
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} onClick={() => {}} size="medium" />
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} onClick={() => {}} size="large" />
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXAvatarStack } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '~/images/avatar-demo.svg';

const AVATARS = [{ src: AvatarDemoImg }, { src: AvatarDemoImg }, { src: AvatarDemoImg }, { src: AvatarDemoImg }];

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
      <TUXAvatarStack avatars={AVATARS} onClick={() => {}} />
      <TUXAvatarStack avatars={AVATARS} extraNumber={8} onClick={() => {}} />
      {/* number more than 99 will show 99+ */}
      <TUXAvatarStack avatars={AVATARS} extraNumber={121} onClick={() => {}} />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXAvatarStack } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '~/images/avatar-demo.svg';

const AVATARS = [{ src: AvatarDemoImg }, { src: AvatarDemoImg }, { src: AvatarDemoImg }, { src: AvatarDemoImg }];

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} onClick={() => {}} />
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} onClick={() => {}} stackMode="firstOnTop" />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXAvatarStack } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '~/images/avatar-demo.svg';

const AVATARS = [{ src: AvatarDemoImg }, { src: AvatarDemoImg }, { src: AvatarDemoImg }];

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} offset={-10} cutoutSize={40} />
      <TUXAvatarStack avatars={AVATARS} extraNumber={3} offset={-5} cutoutSize={32} />
    </div>
  );
};

export default Example;
```
