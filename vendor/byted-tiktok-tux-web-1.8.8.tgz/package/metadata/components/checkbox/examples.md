<!-- tux-web · components/checkbox/examples -->
> **TUX `checkbox` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/checkbox)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXCheckbox, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXText typographyPreset="H3-Semibold">Please select the drink you like</TUXText>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        <TUXCheckbox name="drink" value="black_tea" defaultChecked />
        <TUXText typographyPreset="P1-Semibold">Black Tea</TUXText>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        <TUXCheckbox name="drink" value="green_tea" defaultChecked={false} />
        <TUXText typographyPreset="P1-Semibold">Green Tea</TUXText>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        <TUXCheckbox name="drink" value="milk_tea" defaultChecked={false} />
        <TUXText typographyPreset="P1-Semibold">Milk Tea</TUXText>
      </div>
    </div>
  );
};
export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXCheckbox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXCheckbox name="category" value="category_item" defaultChecked={false} sizePreset="large" />
      <TUXCheckbox name="category" value="category_item" defaultChecked={false} sizePreset="small" />
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXCheckbox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXCheckbox name="category" value="category_item" defaultChecked={false} shapePreset="circle" />
      <TUXCheckbox name="category" value="category_item" defaultChecked={false} shapePreset="square" />
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXCheckbox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXCheckbox name="category" value="category_item" defaultChecked={false} disabled />
      <TUXCheckbox name="category" value="category_item" defaultChecked disabled />
    </div>
  );
};
export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXCheckbox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXCheckbox name="category" value="category_item" defaultChecked={false} invalid />
    </div>
  );
};
export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC, useState } from 'react';
import { TUXCheckbox, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const options = ['apple', 'banana', 'cherry', 'durian'];
  const defaultCheckedList = ['apple', 'cherry'];
  const [checkedList, setCheckedList] = useState<string[]>(defaultCheckedList);
  const checkAll = options.length === checkedList.length;
  const indeterminate = checkedList.length > 0 && checkedList.length < options.length;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    if (e.target.checked) {
      setCheckedList([...checkedList, e.target.value]);
    } else {
      setCheckedList(checkedList.filter((item: string) => item !== e.target.value));
    }
  };

  const handleCheckAllChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    setCheckedList(e.target.checked ? options : []);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        <TUXCheckbox
          name="fruit"
          value="check_all"
          sizePreset="small"
          indeterminate={indeterminate}
          checked={checkAll}
          onChange={handleCheckAllChange}
        />
        <TUXText typographyPreset="P3-Semibold">Check All</TUXText>
      </div>
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          paddingInlineStart: '16px',
          paddingBlockStart: '5px',
        }}
      >
        {options.map((option) => (
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }} key={option}>
            <TUXCheckbox
              name="fruit"
              value={option.toLocaleLowerCase()}
              sizePreset="small"
              checked={checkedList.includes(option)}
              onChange={handleChange}
            />
            <TUXText typographyPreset="P3-Semibold">{option}</TUXText>
          </div>
        ))}
      </div>
    </div>
  );
};
export default Example;
```

## Example example-7

<a id="example-7"></a>

****: 



****:

```tsx
import { FC, useState } from 'react';
import { TUXCheckbox, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [checked, setChecked] = useState<boolean>(true);
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Uncontrolled Mode</TUXText>
        <TUXCheckbox name="category" value="category_item" defaultChecked />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXText typographyPreset="H3-Semibold">Controlled Mode</TUXText>
        <TUXCheckbox
          name="category"
          value="category_item"
          checked={checked}
          onChange={(e) => {
            setChecked(e.target.checked);
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-8

<a id="example-8"></a>

```tsx
import { FC } from 'react';
import { TUXCheckbox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXCheckbox name="category" value="category_item" defaultChecked backgroundColor={'UITextSuccess'} />
      <TUXCheckbox name="category" value="category_item" defaultChecked backgroundColor={'UIShapeWarning'} />
    </div>
  );
};
export default Example;
```
