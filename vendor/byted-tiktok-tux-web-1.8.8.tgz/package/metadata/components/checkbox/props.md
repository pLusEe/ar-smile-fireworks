<!-- tux-web · components/checkbox/props -->
> **TUX `checkbox` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/checkbox)

## `TUXCheckbox` props _(version: v1)_

_Props type: `TUXCheckboxProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `shapePreset?` | `'square' \| 'circle'` | `circle` | Preset shapes of the checkbox. |
| `sizePreset?` | `'large' \| 'small'` | `large` | Preset sizes of the checkbox. |
| `indeterminate?` | `boolean` |  | Whether the checkbox is in an indeterminate state. |
| `name` | `string` |  | Name of the data that the checkbox is associated with. Checkboxes with the same name are grouped and control the same set of data. |
| `value` | `string` |  | Value that the checkbox option represents. This should be unique for all checkboxes with the same name. |
| `id?` | `string` |  | Identifier for the checkbox input. |
| `checked?` | `boolean` |  | Controls the checking state of the checkbox. Uses this prop with 'onChange' to make it in a controlled mode. |
| `defaultChecked?` | `boolean` |  | Controls the default checking state of the checkbox. Uses this prop in an uncontrolled mode. |
| `onChange?` | `(e: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void` |  | Change event handler of the checkbox. Uses this prop with 'checked' to make it in a controlled mode. |
| `disabled?` | `boolean` |  | Whether the checkbox is in a disabled(not interactive) state. |
| `invalid?` | `boolean` |  | Whether the checkbox is in an error state. |
| `backgroundColor?` | `TColorWithToken` |  | Custom background color of the checkbox when checked. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `display?` | `'inline-block' \| 'block'` |  | Whether the checkbox is displayed as a block element. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `shapePreset` — @remarks
>
> - `circle` — round checkbox
> - `square` — rectangular checkbox with rounded corners

> `sizePreset` — @remarks
>
> - `large` — 20px
> - `small` — 16px

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
