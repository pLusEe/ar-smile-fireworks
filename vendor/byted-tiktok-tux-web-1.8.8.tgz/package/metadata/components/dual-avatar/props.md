<!-- tux-web · components/dual-avatar/props -->
> **TUX `dual-avatar` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/dual-avatar)

## `TUXDualAvatar` props _(version: v1)_

_Props type: `TUXDualAvatarProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `frontImageSrc?` | `string` |  | Front image source of the avatar. |
| `backImageSrc?` | `string` |  | Back image source of the avatar. |
| `frontImageAlt?` | `string` |  | Alternative texts to be displayed when the front image fails to load. |
| `backImageAlt?` | `string` |  | Alternative texts to be displayed when the back image fails to load. |
| `size` | `number` |  | Size of the dual avatar. |
| `showDot?` | `boolean` |  | Whether to show the dot or not. |
| `badgeIcon?` | `React.ReactNode` |  | The icon to be displayed on the badge. |
| `dotColor?` | `TColorWithToken` | `MiscOnlineShape` | The background color of the dual avatar dot. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Click event handler for the avatar, set this to make the dual avatar to be interactive. |
| `ringColor?` | `TColorWithToken` | `transparent` | The ring color of the dual avatar. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `dotColor`, `ringColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
