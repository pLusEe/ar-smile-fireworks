<!-- tux-web · components/dual-avatar/examples -->
> **TUX `dual-avatar` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/dual-avatar)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXDualAvatar } from '@byted-tiktok/tux-web';
import DualAvatarDemoFrontImg from '../../../images/avatar-demo.svg';
import DualAvatarDemoBackImg from '../../../images/dual-avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        size={48}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        size={56}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        size={64}
      />
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXDualAvatar, TUXText } from '@byted-tiktok/tux-web';
import DualAvatarDemoFrontImg from '../../../images/avatar-demo.svg';
import DualAvatarDemoBackImg from '../../../images/dual-avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXText typographyPreset="H3-Semibold">Non-interactive avatar</TUXText>
      <div style={{ display: 'flex', gap: '8px' }}>
        <TUXDualAvatar
          frontImageSrc={DualAvatarDemoFrontImg}
          frontImageAlt="Dual Avatar Front Image"
          backImageSrc={DualAvatarDemoBackImg}
          backImageAlt="Dual Avatar Back Image"
          size={48}
        />
        <TUXDualAvatar
          frontImageSrc={DualAvatarDemoFrontImg}
          frontImageAlt="Dual Avatar Front Image"
          backImageSrc={DualAvatarDemoBackImg}
          backImageAlt="Dual Avatar Back Image"
          size={56}
        />
        <TUXDualAvatar
          frontImageSrc={DualAvatarDemoFrontImg}
          frontImageAlt="Dual Avatar Front Image"
          backImageSrc={DualAvatarDemoBackImg}
          backImageAlt="Dual Avatar Back Image"
          size={64}
        />
      </div>
      <TUXText typographyPreset="H3-Semibold">Interactive avatar</TUXText>
      <div style={{ display: 'flex', gap: '8px' }}>
        <TUXDualAvatar
          frontImageSrc={DualAvatarDemoFrontImg}
          frontImageAlt="Dual Avatar Front Image"
          backImageSrc={DualAvatarDemoBackImg}
          backImageAlt="Dual Avatar Back Image"
          size={48}
          onClick={(e) => {
            console.log('This is an interactive avatar');
          }}
        />
        <TUXDualAvatar
          frontImageSrc={DualAvatarDemoFrontImg}
          frontImageAlt="Dual Avatar Front Image"
          backImageSrc={DualAvatarDemoBackImg}
          backImageAlt="Dual Avatar Back Image"
          size={56}
          onClick={(e) => {
            console.log('This is an interactive avatar');
          }}
        />
        <TUXDualAvatar
          frontImageSrc={DualAvatarDemoFrontImg}
          frontImageAlt="Dual Avatar Front Image"
          backImageSrc={DualAvatarDemoBackImg}
          backImageAlt="Dual Avatar Back Image"
          size={64}
          onClick={(e) => {
            console.log('This is an interactive avatar');
          }}
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXDualAvatar } from '@byted-tiktok/tux-web';
import { IconColorPaperplaneCircle } from '@byted-tiktok/tux-icons';
import DualAvatarDemoFrontImg from '../../../images/dual-avatar-demo.svg';
import DualAvatarDemoBackImg from '../../../images/dual-avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        badgeIcon={<IconColorPaperplaneCircle />}
        size={48}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        badgeIcon={<IconColorPaperplaneCircle />}
        size={56}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        badgeIcon={<IconColorPaperplaneCircle />}
        size={64}
      />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXDualAvatar } from '@byted-tiktok/tux-web';
import DualAvatarDemoFrontImg from '../../../images/avatar-demo.svg';
import DualAvatarDemoBackImg from '../../../images/dual-avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        showDot
        size={48}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        showDot
        size={56}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        showDot
        size={64}
      />
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXDualAvatar } from '@byted-tiktok/tux-web';
import DualAvatarDemoFrontImg from '../../../images/avatar-demo.svg';
import DualAvatarDemoBackImg from '../../../images/dual-avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        ringColor="UIShapeNeutral3"
        size={48}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        ringColor="UIShapeNeutral3"
        size={56}
      />
      <TUXDualAvatar
        frontImageSrc={DualAvatarDemoFrontImg}
        frontImageAlt="Dual Avatar Front Image"
        backImageSrc={DualAvatarDemoBackImg}
        backImageAlt="Dual Avatar Back Image"
        ringColor="UIShapeNeutral3"
        size={64}
      />
    </div>
  );
};

export default Example;
```
