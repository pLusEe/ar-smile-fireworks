<!-- tux-web · components/list-cell/examples -->
> **TUX `list-cell` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/list-cell)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <TUXText typographyPreset="Headline-Regular">Action</TUXText>
          <IconChevronRightOffsetLTR />
        </div>
      }
    />
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC } from 'react';
import { TUXButton, TUXListCell } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={<TUXButton sizePreset="small" text="button" maxWidth="120px" />}
    />
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXCheckbox } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={<TUXCheckbox name="Label" value="Label" sizePreset="large" />}
    />
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      disabled={true}
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <TUXText typographyPreset="Headline-Regular">Action</TUXText>
          <IconChevronRightOffsetLTR />
        </div>
      }
      onClick={(e) => {
        console.log('This is a disabled list cell');
      }}
    />
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <TUXText typographyPreset="Headline-Regular">Action</TUXText>
          <IconChevronRightOffsetLTR />
        </div>
      }
    />
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <TUXText typographyPreset="Headline-Regular">Action</TUXText>
          <IconChevronRightOffsetLTR />
        </div>
      }
      onClick={(e) => {
        console.log('This is an interactive list cell');
      }}
    />
  );
};

export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={
        <TUXText typographyPreset="Headline-Regular" color={'UIText3'}>
          Label
        </TUXText>
      }
    />
  );
};

export default Example;
```

## Example example-8

<a id="example-8"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TUXText typographyPreset="H3-Semibold">Stacked</TUXText>
      <div style={{ border: 'solid 1px' }}>
        <TUXListCell
          layout={'stacked'}
          title="Label"
          description="Message"
          leadingIcon={<IconInfoCircle />}
          trailing={
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <TUXText typographyPreset="Headline-Regular">Action</TUXText>
              <IconChevronRightOffsetLTR />
            </div>
          }
        />
      </div>
      <TUXText typographyPreset="H3-Semibold">Segmented</TUXText>
      <div style={{ border: 'solid 1px' }}>
        <TUXListCell
          layout={'segmented'}
          title="Label"
          description="Message"
          leadingIcon={<IconInfoCircle />}
          trailing={
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <TUXText typographyPreset="Headline-Regular">Action</TUXText>
              <IconChevronRightOffsetLTR />
            </div>
          }
        />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-9

<a id="example-9"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXRadio } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={<TUXRadio name="Label" value="Label" sizePreset="large" />}
    />
  );
};

export default Example;
```

## Example example-10

<a id="example-10"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXSwitch } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListCell
      title="Label"
      description="Message"
      leadingIcon={<IconInfoCircle />}
      trailing={<TUXSwitch name="Label" value="Label" sizePreset="large" />}
    />
  );
};

export default Example;
```

## Example example-11

<a id="example-11"></a>

```tsx
import React, { FC } from 'react';
import { TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TUXText typographyPreset="H3-Semibold">Normal</TUXText>
      <TUXListCell
        themePreset={'normal'}
        title="Label"
        description="Message"
        leadingIcon={<IconInfoCircle />}
        trailing={
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <TUXText typographyPreset="Headline-Regular">Action</TUXText>
            <IconChevronRightOffsetLTR />
          </div>
        }
      />
      <TUXText typographyPreset="H3-Semibold">Destructive</TUXText>
      <TUXListCell
        themePreset={'destructive'}
        title="Label"
        description="Message"
        leadingIcon={<IconInfoCircle />}
        trailing={
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <TUXText typographyPreset="Headline-Regular">Action</TUXText>
            <IconChevronRightOffsetLTR />
          </div>
        }
      />
    </div>
  );
};

export default Example;
```
