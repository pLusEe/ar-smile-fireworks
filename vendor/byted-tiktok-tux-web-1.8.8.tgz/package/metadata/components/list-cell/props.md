<!-- tux-web · components/list-cell/props -->
> **TUX `list-cell` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/list-cell)

## `TUXListCell` props _(version: v1)_

_Props type: `TUXListCellProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `React.ReactNode` |  | The title of the list cell. |
| `trailing?` | `React.ReactNode` |  | Trailing area of the list cell. |
| `description?` | `React.ReactNode` |  | The description of the list cell. |
| `leadingIcon?` | `React.ReactNode` |  | Leading icon of the list cell. |
| `layout?` | `'stacked' \| 'segmented'` | `'stacked'` | Provide two kind of layouts: 'stacked' for vertical layout, 'segmented' for left-center-right layout. |
| `themePreset?` | `'normal' \| 'destructive'` | `normal` | Preset themes of the list cell. |
| `disabled?` | `boolean` | `false` | Whether the list cell is disabled. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Callback event triggered when the list cell is clicked, set this to make the list cell to be interactive. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `themePreset` — @remarks
>
> - `normal` — UIText1 title color
> - `destructive` — UITextDanger title color
