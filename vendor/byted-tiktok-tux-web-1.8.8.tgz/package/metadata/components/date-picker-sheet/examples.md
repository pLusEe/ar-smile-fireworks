<!-- tux-web · components/date-picker-sheet/examples -->
> **TUX `date-picker-sheet` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/date-picker-sheet)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXDatePickerSheet, TDateValue, TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);
  const [visible, setVisible] = useState(false);

  return (
    <>
      <div>value is: {value.length === 0 ? null : `${value[0]}`}</div>
      <TUXButton text="click" onClick={() => setVisible(true)} />
      <TUXDatePickerSheet value={value} onValueChange={setValue} visible={visible} onVisibleChange={setVisible} />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXDatePickerSheet, TDateValue, TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);
  const [visible, setVisible] = useState(false);

  return (
    <>
      <div>value is: {value.length === 0 ? null : `${value[0]} - ${value[1]}`}</div>
      <TUXButton text="click" onClick={() => setVisible(true)} />
      <TUXDatePickerSheet
        mode="range"
        value={value}
        onValueChange={setValue}
        visible={visible}
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import {
  TUXDatePickerSheet,
  TDateValue,
  TUXButton,
  TUXSelectBox,
  TUXNavBar,
  TUXNavBarCloseButton,
} from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [value, setValue] = useState<TDateValue>([]);
  const [visible, setVisible] = useState(false);

  const renderFooter = ({ internalValue, setInternalValue, isInternalValueValid }) => (
    <div style={{ display: 'flex', gap: '8px' }}>
      <div style={{ flex: 1 }}>
        <TUXButton themePreset="secondary" text="Reset" onClick={() => setInternalValue([])} width="100%" />
      </div>
      <div style={{ flex: 1 }}>
        <TUXButton
          text="Apply"
          disabled={!isInternalValueValid}
          onClick={() => {
            setVisible(false);
            setValue(internalValue);
          }}
          width="100%"
        />
      </div>
    </div>
  );

  return (
    <>
      <TUXSelectBox value={value.toString()} onClick={() => setVisible(true)} />
      <TUXDatePickerSheet
        value={value}
        onValueChange={setValue}
        visible={visible}
        onVisibleChange={setVisible}
        navbar={
          <TUXNavBar
            title="Navigation title"
            trailing={<TUXNavBarCloseButton onClick={() => setVisible(false)} />}
            backgroundColor="UISheetFlat1"
          />
        }
        renderFooter={renderFooter}
      />
    </>
  );
};

export default Example;
```
