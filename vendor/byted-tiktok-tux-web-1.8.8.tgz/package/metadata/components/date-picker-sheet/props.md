<!-- tux-web · components/date-picker-sheet/props -->
> **TUX `date-picker-sheet` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/date-picker-sheet)

## `TUXDatePickerSheet` props _(version: v1)_

_Props type: `TUXDatePickerSheetProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `sheetRange?` | `[Date, Date]` |  | Date range of the calendar sheet. |
| `navbar?` | `React.ReactNode` |  | TUXNavBar component. |
| `renderPrompt?` | `(innerData: { internalValue: TDateValue }) => React.ReactNode` |  | render prompt. |
| `confirmText?` | `string` | `'Confirm'` | Confirm button text. |
| `renderFooter?` | `(innerData: {     internalValue: TDateValue;     setInternalValue: (dateValue: TDateValue) => void;     isInternalValueValid: boolean;   }) => React.ReactNode` |  | Customized the footer. |
| `mode?` | `'single' \| 'range'` | `'single'` | Date picker mode. |
| `value` | `TDateValue` |  | confirmed value, which is [] \| [Date] \| [Date, Date]. |
| `onValueChange` | `(dateValue: TDateValue) => void` |  | Value change callback. |
| `selectableDateRange?` | `[Date, Date]` |  | Selectable date range. |
| `onConfirm?` | `(internalValue: TDateValue) => void` |  | Confirm callback. |
| `onVisibleChange?` | `(visible: boolean) => void` |  |  |
| `disableDate?` | `(date: Date) => boolean` |  | The function to disable a date. |
| `onDayClick?` | `(e: React.MouseEvent<HTMLDivElement>, date: Date) => void` |  | The function to handle day click. |
| `locale?` | `string` |  | The locale to use. |
| `showToday?` | `boolean` | `false` | Whether to show today. |
| `position?` | `'bottom' \| 'left' \| 'right'` | `bottom` | Direction in which the sheet is displayed. |
| `heightModePreset?` | `'auto' \| 'fixed'` | `auto` | Preset height modes of the sheet if position = "bottom". |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether clicking the overlay closes the sheet. |
| `height?` | `string` |  | Height of the sheet, only valid if position = "bottom" |
| `snapHeights?` | `string[]` |  | Multiple snap heights for the sheet, only valid if position = "bottom" |
| `snapMinHeight?` | `string` | `166px` | Minimum snap height for the sheet, only valid if position = "bottom", will be applied when at least one of the snapHeights is smaller than snapMinHeight |
| `snapMaxHeight?` | `string` | `100%` | Maximum snap height for the sheet, only valid if position = "bottom", will be applied when at least one of the snapHeights is larger than snapMaxHeight |
| `minHeight?` | `string` |  | Minimum height of the sheet, only valid if position = "bottom" && draggable = false |
| `maxHeight?` | `string` |  | Maximum height of the sheet, only valid if position = "bottom" && draggable = false |
| `width?` | `string` |  | Width of the sheet, only valid if position = "left" or "right" |
| `minWidth?` | `string` |  | Minimum width of the sheet, only valid if position = "left" or "right" |
| `maxWidth?` | `string` |  | Maximum width of the sheet, only valid if position = "left" or "right" |
| `marginBottom?` | `string` |  | Margin-bottom value of the sheet. |
| `zIndex?` | `number` | `2000` | Z-index of the sheet. |
| `overlayBackgroundColor?` | `TColorWithToken` |  | Background color of the overlay. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `sheetBackgroundColor?` | `TColorWithToken` |  | Background color of the sheet container. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `sheetBackground?` | `string` |  | Any background of the sheet container. |
| `dragHandle?` | `'auto' \| 'hidden' \| 'visible'` | `auto` | Whether to show drag handle, only valid if position = "bottom" (In 'auto' mode, it will be shown when the sheet has multiple snap heights) |
| `draggable?` | `boolean` | `false` | Whether the sheet is draggable. |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `heightModePreset` — @remarks
>
> - `auto` — sizes to content height
> - `fixed` — uses the specified `height` value exactly

> `overlayBackgroundColor`, `sheetBackgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
