<!-- tux-web · components/action-sheet/content -->
> **TUX `action-sheet` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/action-sheet)

_See example: [example example-1](./examples.md#example-1)_

_See example: [example example-2](./examples.md#example-2)_
