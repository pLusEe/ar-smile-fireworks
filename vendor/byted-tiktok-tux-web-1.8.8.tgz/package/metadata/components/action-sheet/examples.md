<!-- tux-web · components/action-sheet/examples -->
> **TUX `action-sheet` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/action-sheet)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXActionSheet, TUXActionSheetProps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  const onVisibleChange = (visible: boolean): void => {
    setVisible(visible);
  };
  const actionSheetOnClick = (): void => {
    setVisible(false);
  };

  const actionItems: TUXActionSheetProps['actions'] = [
    {
      themePreset: 'primary',
      text: 'Normal action',
      subtext: 'Normal action subtext',
      testId: 'text-normal-action-1',
      onClick: actionSheetOnClick,
    },
    {
      themePreset: 'primary',
      text: 'Normal action 2 (Disabled)',
      disabled: true,
      testId: 'text-normal-action-2',
      onClick: actionSheetOnClick,
    },
    {
      themePreset: 'destructive',
      text: 'Destructive action',
      testId: 'text-destructive-action-1',
      onClick: actionSheetOnClick,
    },
    {
      themePreset: 'destructive',
      text: 'Destructive action 2 (Disabled)',
      disabled: true,
      testId: 'text-destructive-action-2',
      onClick: actionSheetOnClick,
    },
  ];

  return (
    <>
      <TUXButton
        text="Open Sheet"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXActionSheet
        title="Title"
        actions={actionItems}
        actionType="text"
        visible={visible}
        onVisibleChange={onVisibleChange}
      />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXActionSheet, TUXActionSheetProps } from '@byted-tiktok/tux-web';
import { IconPerson, IconGif, IconHeart, IconTrashBin } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  const onVisibleChange = (visible: boolean): void => {
    setVisible(visible);
  };
  const actionSheetOnClick = (): void => {
    setVisible(false);
  };

  const actionItems: TUXActionSheetProps['actions'] = [
    {
      themePreset: 'primary',
      text: 'Change Cover',
      subtext: 'sub text',
      icon: <IconGif />,
      testId: 'icon-change-cover',
      onClick: actionSheetOnClick,
    },
    {
      themePreset: 'primary',
      text: 'Pin to top (Disabled)',
      icon: <IconHeart />,
      disabled: true,
      testId: 'text-normal-action-2',
      onClick: actionSheetOnClick,
    },
    {
      themePreset: 'destructive',
      text: 'Remove Friend',
      icon: <IconPerson />,
      testId: 'text-destructive-action-1',
      onClick: actionSheetOnClick,
    },
    {
      themePreset: 'destructive',
      text: 'Delete (Disabled)',
      disabled: true,
      icon: <IconTrashBin />,
      testId: 'text-destructive-action-2',
      onClick: actionSheetOnClick,
    },
  ];

  return (
    <>
      <TUXButton
        text="Open Sheet"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXActionSheet
        title="Title"
        actions={actionItems}
        actionType="icon"
        visible={visible}
        onVisibleChange={onVisibleChange}
      />
    </>
  );
};

export default Example;
```
