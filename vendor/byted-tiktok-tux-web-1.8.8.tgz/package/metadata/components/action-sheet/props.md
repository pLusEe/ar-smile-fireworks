<!-- tux-web · components/action-sheet/props -->
> **TUX `action-sheet` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/action-sheet)

## `TUXActionSheet` props _(version: v1)_

_Props type: `TUXActionSheetProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `string` |  | Title of the action sheet. |
| `cancelText?` | `string` | `Cancel` | Text content of the action sheet's cancel button. Only present in the text variant. |
| `actionType` | `'text' \| 'icon'` |  | Specifies which type of action sheet to use. Either text or icon. |
| `actions` | `TUXActionItemProps[]` |  | The actions to be displayed in the action sheet. |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Referenced types

#### `TUXActionItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text` | `string` |  | Text of the action button. |
| `subtext?` | `string` |  | Subtext of the action button. |
| `icon?` | `React.ReactNode` |  | Icon of the action button. |
| `disabled?` | `boolean` |  | Whether the action button is disabled. |
| `textDisplay?` | `'truncate' \| 'lineBreak'` | `truncate` | The text overflow behavior of the action button. |
| `themePreset` | `'primary' \| 'destructive'` |  | Theme preset of the action button. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Click handler of the action button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

> `themePreset` — @remarks
>
> - `primary` — neutral foreground color (`UIText1`), for standard actions
> - `destructive` — danger foreground color (`UITextDangerDisplay`), for destructive or irreversible actions
