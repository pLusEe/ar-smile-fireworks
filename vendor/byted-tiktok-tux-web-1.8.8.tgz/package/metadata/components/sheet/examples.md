<!-- tux-web · components/sheet/examples -->
> **TUX `sheet` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/sheet)

## Example example-1

<a id="example-1"></a>

```tsx
import { IconChevronLeftOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXNavBar, TUXNavBarIconAction, TUXSheet } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Sheet"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXSheet visible={visible} onVisibleChange={setVisible}>
        <TUXNavBar
          title="Sheet"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} />}
          trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <div style={{ padding: 16, display: 'flex', gap: 8 }}>
          <TUXButton text="Close" onClick={() => setVisible(false)} />
        </div>
        <p style={{ flex: '1 1 0%', paddingInline: 16, paddingBlock: 8, overflowY: 'auto' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illud quaero, quid ei, qui in voluptate summum bonum
          ponat, consentaneum sit dicere.
          <b>Nihil opus est exemplis hoc facere longius.</b> Qua tu etiam inprudens utebare non numquam. Nec enim figura
          corporis nec ratio excellens ingenii humani significat ad unam hanc rem natum hominem, ut frueretur
          voluptatibus.
          <i>Sed in rebus apertissimis nimium longi sumus.</i> Ita enim vivunt quidam, ut eorum vita refellatur oratio.
          Atqui perspicuum est hominem e corpore animoque constare, cum primae sint animi partes, secundae corporis.
          Quae quo sunt excelsiores, eo dant clariora indicia naturae.
        </p>
      </TUXSheet>
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { IconChevronLeftOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXNavBar, TUXNavBarIconAction, TUXSheet } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Sheet"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXSheet visible={visible} onVisibleChange={setVisible} position="left">
        <TUXNavBar
          title="Sheet"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} />}
          trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <div style={{ padding: 16, display: 'flex', gap: 8 }}>
          <TUXButton text="Close" onClick={() => setVisible(false)} />
        </div>
        <p style={{ flex: '1 1 0%', paddingInline: 16, paddingBlock: 8, overflowY: 'auto' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illud quaero, quid ei, qui in voluptate summum bonum
          ponat, consentaneum sit dicere.
          <b>Nihil opus est exemplis hoc facere longius.</b> Qua tu etiam inprudens utebare non numquam. Nec enim figura
          corporis nec ratio excellens ingenii humani significat ad unam hanc rem natum hominem, ut frueretur
          voluptatibus.
          <i>Sed in rebus apertissimis nimium longi sumus.</i> Ita enim vivunt quidam, ut eorum vita refellatur oratio.
          Atqui perspicuum est hominem e corpore animoque constare, cum primae sint animi partes, secundae corporis.
          Quae quo sunt excelsiores, eo dant clariora indicia naturae.
        </p>
      </TUXSheet>
    </>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { IconChevronLeftOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXNavBar, TUXNavBarIconAction, TUXSheet } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  // Define multiple snap heights: 30%, 50%, 70%
  const snapHeights = ['30%', '50%', '70%'];
  const snapMinHeight = '300px';
  const snapMaxHeight = '500px';

  return (
    <>
      <TUXButton
        text="Open Multi Heights Sheet"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXSheet
        visible={visible}
        onVisibleChange={setVisible}
        draggable={true}
        snapHeights={snapHeights}
        snapMinHeight={snapMinHeight}
        snapMaxHeight={snapMaxHeight}
      >
        <TUXNavBar
          title="Multi Heights Sheet"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} />}
          trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <div style={{ padding: 16, paddingBottom: 24, overflowY: 'auto' }}>
          <h3 style={{ marginTop: 0, marginBottom: 12, fontSize: 18, fontWeight: 600 }}>Drag Gesture Feature</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8 }}>
              <strong>Multi-Snap Heights</strong>
              <p style={{ margin: '8px 0 0 0', fontSize: 14, lineHeight: 1.5 }}>
                This is a draggable Sheet. This Sheet supports three heights: 30%, 50%, and 70%. When dragging, it
                automatically snaps to the nearest height position. You can set up your own snap heights by passing an
                array of height strings to the `snapHeights` prop.
              </p>
            </div>

            <div style={{ padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8 }}>
              <strong>Drag Gestures</strong>
              <p style={{ margin: '8px 0 0 0', fontSize: 14, lineHeight: 1.5 }}>
                • Drag down to decrease Sheet height
                <br />
                • Drag up to increase Sheet height
                <br />• Quick swipe down to dismiss the Sheet
              </p>
            </div>

            <div style={{ padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8 }}>
              <strong>Rubber Band Effect</strong>
              <p style={{ margin: '8px 0 0 0', fontSize: 14, lineHeight: 1.5 }}>
                When dragging beyond the maximum or minimum height, a rubber band bounce effect is applied.
              </p>
            </div>

            <div style={{ padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8 }}>
              <strong>Smart Scrolling</strong>
              <p style={{ margin: '8px 0 0 0', fontSize: 14, lineHeight: 1.5 }}>
                When the Sheet reaches maximum height, the content area becomes scrollable. At the top of the content,
                you can continue dragging the Sheet.
              </p>
            </div>

            <div style={{ padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8 }}>
              <strong>snapMinHeight & snapMaxHeight</strong>
              <p style={{ margin: '8px 0 0 0', fontSize: 14, lineHeight: 1.5 }}>
                Use <code>snapMinHeight</code> to set the minimum height constraint for the Sheet. When dragging down,
                the Sheet will not go below this value. It will replace all the smaller heights in snapHeights.
                <br />
                <br />
                Use <code>snapMaxHeight</code> to set the maximum height constraint for the Sheet. When dragging up, the
                Sheet will not exceed this value. It will replace all the larger heights in snapHeights.
                <br />
                <br />
                These props work together with <code>snapHeights</code> to control the draggable range of the Sheet.
              </p>
            </div>
          </div>

          <div style={{ marginTop: 24 }}>
            <TUXButton text="Close" onClick={() => setVisible(false)} />
          </div>
        </div>
      </TUXSheet>
    </>
  );
};

export default Example;
```
