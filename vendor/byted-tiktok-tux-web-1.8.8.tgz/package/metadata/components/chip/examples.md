<!-- tux-web · components/chip/examples -->
> **TUX `chip` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/chip)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXChipGroup } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const items = [
    { itemKey: 'profanity', text: 'Profanity' },
    { itemKey: 'drugs', text: 'Drugs', disabled: true },
    { itemKey: 'violent', text: 'Violent' },
    { itemKey: 'firearms', text: 'Firearms' },
    { itemKey: 'info', trailing: <IconInfoCircle /> },
  ];
  const defaultSelectedKeys = ['violent'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXChipGroup items={items} defaultSelectedKeys={defaultSelectedKeys} />
    </div>
  );
};
export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXChipGroup } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const items = [
    { itemKey: 'profanity', text: 'Profanity' },
    { itemKey: 'drugs', text: 'Drugs', disabled: true },
    { itemKey: 'violent', text: 'Violent' },
    { itemKey: 'firearms', text: 'Firearms' },
    { itemKey: 'info', trailing: <IconInfoCircle /> },
  ];
  const defaultSelectedKeys = ['violent'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXChipGroup
        items={items}
        defaultSelectedKeys={defaultSelectedKeys}
        configForAll={{
          shapePreset: 'capsule',
        }}
      />
      <TUXChipGroup
        items={items}
        defaultSelectedKeys={defaultSelectedKeys}
        configForAll={{
          shapePreset: 'rectangle',
        }}
      />
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXChipGroup } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const items = [
    { itemKey: 'profanity', text: 'Profanity' },
    { itemKey: 'drugs', text: 'Drugs', disabled: true },
    { itemKey: 'violent', text: 'Violent' },
    { itemKey: 'firearms', text: 'Firearms' },
    { itemKey: 'info', trailing: <IconInfoCircle /> },
  ];
  const defaultSelectedKeys = ['violent'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXChipGroup
        items={items}
        defaultSelectedKeys={defaultSelectedKeys}
        configForAll={{
          multiSelect: true,
        }}
      />
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXChipGroup } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const items = [
    { itemKey: 'profanity', text: 'Profanity' },
    { itemKey: 'drugs', text: 'Drugs', disabled: true },
    { itemKey: 'violent', text: 'Violent' },
    { itemKey: 'firearms', text: 'Firearms' },
    { itemKey: 'info', trailing: <IconInfoCircle /> },
  ];
  const defaultSelectedKeys = ['violent'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXChipGroup
        items={items}
        defaultSelectedKeys={defaultSelectedKeys}
        configForAll={{
          quiet: true,
        }}
      />
    </div>
  );
};
export default Example;
```

## Example example-5

<a id="example-5"></a>

****: 



****:

```tsx
import { FC, useState } from 'react';
import { TUXChipGroup } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const items = [
    { itemKey: 'profanity', text: 'Profanity' },
    { itemKey: 'drugs', text: 'Drugs', disabled: true },
    { itemKey: 'violent', text: 'Violent' },
    { itemKey: 'firearms', text: 'Firearms' },
    { itemKey: 'info', trailing: <IconInfoCircle /> },
  ];
  const [selectedKeys, setSelectedKeys] = useState<number[]>([]);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXChipGroup
        items={items}
        selectedKeys={selectedKeys}
        onChange={(newSelectedKeys: number[]) => {
          setSelectedKeys(newSelectedKeys);
        }}
      />
    </div>
  );
};
export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXChipGroup } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const items = [
    { itemKey: 'profanity', text: 'Profanity' },
    { itemKey: 'drugs', text: 'Drugs', disabled: true },
    { itemKey: 'violent', text: 'Violent' },
    { itemKey: 'firearms', text: 'Firearms' },
    { itemKey: 'info', trailing: <IconInfoCircle /> },
  ];
  const defaultSelectedKeys = ['violent'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <TUXChipGroup items={items} defaultSelectedKeys={defaultSelectedKeys} fitContent />
      <TUXChipGroup items={items} defaultSelectedKeys={defaultSelectedKeys} fitContent={false} />
    </div>
  );
};
export default Example;
```
