<!-- tux-web · components/chip/props -->
> **TUX `chip` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/chip)

## `TUXChipGroup` props _(version: v1)_

_Props type: `TUXChipGroupProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TUXChipBaseProps[]` |  | Chip items of the chip group. |
| `fitContent?` | `boolean` | `true` | Whether the chip group hugs the content. |
| `defaultSelectedKeys?` | `string[]` |  | Default selected keys of the chip group, used in an uncontrolled mode. |
| `selectedKeys?` | `string[]` |  | Selected keys of the chip group, used in a controlled mode. |
| `onChange?` | `(selectedKeys: string[]) => void` |  | Change event handler of the chip group. Triggered when selected states change under the controlled mode. |
| `configForAll?` | `TUXChipSharedProps` |  | config for all items in the chip group. |

#### Referenced types

#### `TUXChipBaseProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `itemKey` | `string` |  | Unique identifier for the chip. |
| `text?` | `string` |  | Text to be displayed in the chip. |
| `leading?` | `React.ReactNode` |  | Custom leading action area of the chip. |
| `trailing?` | `React.ReactNode` |  | Custom trailing action area of the chip. |
| `selected?` | `boolean` |  | The selected state of the chip. * @default "false" |
| `disabled?` | `boolean` |  | Whether the chip is in a disabled(not interactive) state. |
| `onChange?` | `(e: React.MouseEvent<HTMLDivElement>, selected: boolean, selectedKey: string) => void` |  | The change handler of the chip. |
| `minWidth?` | `string` |  | Custom min-width of the chip. |
| `maxWidth?` | `string` |  | Custom max-width of the chip. |

#### `TUXChipSharedProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `shapePreset?` | `'capsule' \| 'rectangle'` | `capsule` | Preset shapes of the chip. |
| `multiSelect?` | `boolean` |  | Whether the chip is in a multi-select mode. |
| `quiet?` | `boolean` |  | Whether the chip is in a quiet mode. |

> `shapePreset` — @remarks
>
> - `capsule` — fully rounded pill-shape
> - `rectangle` — medium rounded corners

## `TUXChip` props _(version: v1)_

_Props type: `TUXChipProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `itemKey` | `string` |  | Unique identifier for the chip. |
| `text?` | `string` |  | Text to be displayed in the chip. |
| `leading?` | `React.ReactNode` |  | Custom leading action area of the chip. |
| `trailing?` | `React.ReactNode` |  | Custom trailing action area of the chip. |
| `selected?` | `boolean` |  | The selected state of the chip. * @default "false" |
| `disabled?` | `boolean` |  | Whether the chip is in a disabled(not interactive) state. |
| `onChange?` | `(e: React.MouseEvent<HTMLDivElement>, selected: boolean, selectedKey: string) => void` |  | The change handler of the chip. |
| `minWidth?` | `string` |  | Custom min-width of the chip. |
| `maxWidth?` | `string` |  | Custom max-width of the chip. |
| `shapePreset?` | `'capsule' \| 'rectangle'` | `capsule` | Preset shapes of the chip. |
| `multiSelect?` | `boolean` |  | Whether the chip is in a multi-select mode. |
| `quiet?` | `boolean` |  | Whether the chip is in a quiet mode. |

#### Detailed notes

> `shapePreset` — @remarks
>
> - `capsule` — fully rounded pill-shape
> - `rectangle` — medium rounded corners
