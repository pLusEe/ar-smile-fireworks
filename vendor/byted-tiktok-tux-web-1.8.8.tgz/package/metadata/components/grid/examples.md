<!-- tux-web · components/grid/examples -->
> **TUX `grid` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/grid)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXGrid, TUXGridCell } from '@byted-tiktok/tux-web';

const gridCellStyle = {
  backgroundColor: '#ddd',
};

const Example: FC = () => {
  return (
    <>
      <TUXGrid gap={10} paddingX={30} maxWidth={1200} style={{ height: '100px' }}>
        <TUXGridCell span={3} style={gridCellStyle}>
          span: 3
        </TUXGridCell>
        <TUXGridCell span={3} style={gridCellStyle}>
          span: 3
        </TUXGridCell>
        <TUXGridCell span={6} style={gridCellStyle}>
          span: 6
        </TUXGridCell>
      </TUXGrid>
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXGrid, TUXGridCell } from '@byted-tiktok/tux-web';

const gridCellStyle = {
  backgroundColor: '#ddd',
};

const Example: FC = () => {
  return (
    <>
      <TUXGrid columns={{ xs: 6, s: 10, l: 14 }} style={{ height: '100px' }}>
        <TUXGridCell span={{ xs: 2, s: 2, l: 4 }} style={gridCellStyle}>
          span: {JSON.stringify({ xs: 2, s: 2, l: 4 })}
        </TUXGridCell>
        <TUXGridCell span={{ xs: 2, s: 3, l: 4 }} style={gridCellStyle}>
          span: {JSON.stringify({ xs: 2, s: 3, l: 4 })}
        </TUXGridCell>
        <TUXGridCell span={{ xs: 2, s: 5, l: 6 }} style={gridCellStyle}>
          span: {JSON.stringify({ xs: 2, s: 5, l: 6 })}
        </TUXGridCell>
      </TUXGrid>
    </>
  );
};

export default Example;
```
