<!-- tux-web · components/grid/props -->
> **TUX `grid` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/grid)

## `TUXGrid` props _(version: v1)_

_Props type: `TUXGridProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `columns?` | `number \| TCommonResponsiveConfig<number>` | `12` | How many columns you want to separate, support responsive |
| `gap?` | `string \| number \| TCommonResponsiveConfig<string \| number>` | `16` | Set the gap between each cell, support responsive |
| `paddingX?` | `string \| number \| TCommonResponsiveConfig<string \| number>` | `32` | Set the Horizontal padding, support responsive |
| `maxWidth?` | `string \| number \| TCommonResponsiveConfig<string \| number>` |  | Set the max width of the grid container, support responsive, the default value is unset |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |

## `TUXGridCell` props _(version: v1)_

_Props type: `TUXGridCellProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `span?` | `number \| TCommonResponsiveConfig<number>` | `1` | How many span this cell want to take, support responsive |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |
