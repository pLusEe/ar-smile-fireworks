<!-- tux-web · components/tooltip/examples -->
> **TUX `tooltip` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/tooltip)

## Example example-1

<a id="example-1"></a>

```tsx
import { TUXButton, TUXTooltip } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return <TUXTooltip trigger={<TUXButton text="Hover Me" />} text="This is a tooltip" />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { TUXButton, TUXTooltip } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '1rem' }}>
      <TUXTooltip trigger={<TUXButton text="BlockStart" />} text="This is a tooltip" placement="BlockStart" />
      <TUXTooltip trigger={<TUXButton text="BlockEnd" />} text="This is a tooltip" placement="BlockEnd" />
      <TUXTooltip trigger={<TUXButton text="InlineStart" />} text="This is a tooltip" placement="InlineStart" />
      <TUXTooltip
        trigger={<TUXButton text="InlineEnd-Start" />}
        text="This is a tooltip, with longer text content, and hello world"
        placement="InlineEnd-Start"
      />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { IconPersonFill } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXTooltip, TUXTooltipLeadingImage } from '@byted-tiktok/tux-web';
import AvatarDemoImg from '~/images/avatar-demo.svg';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '1rem' }}>
      <TUXTooltip
        trigger={<TUXButton text="Hover Me" />}
        leadingIcon={<IconPersonFill />}
        leadingIconSize="large"
        showTrailingIcon
        text="This is a tooltip"
      />
      <TUXTooltip
        trigger={<TUXButton text="Hover Me" />}
        leading={<TUXTooltipLeadingImage src={AvatarDemoImg} shapePreset="round" />}
        text="This is a tooltip, which will display in 2 lines"
        placement="BlockEnd"
        showArrow
      />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { TUXButton, TUXTooltip } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  return (
    <TUXTooltip
      trigger={<TUXButton text="Hover Me" />}
      text="Controlled tooltip"
      visible={visible}
      onVisibleChange={setVisible}
    />
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXPopover, TUXFloatingRoot, TUXFloatingTrigger, TUXTooltip } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ height: 100, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <TUXFloatingRoot>
        <TUXFloatingTrigger>
          <TUXButton>Click me</TUXButton>
        </TUXFloatingTrigger>
        {/* id is needed when using several popovers or tooltips */}
        <TUXPopover id="popoverOne" placement="InlineStart" triggerMode="hover">
          <div style={{ padding: 12 }}>Popover content One</div>
        </TUXPopover>
        <TUXPopover id="popoverTwo" placement="InlineEnd" triggerMode="click">
          <div style={{ padding: 12 }}>Popover content Two</div>
        </TUXPopover>
        <TUXTooltip
          id="tooltipOne"
          placement="BlockEnd"
          triggerMode="click"
          text="Tooltip content down"
          offsetOptions={{ mainAxis: 60 }}
        />
      </TUXFloatingRoot>
    </div>
  );
};

export default Example;
```
