<!-- tux-web · components/tooltip/props -->
> **TUX `tooltip` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/tooltip)

## `TUXTooltip` props _(version: v1)_

_Props type: `TUXTooltipProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `trigger?` | `ReactElement` |  | Trigger element |
| `id?` | `string` |  | id of the tooltip, used to identify the tooltip when use together with other tooltips in same TUXFloatingRoot |
| `triggerMode?` | `TTriggerMode \| TTriggerMode[]` | `['hover', 'focus']` | Trigger mode, can be one of the following: 'click' \| 'hover' \| 'focus' |
| `placement?` | `TPopoverPlacement` | `'BlockStart'` | Placement of the tooltip relative to the trigger element, the value can be one of the following: 'BlockStart' \| 'BlockStart-Start' \| 'BlockStart-End' \| 'BlockEnd' \| 'BlockEnd-Start' \| 'BlockEnd-End' \| 'InlineStart' \| 'InlineStart-Start' \| 'InlineStart-End' \| 'InlineEnd' \| 'InlineEnd-Start' \| 'InlineEnd-End' |
| `root?` | `Parameters<typeof FloatingPortal>['0']['root']` | `null` | Root element of the tooltip, default is null, which means the tooltip will be rendered in the body element |
| `visible?` | `boolean` | `false` | Whether the tooltip is open |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback when the tooltip is open or closed |
| `showArrow?` | `boolean` | `false` | Whether to show arrow |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus tooltip when open |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether to dismiss the tooltip when click outside |
| `autoFlip?` | `boolean` | `false` | Whether to flip the tooltip when it is out of the viewport |
| `zIndex?` | `number` | `2200` | Z-index of the tooltip |
| `offsetOptions?` | `OffsetOptions` |  | Gap between the trigger element and the tooltip |
| `openDelay?` | `number` | `0` | Open delay duration(ms) when hovered. |
| `closeDelay?` | `number` | `150` | Close delay duration(ms) when hovered. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |
| `leadingIcon?` | `TLeadingElement` |  | Leading icon, can be any svg icon |
| `leadingIconSize?` | `'small' \| 'large'` | `'small'` | Leading icon size, can be 'small' or 'large' |
| `leading?` | `TLeadingElement` |  | Leading content, can be image, Avatar and other elements, should support size or style props |
| `text` | `string` |  | Text content |
| `showTrailingIcon?` | `boolean` |  | Whether to show trailing icon |
| `onContentClick?` | `MouseEventHandler<HTMLDivElement>` |  | Click event handler for the container. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `triggerMode` — TTriggerMode
>
> Trigger interaction(s) that open a floating element such as a popover or
> tooltip. Pass an array to enable multiple triggers at once.
> 
> - `click` — opens on click of the trigger; closes on outside click
> - `hover` — opens while the pointer hovers over the trigger
> - `focus` — opens while the trigger has keyboard focus

> `placement` — TPopoverPlacement
>
> Logical placement of a floating element relative to its trigger.
> 
> Names use logical (writing-direction-aware) axes so the same value renders
> correctly under both LTR and RTL:
> - `Block*` — vertical axis. `BlockStart` is above the trigger;
>   `BlockEnd` is below.
> - `Inline*` — horizontal axis. `InlineStart` is the leading side
>   (left in LTR, right in RTL); `InlineEnd` is the trailing side.
> - Plain `BlockStart` / `BlockEnd` / `InlineStart` / `InlineEnd` center the
>   floating element along the cross axis of the trigger.
> - `-Start` / `-End` suffixes pin the floating element to the start or end of
>   the cross axis instead (e.g. `BlockEnd-Start` opens below the trigger,
>   aligned to its leading edge).
