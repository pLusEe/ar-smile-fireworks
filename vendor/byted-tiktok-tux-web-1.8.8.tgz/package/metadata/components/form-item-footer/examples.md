<!-- tux-web · components/form-item-footer/examples -->
> **TUX `form-item-footer` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-item-footer)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXFormItemFooter, TUXInput } from '@byted-tiktok/tux-web';
import { IconExclamationMarkTriangleInline } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [value, setValue] = useState<string>('');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <TUXInput
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
        }}
      />
      <TUXFormItemFooter
        message="Message here"
        maxLengthExceededMessage="Word count exceeded limit"
        messageIcon={<IconExclamationMarkTriangleInline />}
        showCounter
        counterLength={value.length}
        counterMaxLength={25}
      />
    </div>
  );
};
export default Example;
```
