<!-- tux-web · components/form-item-footer/props -->
> **TUX `form-item-footer` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-item-footer)

## `TUXFormItemFooter` props _(version: v1)_

_Props type: `TUXFormItemFooterProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `message?` | `string` |  | Message of the input footer. |
| `maxLengthExceededMessage?` | `string` |  | Message displayed when counterLength exceeds counterMaxLength. |
| `invalid?` | `boolean` |  | Whether the input footer is in an error state. |
| `messageIcon?` | `React.ReactNode` |  | Custom message icon of the input footer, if set to null, there is no message icon |
| `showCounter?` | `boolean` |  | Whether to show the counter or not. |
| `counterLength?` | `number` |  | The length of the input value for the counter. |
| `counterMaxLength?` | `number` |  | The max length of the input value for the counter. |
