<!-- tux-web · components/status-view/examples -->
> **TUX `status-view` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/status-view)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXStatusView } from '@byted-tiktok/tux-web';
import { IllustrationEmptyHumanChatBubble } from '@tiktok-arch/tux-illustration/web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', width: '390px', border: '1px solid' }}>
      <TUXStatusView
        title="Request submitted!"
        message="Thanks for requesting a sample. The seller will respond within 3 days."
        image={<IllustrationEmptyHumanChatBubble />}
        footerButton={{ text: 'Comment Now', themePreset: 'primary' }}
      />
    </div>
  );
};
export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXStatusView } from '@byted-tiktok/tux-web';
import { IllustrationEmptyHumanChatBubble } from '@tiktok-arch/tux-illustration/web';

const Example: FC = () => {
  return (
    <div style={{ width: '390px', height: '650px', border: '1px solid' }}>
      <TUXStatusView
        title="Request submitted!"
        message="Thanks for requesting a sample. The seller will respond within 3 days."
        image={<IllustrationEmptyHumanChatBubble />}
        footerButton={{ text: 'Comment Now', themePreset: 'primary' }}
        fitContent={false}
      />
    </div>
  );
};
export default Example;
```
