<!-- tux-web · components/status-view/props -->
> **TUX `status-view` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/status-view)

## `TUXStatusView` props _(version: v1)_

_Props type: `TUXStatusViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `string` |  | Title of the status view. |
| `message?` | `React.ReactNode` |  | Message of the status view. |
| `image?` | `React.ReactNode` |  | Top image of the status view(this can usually be a banner or an illustration). |
| `fitContent?` | `boolean` | `true` | Whether the status view's height fit its content or not. |
| `footerButton?` | `TUXStatusViewFooterButtonProps` |  | The footer button of the status view. TUXStatusViewFooterButtonProps = {   text?: string;   themePreset?: "primary" \| "secondary";   shapePreset?: "normal" \| "capsule" \| "borderless";   disabled?: boolean;   onClick?: React.MouseEventHandler<HTMLButtonElement>; } |
| `customFooter?` | `React.ReactNode` |  | Custom footer area of the status view. |
| `titleResize?` | `boolean` |  | Whether to enable the text resize mode on title. |

#### Referenced types

#### `TUXStatusViewFooterButtonProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | The text content inside the button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `themePreset?` | `'primary' \| 'secondary'` | `primary` | Preset themes of the button. |
| `shapePreset?` | `'normal' \| 'capsule' \| 'borderless'` | `capsule` | Preset shapes of the button. |

> `themePreset` — @remarks
>
> - `primary` — UIShapePrimary (brand primary fill) background, UIShapeText1OnPrimary (high-contrast on primary) text; borderless variant: UITextPrimaryDisplay (brand-colored) text only
> - `secondary` — UIShapeNeutral4 (light neutral fill) background, UIText1 (primary text color) text; borderless variant: UIText1 text only

> `shapePreset` — @remarks
>
> - `normal` — standard rounded corners sized to the sizePreset
> - `capsule` — fully rounded pill-shape
> - `borderless` — no background or border, text-only
