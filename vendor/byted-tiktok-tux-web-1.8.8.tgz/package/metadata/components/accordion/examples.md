<!-- tux-web · components/accordion/examples -->
> **TUX `accordion` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/accordion)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { TUXAccordion, TUXAccordionItemProps } from '@byted-tiktok/tux-web';
const CONTENT =
  'Page Control is the process of splitting information over multiple pages instead of showing it all on a single page; also the name for the interface component used for navigating between these pages.';

const items: TUXAccordionItemProps[] = [
  {
    itemKey: 'craft',
    title: 'Showcase your craft',
    text: CONTENT,
  },
  {
    itemKey: 'engage',
    title: 'Enhance your engagement',
    text: CONTENT,
  },
  {
    itemKey: 'focus',
    title: 'Focus on your specialty',
    text: CONTENT,
    disabled: true,
  },
];

const Example: FC = () => {
  return <TUXAccordion items={items} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC } from 'react';
import { TUXAccordion, TUXAccordionItemProps } from '@byted-tiktok/tux-web';
const CONTENT =
  'Page Control is the process of splitting information over multiple pages instead of showing it all on a single page; also the name for the interface component used for navigating between these pages.';

const items: TUXAccordionItemProps[] = [
  {
    itemKey: 'craft',
    title: 'Showcase your craft',
    text: CONTENT,
  },
  {
    itemKey: 'engage',
    title: 'Enhance your engagement',
    text: CONTENT,
  },
  {
    itemKey: 'focus',
    title: 'Focus on your specialty',
    text: CONTENT,
  },
];

const Example: FC = () => {
  return (
    <TUXAccordion
      items={items}
      multiple={true}
      defaultActiveKey={['craft']}
      onChange={(activeKey) => {
        console.log('activeKey', activeKey);
      }}
    />
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC } from 'react';
import { TUXAccordion, TUXAccordionItemProps, TUXText } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';
const CONTENT =
  'Page Control is the process of splitting information over multiple pages instead of showing it all on a single page; also the name for the interface component used for navigating between these pages.';

const items: TUXAccordionItemProps[] = [
  {
    itemKey: 'craft',
    leading: <IconInfoCircle />,
    title: 'Showcase your craft',
    content: (
      <TUXText typographyPreset={'P2-Regular'} color={'UIText3'} as={'div'} style={{ marginLeft: 28 }}>
        {CONTENT}
      </TUXText>
    ),
  },
  {
    itemKey: 'engage',
    leading: <IconInfoCircle />,
    title: 'Enhance your engagement',
    content: (
      <TUXText typographyPreset={'P2-Regular'} color={'UIText3'} as={'div'} style={{ marginLeft: 28 }}>
        {CONTENT}
      </TUXText>
    ),
  },
  {
    itemKey: 'focus',
    leading: <IconInfoCircle />,
    title: 'Focus on your specialty',
    content: (
      <TUXText typographyPreset={'P2-Regular'} color={'UIText3'} as={'div'} style={{ marginLeft: 28 }}>
        {CONTENT}
      </TUXText>
    ),
  },
];

const Example: FC = () => {
  return (
    <TUXAccordion
      items={items}
      defaultActiveKey={['craft']}
      onChange={(activeKey) => {
        console.log('activeKey', activeKey);
      }}
    />
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC } from 'react';
import { TUXAccordion, TUXAccordionItemProps, TUXListView, TUXListHeader } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const CONTENT =
  'Page Control is the process of splitting information over multiple pages instead of showing it all on a single page; also the name for the interface component used for navigating between these pages.';

const items: TUXAccordionItemProps[] = [
  {
    itemKey: 'craft',
    leading: <IconInfoCircle />,
    title: 'Showcase your craft',
    text: CONTENT,
  },
  {
    itemKey: 'engage',
    leading: <IconInfoCircle />,
    title: 'Enhance your engagement',
    text: CONTENT,
  },
  {
    itemKey: 'focus',
    leading: <IconInfoCircle />,
    title: 'Focus on your specialty',
    text: CONTENT,
    disabled: true,
  },
];

const Example: FC = () => {
  return (
    <TUXListView header={<TUXListHeader title="Set audience" sizePreset={'large'} />}>
      <TUXAccordion items={items} />
    </TUXListView>
  );
};

export default Example;
```
