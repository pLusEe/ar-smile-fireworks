<!-- tux-web · components/accordion/props -->
> **TUX `accordion` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/accordion)

## `TUXAccordion` props _(version: v1)_

_Props type: `TUXAccordionProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TUXAccordionItemProps[]` |  | Array of accordion props data. { itemKey: string, title: string, leading?: React.ReactNode, text?: string, content?: React.ReactNode, disabled?: boolean } |
| `activeKey?` | `string[]` |  | Specify the current active accordion item by key. |
| `defaultActiveKey?` | `string[]` |  | Specify the initial active accordion item. |
| `multiple?` | `boolean` | `false` | Whether multiple Accordion items can be expanded at the same time. |
| `onChange?` | `(activeKey: string[]) => void` |  | Callback triggered when active accordion item changed. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Referenced types

#### `TUXAccordionItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `itemKey` | `string` |  | Unique identifier for the accordion item. |
| `title` | `string` |  | Title of the accordion item. |
| `leading?` | `React.ReactNode` |  | Custom content before the title. |
| `text?` | `string` |  | Text content expanded in the accordion item. |
| `content?` | `React.ReactNode` |  | Custom content expanded in the accordion item. |
| `disabled?` | `boolean` | `false` | Whether the accordion is disabled. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
