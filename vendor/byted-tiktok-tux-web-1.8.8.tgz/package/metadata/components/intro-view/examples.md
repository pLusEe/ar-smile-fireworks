<!-- tux-web · components/intro-view/examples -->
> **TUX `intro-view` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/intro-view)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { IllustrationMTTSNewTask } from '@tiktok-arch/tux-illustration/web';
import { TUXButton, TUXIntroPanel, TUXIntroView } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Intro Panel"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXIntroPanel
        visible={visible}
        onVisibleChange={setVisible}
        onClose={() => {
          setVisible(false);
          console.log('close button click');
        }}
        showCloseButton
      >
        <TUXIntroView
          image={<IllustrationMTTSNewTask />}
          title="Intro Title"
          message="Get notified about new interactions, messages, post recommendations, and more. Manage this in Settings at any time."
          footerActions={[
            {
              text: 'Confirm',
              themePreset: 'primary',
              onClick: () => {
                setVisible(false);
              },
            },
          ]}
        />
      </TUXIntroPanel>
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { IconStarLight, IconPost } from '@byted-tiktok/tux-icons';
import { IllustrationMTTSNewTask } from '@tiktok-arch/tux-illustration/web';
import { TUXButton, TUXCheckbox, TUXIntroPanel, TUXIntroView } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Intro Panel"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXIntroPanel visible={visible} onVisibleChange={setVisible}>
        <TUXIntroView
          image={<IllustrationMTTSNewTask />}
          title="Intro Title"
          message="Get notified about new interactions, messages, post recommendations, and more. Manage this in Settings at any time."
          contentList={[
            {
              title: 'Visual Elements',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconStarLight />,
              trailing: <TUXCheckbox name="Visual Elements" value="visualElements" defaultChecked />,
            },
            {
              title: 'Call to Action',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconPost />,
              trailing: <TUXCheckbox name="Call to Action" value="callToAction" defaultChecked />,
            },
          ]}
          footerActions={[
            {
              text: 'Confirm',
              themePreset: 'primary',
              onClick: () => {
                setVisible(false);
              },
            },
          ]}
        />
      </TUXIntroPanel>
    </>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import { IconStarLight, IconPost } from '@byted-tiktok/tux-icons';
import { IllustrationMTTSNewTask } from '@tiktok-arch/tux-illustration/web';
import { TUXButton, TUXCheckbox, TUXIntroPanel, TUXIntroView } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [verticalActionVisible, setVerticalActionVisible] = useState(false);
  const [horizontalActionVisible, setHorizontalActionVisible] = useState(false);

  return (
    <div style={{ display: 'flex', gap: '12px' }}>
      <TUXButton
        text="Vertical Footer Buttons"
        onClick={(): void => {
          setVerticalActionVisible(true);
        }}
      />
      <TUXButton
        text="Horizontal Footer Buttons"
        onClick={(): void => {
          setHorizontalActionVisible(true);
        }}
      />
      <TUXIntroPanel visible={verticalActionVisible} onVisibleChange={setVerticalActionVisible}>
        <TUXIntroView
          image={<IllustrationMTTSNewTask />}
          title="Intro Title"
          message="Get notified about new interactions, messages, post recommendations, and more. Manage this in Settings at any time."
          contentList={[
            {
              title: 'Visual Elements',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconStarLight />,
              trailing: <TUXCheckbox name="Visual Elements" value="visualElements" defaultChecked />,
            },
            {
              title: 'Call to Action',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconPost />,
              trailing: <TUXCheckbox name="Call to Action" value="callToAction" defaultChecked />,
            },
          ]}
          footerActions={[
            {
              text: 'Confirm',
              themePreset: 'primary',
              onClick: () => {
                setVerticalActionVisible(false);
              },
            },
            {
              text: 'Not now',
              onClick: () => {
                setVerticalActionVisible(false);
              },
            },
          ]}
        />
      </TUXIntroPanel>
      <TUXIntroPanel visible={horizontalActionVisible} onVisibleChange={setHorizontalActionVisible}>
        <TUXIntroView
          image={<IllustrationMTTSNewTask />}
          title="Intro Title"
          message="Get notified about new interactions, messages, post recommendations, and more. Manage this in Settings at any time."
          contentList={[
            {
              title: 'Visual Elements',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconStarLight />,
              trailing: <TUXCheckbox name="Visual Elements" value="visualElements" defaultChecked />,
            },
            {
              title: 'Call to Action',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconPost />,
              trailing: <TUXCheckbox name="Call to Action" value="callToAction" defaultChecked />,
            },
          ]}
          actionDirection="horizontal"
          footerActions={[
            {
              text: 'Confirm',
              themePreset: 'primary',
              onClick: () => {
                setHorizontalActionVisible(false);
              },
            },
            {
              text: 'Not now',
              onClick: () => {
                setHorizontalActionVisible(false);
              },
            },
          ]}
        />
      </TUXIntroPanel>
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC, useState } from 'react';
import { IconStarLight, IconPost } from '@byted-tiktok/tux-icons';
import { IllustrationMTTSNewTask } from '@tiktok-arch/tux-illustration/web';
import { TUXButton, TUXCheckbox, TUXIntroPanel, TUXIntroView, TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Intro Panel"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXIntroPanel visible={visible} onVisibleChange={setVisible}>
        <TUXIntroView
          image={<IllustrationMTTSNewTask />}
          title="Intro Title"
          message="Get notified about new interactions, messages, post recommendations, and more. Manage this in Settings at any time."
          contentList={[
            {
              title: 'Visual Elements',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconStarLight />,
              trailing: <TUXCheckbox name="Visual Elements" value="visualElements" defaultChecked />,
            },
            {
              title: 'Call to Action',
              description: 'Use a clean and minimalistic design',
              leadingIcon: <IconPost />,
              trailing: <TUXCheckbox name="Call to Action" value="callToAction" defaultChecked />,
            },
          ]}
          footerActions={[
            {
              text: 'Confirm',
              themePreset: 'primary',
              onClick: () => {
                setVisible(false);
              },
            },
          ]}
          customFooter={
            <div style={{ display: 'flex', flexDirection: 'column', padding: '12px 28px 28px' }}>
              <TUXButton
                text="Custom Footer"
                themePreset="primary"
                onClick={() => {
                  setVisible(false);
                }}
              />
              <div style={{ display: 'flex', paddingBlockStart: '12px' }}>
                <TUXCheckbox name="footer message" value="footer_message" sizePreset="small" />
                <TUXText typographyPreset="P2-Regular" color="UIText2" style={{ paddingInlineStart: '8px' }}>
                  Save login info on your iCloud devices to log in automatically next time.
                </TUXText>
              </div>
            </div>
          }
        />
      </TUXIntroPanel>
    </>
  );
};

export default Example;
```
