<!-- tux-web · components/intro-view/props -->
> **TUX `intro-view` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/intro-view)

## `TUXIntroView` props _(version: v1)_

_Props type: `TUXIntroViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `string` |  | Title of the intro view. |
| `message?` | `React.ReactNode` |  | Message of the intro view. |
| `image?` | `React.ReactNode` |  | Top image of the intro view. |
| `contentList?` | `TUXIntroViewListCellProps[]` |  | The content list part of the intro view. |
| `customFooter?` | `React.ReactNode` |  | Custom footer area of the status view. |
| `titleResize?` | `boolean` |  | Whether to enable the text resize mode on title. |
| `actionDirection?` | `'horizontal' \| 'vertical'` | `'vertical'` | Action direction of the intro view footer actions. |
| `footerActions?` | `\| [TUXIntroViewPrimaryFooterActionProps]     \| [TUXIntroViewPrimaryFooterActionProps, TUXIntroViewSecondaryFooterActionProps]` |  | The footer button of the intro view. Maximum button count: 2 TUXIntroViewPrimaryFooterActionProps = {   text?: string;   themePreset?: "primary" \| "secondary";   shapePreset?: "normal" \| "capsule" \| "borderless";   disabled?: boolean;   onClick?: React.MouseEventHandler<HTMLButtonElement>; } TUXIntroViewSecondaryFooterActionProps = {   text?: string;   shapePreset?: "normal" \| "capsule" \| "borderless";   disabled?: boolean;   onClick?: React.MouseEventHandler<HTMLButtonElement>; } |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Referenced types

#### `TUXIntroViewListCellProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `string` |  | The title of the intro view list cell. |
| `description?` | `string` |  | The description of the intro view list cell. |
| `trailing?` | `React.ReactNode` |  | Trailing area of the intro view list cell. |
| `leadingIcon?` | `React.ReactNode` |  | Leading icon of the intro view list cell. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Callback event triggered when the intro view list cell is clicked, set this to make the intro view list cell to be interactive. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### `TUXIntroViewPrimaryFooterActionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | The text content inside the button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `themePreset?` | `'primary' \| 'secondary'` | `primary` | Preset themes of the button. |
| `shapePreset?` | `'normal' \| 'capsule' \| 'borderless'` | `capsule` | Preset shapes of the button. |

> `themePreset` — @remarks
>
> - `primary` — UIShapePrimary (brand primary fill) background, UIShapeText1OnPrimary (high-contrast on primary) text; borderless variant: UITextPrimaryDisplay (brand-colored) text only
> - `secondary` — UIShapeNeutral4 (light neutral fill) background, UIText1 (primary text color) text; borderless variant: UIText1 text only

> `shapePreset` — @remarks
>
> - `normal` — standard rounded corners sized to the sizePreset
> - `capsule` — fully rounded pill-shape
> - `borderless` — no background or border, text-only

#### `TUXIntroViewSecondaryFooterActionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | The text content inside the button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `shapePreset?` | `'normal' \| 'capsule' \| 'borderless'` | `capsule` | Preset shapes of the button. |

> `shapePreset` — @remarks
>
> - `normal` — standard rounded corners sized to the sizePreset
> - `capsule` — fully rounded pill-shape
> - `borderless` — no background or border, text-only
