<!-- tux-web · components/loading-toast/examples -->
> **TUX `loading-toast` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/loading-toast)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXLoadingToast } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Loading Toast"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXLoadingToast text="Loading..." visible={visible} onVisibleChange={setVisible} showCloseButton />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXLoadingToast } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXButton
        text="Loading Toast with loading progress"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXLoadingToast text="Loading..." visible={visible} onVisibleChange={setVisible} showCloseButton progress={60} />
    </div>
  );
};

export default Example;
```
