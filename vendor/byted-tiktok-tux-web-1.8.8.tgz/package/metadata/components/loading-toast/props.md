<!-- tux-web · components/loading-toast/props -->
> **TUX `loading-toast` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/loading-toast)

## `TUXLoadingToast` props _(version: v1)_

_Props type: `TUXLoadingToastProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | Text to be displayed under the loading image. |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether clicking the overlay closes the loading toast. |
| `zIndex?` | `number` | `2300` |  |
| `showCloseButton?` | `boolean` |  | Whether to show the close button or not. |
| `progress?` | `number` |  | The progress number of the loading progress( should between 0-100, if it is set, the loading image will be a loading progress ) |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
