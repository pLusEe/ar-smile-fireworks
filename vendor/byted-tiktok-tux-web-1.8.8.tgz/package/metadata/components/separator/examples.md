<!-- tux-web · components/separator/examples -->
> **TUX `separator` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/separator)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { TUXSeparator, useTheme } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const theme = useTheme();
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '8px',
        padding: '8px',
        backgroundColor: theme === 'dark' ? 'darkslategrey' : 'aquamarine',
        height: 70,
      }}
    >
      <TUXSeparator thickness={'thick'} direction={'horizontal'} />
      <TUXSeparator thickness={'thin'} direction={'horizontal'} />
      <div style={{ height: '10px' }}>
        <TUXSeparator thickness={'thick'} direction={'vertical'} />
      </div>
      <div style={{ height: '10px' }}>
        <TUXSeparator thickness={'thin'} direction={'vertical'} />
      </div>
    </div>
  );
};

export default Example;
```
