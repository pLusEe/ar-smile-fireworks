<!-- tux-web · components/separator/props -->
> **TUX `separator` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/separator)

## `TUXSeparator` props _(version: v1)_

_Props type: `TUXSeparatorProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `thickness?` | `'thin' \| 'thick'` | `'thin'` | Preset thickness of the separator. |
| `direction?` | `'horizontal' \| 'vertical'` | `'horizontal'` | Direction of the separator. |
| `height?` | `string` |  | Custom height of the separator. |
| `width?` | `string` |  | Custom width of the separator. |
| `color?` | `TColorWithToken` |  | Custom color of the separator. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |

#### Detailed notes

> `color` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
