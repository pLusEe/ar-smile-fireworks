<!-- tux-web · components/form-view/props -->
> **TUX `form-view` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-view)

## `TUXFormView` props _(version: v1)_

_Props type: `TUXFormViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `string` |  | Title of the form view. |
| `subtitle?` | `string` |  | Subtitle of the form view. |
| `infoIcon?` | `React.ReactNode` |  | Info icon of the form view. Usually used with tooltip/sheet to hide more information. |
| `showTopSeparator?` | `boolean` |  | Whether to have the top separator or not. |
| `message?` | `string` |  | Message of the form view. |
| `messageIcon?` | `React.ReactNode` |  | Custom message icon of the form view, if set to null, there is no message icon |
| `invalid?` | `boolean` |  | Whether the form view is in an error state. |

_Also extends: `TPropsWithoutCustomStyle<React.FormHTMLAttributes<HTMLFormElement>>`_
