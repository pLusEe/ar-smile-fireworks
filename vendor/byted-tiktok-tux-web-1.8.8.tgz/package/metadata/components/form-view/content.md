<!-- tux-web · components/form-view/content -->
> **TUX `form-view` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-view)

_See example: [example example-1](./examples.md#example-1)_
