<!-- tux-web · components/form-view/examples -->
> **TUX `form-view` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/form-view)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXFormView, TUXFormItem, TUXInput, TUXFormItemHeader, TUXRadio, TUXText } from '@byted-tiktok/tux-web';
import { IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const options = ['coffee', 'tea', 'juice'];
  const [checkedItem, setCheckedItem] = useState<string>();
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    if (e.target.checked) {
      setCheckedItem(e.target.value);
    }
  };
  return (
    <TUXFormView
      title="Title"
      subtitle="Subtitle"
      infoIcon={<IconInfoCircle />}
      message="Username can contain only letter, numbers, underscores, and periods. Changing your username will also change your profile link."
    >
      <TUXFormItem>
        <TUXFormItemHeader title="Username" showRequiredMark />
        <TUXInput placeholder="Username" />
      </TUXFormItem>
      <TUXFormItem>
        <TUXFormItemHeader title="Email" infoIcon={<IconInfoCircle />} />
        <TUXInput placeholder="Email" />
      </TUXFormItem>
      <TUXFormItem>
        <TUXFormItemHeader title="Choose your drink" />
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            paddingBlock: '8px',
            paddingInline: '4px',
            gap: '16px',
          }}
        >
          {options.map((option) => (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }} key={option}>
              <TUXRadio name="color" value={option} checked={checkedItem === option} onChange={handleChange} />
              <TUXText typographyPreset="Headline-Regular">{option}</TUXText>
            </div>
          ))}
        </div>
      </TUXFormItem>
    </TUXFormView>
  );
};
export default Example;
```
