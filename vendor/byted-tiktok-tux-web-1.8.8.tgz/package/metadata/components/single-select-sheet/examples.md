<!-- tux-web · components/single-select-sheet/examples -->
> **TUX `single-select-sheet` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/item-picker)

## Example example-1

<a id="example-1"></a>

```tsx
import { TUXSingleSelectSheet, TUXSelectBox } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState('');

  const options = Array(7)
    .fill(null)
    .map((_, index) => ({
      title: `Option ${index + 1}`,
      value: `option-${index + 1}`,
    }));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TUXSelectBox
        placeholder="Open Single Select Sheet"
        value={options.find((item) => item.value === value)?.title}
        onClick={() => setVisible(true)}
      />

      <TUXSingleSelectSheet
        value={value}
        visible={visible}
        title="Single Select Sheet"
        options={options.map((option, index) => ({
          ...option,
          name: 'single select option',
          disabled: index === 3,
        }))}
        onChange={(value) => {
          setValue(value ?? '');
        }}
        onVisibleChange={(visible) => {
          setVisible(visible);
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { TUXMultiSelectSheet, TUXButton, TUXText, TUXSelectBox } from '@byted-tiktok/tux-web';
import React, { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState<string[]>([]);

  const options = Array(7)
    .fill(null)
    .map((_, index) => ({
      title: `Option ${index + 1}`,
      value: `option-${index + 1}`,
    }));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TUXSelectBox
        placeholder="Open Multi Select Sheet"
        value={options
          .filter((item) => value.includes(item.value))
          .map((item) => item.title)
          .join(', ')}
        onClick={() => setVisible(true)}
      />
      <TUXMultiSelectSheet
        visible={visible}
        title="Multi Select Sheet"
        options={options.map((option, index) => ({
          ...option,
          name: 'multi select option',
          disabled: index === 3,
        }))}
        onVisibleChange={(visible) => {
          setVisible(visible);
        }}
        onSubmit={(value) => {
          setValue(value);
          setVisible(false);
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { TUXMultiSelectSheet, TUXButton, TUXText } from '@byted-tiktok/tux-web';
import React, { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState<string[]>([]);

  const options = Array(7).fill(null);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TUXButton text="Open Multi Select Sheet" onClick={() => setVisible(true)} />

      <TUXText typographyPreset="P2-Regular" color={'UIText3'}>
        Single Select Value: {value.join(', ')}
      </TUXText>
      <TUXMultiSelectSheet
        visible={visible}
        title="Multi Select Sheet"
        options={options.map((_, index) => ({
          title: `Option ${index + 1}`,
          description: `Description ${index + 1}`,
          name: `option-${index + 1}`,
          value: `option ${index + 1}`,
          disabled: index === 3,
        }))}
        onVisibleChange={(visible) => {
          setVisible(visible);
        }}
        renderFooter={({ value, updateValue }) => {
          return (
            <div style={{ padding: '16px 16px 12px 16px', display: 'flex', gap: 8 }}>
              <div style={{ flexGrow: 1 }}>
                <TUXButton
                  text="Clear"
                  themePreset="secondary"
                  sizePreset="large"
                  width="100%"
                  onClick={() => {
                    updateValue([]);
                    setValue([]);
                  }}
                />
              </div>
              <div style={{ flexGrow: 1 }}>
                <TUXButton
                  text="Submit"
                  sizePreset="large"
                  width="100%"
                  onClick={() => {
                    setValue(value);
                    setVisible(false);
                  }}
                />
              </div>
            </div>
          );
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { IconChevronRightOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import {
  TUXButton,
  TUXText,
  TUXItemPickerView,
  TUXListCell,
  TUXListCellProps,
  TUXListView,
  TUXNavBar,
  TUXNavBarIconAction,
  TUXRadio,
  TUXSheet,
  TUXSheetProps,
} from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const mockParentData = {
  'option 1': ['option 1-1', 'option 1-2'],
  'option 2': ['option 2-1', 'option 2-2'],
  'option 3': ['option 3-1', 'option 3-2'],
  'option 4': ['option 4-1', 'option 4-2'],
};

const ParentItemPickerSheet: FC<{
  visible: boolean;
  onVisibleChange: TUXSheetProps['onVisibleChange'];
  onChange: (value: string) => void;
}> = ({ visible, onVisibleChange, onChange }) => {
  const [selectedParent, setSelectedParent] = useState<keyof typeof mockParentData>();

  const data = selectedParent ? mockParentData[selectedParent] : Object.keys(mockParentData);

  const renderListCellProps: TUXListCellProps[] = data.map((key) => {
    if (selectedParent) {
      return {
        title: key,
        name: key,
        key,
        trailing: <TUXRadio name={key} value={key} sizePreset="large" />,
        onClick: () => {
          onChange(key);
          setSelectedParent(undefined);
        },
      };
    }

    return {
      title: key,
      name: key,
      key,
      trailing: <IconChevronRightOffsetLTR />,
      onClick: () => {
        setSelectedParent(key as keyof typeof mockParentData);
      },
    };
  });

  return (
    <TUXSheet visible={visible} onVisibleChange={onVisibleChange}>
      <TUXItemPickerView
        header={
          <TUXNavBar
            title={'Parent Item Picker Sheet'}
            trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => onVisibleChange?.(false)} />}
            backgroundColor={'UISheetFlat1'}
          />
        }
      >
        <TUXListView>
          {renderListCellProps.map((props, index) => {
            return <TUXListCell key={index} {...props} />;
          })}
        </TUXListView>
      </TUXItemPickerView>
    </TUXSheet>
  );
};

const Example: FC = () => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState('');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TUXButton text="Open Parent Item Picker Sheet" onClick={() => setVisible(true)} />

      <TUXText typographyPreset="P2-Regular" color={'UIText3'}>
        Single Select Value: {value}
      </TUXText>

      <ParentItemPickerSheet
        visible={visible}
        onChange={(value) => {
          setValue(value);
          setVisible(false);
        }}
        onVisibleChange={(visible) => {
          setVisible(visible);
        }}
      />
    </div>
  );
};

export default Example;
```
