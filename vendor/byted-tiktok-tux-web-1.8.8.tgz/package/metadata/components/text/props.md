<!-- tux-web · components/text/props -->
> **TUX `text` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/text)

## `TUXText` props _(version: v1)_

_Props type: `TUXTextProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `typographyPreset?` | `TTUXTypographyPreset` |  | Typography preset of tux. |
| `font?` | `'TikTokFont' \| 'TikTokDisplayFont'` |  | Font family of the text. |
| `size?` | `number` |  | Font size in pixels. |
| `color?` | `TColorWithToken` |  | Color of the text. |
| `weight?` | `number` |  | Weight of the font. |
| `align?` | `'start' \| 'center' \| 'end'` |  | Aligns text based on the parent container. |
| `textDisplay?` | `'truncate' \| 'lineBreak'` |  | The text overflow behavior. |
| `italic?` | `boolean` |  | Applies the italic font style to the content. |
| `underline?` | `boolean` |  | Applies the underline text decoration to the content. |
| `strikethrough?` | `boolean` |  | Applies the strikethrough text decoration to the content. |
| `as?` | `'div' \| 'span' \| 'p' \| 'h1' \| 'h2' \| 'h3' \| 'h4' \| 'h5' \| 'h6' \| 'pre' \| 'label'` | `span` | Container element tag, default tag is 'span' |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |

#### Detailed notes

> `typographyPreset` — TTUXTypographyPreset
>
> Valid typography preset combinations in `{Size}-{Weight}` format.
> 
> Combines a size preset with a weight preset (e.g., `'H1-Bold'`, `'P1-Regular'`).
> Not all combinations are valid:
> - Body/small sizes (P1–P3, SmallText1–2) do **not** support `Bold`
> - Large sizes (H1, LargeTitle) do **not** support `Regular`
> 
> Common presets and their visual meaning:
> - `'H1-Bold'` — 24px bold, for top-level headings
> - `'H2-Semibold'` — 20px semibold, for section headings
> - `'H3-Semibold'` — 17px semibold, for sub-headings
> - `'Headline-Semibold'` — 16px semibold, for emphasized inline text
> - `'Headline-Regular'` — 16px regular, for standard inline text at headline size
> - `'P1-Regular'` — 14px regular, standard body text
> - `'P2-Regular'` — 13px regular, secondary body text
> - `'SmallText1-Regular'` — 11px regular, captions and labels

> `color` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
