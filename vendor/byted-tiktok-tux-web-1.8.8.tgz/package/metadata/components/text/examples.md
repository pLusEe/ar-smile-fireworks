<!-- tux-web · components/text/examples -->
> **TUX `text` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/text)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXText } from '@byted-tiktok/tux-web';

<TUXText typographyPreset={'P1-Regular'} color={'UIText3'}>Lorem ipsum</TUXText>
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXText } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <>
      <TUXText typographyPreset="H2-Bold">Lorem ipsum</TUXText>
      <br />
      <TUXText size={36} weight={600}>
        Lorem ipsum
      </TUXText>
    </>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
<>
  <TUXText as="div">Div</TUXText>
  <TUXText as="span">Span 1</TUXText>
  <TUXText as="span">Span 2</TUXText>
</>
```

## Example example-4

<a id="example-4"></a>

```tsx
<TUXText as="div" textDisplay="truncate">{'Hello world! '.repeat(20)}</TUXText>
```

## Example example-5

<a id="example-5"></a>

```tsx
<>
  <TUXText as="div" align="start">Start</TUXText>
  <TUXText as="div" align="center">Center</TUXText>
  <TUXText as="div" align="end">End</TUXText>
</>
```
