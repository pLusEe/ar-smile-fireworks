<!-- tux-web · components/vertical-steps/examples -->
> **TUX `vertical-steps` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/vertical-steps)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXVerticalSteps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const items = [
    {
      title: 'Step 1',
      description: 'Step 1 Description',
      caption: 'San Francisco, CA · Apr 12',
    },
    {
      title: 'Step 2',
      description: 'Step 2 Description',
      caption: 'San Francisco, CA · Apr 13',
    },
    {
      title: 'Step 3',
      description: 'Step 3 Description',
      caption: 'San Francisco, CA · Apr 14',
    },
    {
      title: 'Step 4',
      description: 'Step 4 Description',
      caption: 'San Francisco, CA · Apr 15',
    },
    {
      title: 'Step 5',
      description: 'Step 5 Description',
      caption: 'San Francisco, CA · Apr 16',
    },
  ];
  return <TUXVerticalSteps items={items} current={2} />;
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXVerticalSteps } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const items = [
    {
      title: 'Step 1',
      description: 'Step 1 Description',
      caption: 'San Francisco, CA · Apr 12',
    },
    {
      title: 'Step 2',
      description: 'Step 2 Description',
      caption: 'San Francisco, CA · Apr 13',
    },
    {
      title: 'Step 3',
      description: 'Step 3 Description',
      caption: 'San Francisco, CA · Apr 14',
    },
    {
      title: 'Step 4',
      description: 'Step 4 Description',
      caption: 'San Francisco, CA · Apr 15',
    },
    {
      title: 'Step 5',
      description: 'Step 5 Description',
      caption: 'San Francisco, CA · Apr 16',
    },
  ];
  return <TUXVerticalSteps items={items} current={2} collapse />;
};

export default Example;
```
