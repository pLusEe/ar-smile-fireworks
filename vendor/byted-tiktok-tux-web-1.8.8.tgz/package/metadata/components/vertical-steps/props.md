<!-- tux-web · components/vertical-steps/props -->
> **TUX `vertical-steps` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/vertical-steps)

## `TUXVerticalSteps` props _(version: v1)_

_Props type: `TUXVerticalStepsProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TTUXVerticalStepItems[]` |  | Steps of the vertical step panel. |
| `current` | `number` |  | Index of the current step. |
| `collapse?` | `boolean` |  | Whether to collapse when steps >= 4. |
| `completedDotColor?` | `TColorWithToken` |  | Custom node dot color(only completed part). |
| `completedStrokeColor?` | `TColorWithToken` |  | Custom stroke color(only completed part). |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `completedDotColor`, `completedStrokeColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TTUXVerticalStepItems`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `string` |  | Title of the vertical step item. |
| `description?` | `React.ReactNode` |  | Description of the vertical step item. |
| `caption?` | `React.ReactNode` |  | Caption of the vertical step item. |
