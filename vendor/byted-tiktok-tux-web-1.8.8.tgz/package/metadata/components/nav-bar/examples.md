<!-- tux-web · components/nav-bar/examples -->
> **TUX `nav-bar` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/nav-bar)

## Example example-1

<a id="example-1"></a>

```tsx
import { TUXNavBar } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return (
    <>
      <TUXNavBar title="Navigation title" showSeparator={true} />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC } from 'react';
import { TUXNavBar, TUXNavBarTextAction } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <TUXNavBar
      title="Navigation title"
      subtitle="Subtitle"
      leading={<TUXNavBarTextAction text="Cancel" themePreset="secondary" onClick={() => console.log('click')} />}
      trailing={<TUXNavBarTextAction text="Done" themePreset="primary" onClick={() => console.log('click')} />}
    />
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC } from 'react';
import { TUXNavBar, TUXNavBarIconAction } from '@byted-tiktok/tux-web';
import { IconAddShoppingCart, IconChevronLeftOffsetLTR } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXNavBar
      title="Navigation title"
      subtitle="Subtitle"
      leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} onClick={() => console.log('click')} />}
      trailing={<TUXNavBarIconAction icon={<IconAddShoppingCart />} onClick={() => console.log('click')} />}
    />
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC } from 'react';
import { TUXNavBar, TUXNavBarIconAction, TUXNavBarCloseButton } from '@byted-tiktok/tux-web';
import { IconChevronLeftOffsetLTR } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXNavBar
      title="Navigation title"
      subtitle="Subtitle"
      leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} onClick={() => console.log('click')} />}
      trailing={<TUXNavBarCloseButton onClick={() => console.log('close')} />}
    />
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import React, { FC } from 'react';
import { TUXNavBar, TUXNavBarIconAction, TUXButton } from '@byted-tiktok/tux-web';
import { IconChevronLeftOffsetLTR } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXNavBar
      title="Navigation title"
      subtitle="Subtitle"
      leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} onClick={() => console.log('click')} />}
      trailing={
        <TUXButton text="Button" sizePreset="small" shapePreset="normal" onClick={() => console.log('click')} />
      }
    />
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXNavBar, TUXNavBarIconAction, TUXNavBarTitle } from '@byted-tiktok/tux-web';
import { IconAddShoppingCart, IconChevronLeftOffsetLTR, IconTiktokLogoCircleFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [trailingDefault, setTrailingDefault] = useState<'triangleUp' | 'triangleDown'>('triangleUp');
  return (
    <TUXNavBar
      customTitle={
        <TUXNavBarTitle
          title="Custom Title"
          subtitle="Subtitle"
          leading={<IconTiktokLogoCircleFill />}
          trailingDefault={trailingDefault}
          onTitleClick={() => {
            setTrailingDefault(trailingDefault === 'triangleUp' ? 'triangleDown' : 'triangleUp');
          }}
        />
      }
      leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} onClick={() => console.log('click')} />}
      trailing={<TUXNavBarIconAction icon={<IconAddShoppingCart />} onClick={() => console.log('click')} />}
    />
  );
};

export default Example;
```

## Example example-7

<a id="example-7"></a>

****

```tsx
import { FC } from 'react';
import { TUXNavBar, TUXNavBarIconAction } from '@byted-tiktok/tux-web';
import {
  IconChevronLeftOffsetLTR,
  IconArrowTurnUpRight,
  IconBookmark,
  IconLinesHorizontalDecreaseAlt,
} from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <>
      <TUXNavBar
        title="Navigation title"
        subtitle="Subtitle"
        leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} onClick={() => console.log('click')} />}
        trailing={
          <>
            <TUXNavBarIconAction
              icon={<IconArrowTurnUpRight />}
              onClick={() => console.log('click')}
              width="36px"
              height="44px"
              padding="10px 6px"
            />
            <TUXNavBarIconAction
              icon={<IconBookmark />}
              onClick={() => console.log('click')}
              width="36px"
              height="44px"
              padding="10px 6px"
            />
            <TUXNavBarIconAction
              icon={<IconLinesHorizontalDecreaseAlt />}
              onClick={() => console.log('click')}
              width="36px"
              height="44px"
              padding="10px 6px"
            />
          </>
        }
        titleAlign="start"
      />
    </>
  );
};

export default Example;
```

## Example example-8

<a id="example-8"></a>

```tsx
import { TUXNavBar } from '@byted-tiktok/tux-web';
import { FC } from 'react';

const Example: FC = () => {
  return (
    <div style={{ overflow: 'auto', background: 'var(--tux-v2-color-ui-shape-secondary-4)' }}>
      <TUXNavBar
        title="Navigation title"
        showTopSafeArea={true}
        fixed={true}
        showPlaceHolder={true}
        showSeparator={true}
      />
      <div
        style={{
          height: '150vh',
          display: 'flex',
          flexDirection: 'column',
          gap: '52px',
        }}
      >
        <div>first content</div>
        <div>second content</div>
        <div>third content</div>
      </div>
    </div>
  );
};

export default Example;
```

## Example example-9

<a id="example-9"></a>

```tsx
import { TUXNavBar } from '@byted-tiktok/tux-web';
import { FC, useEffect, useRef, useState } from 'react';

const Example: FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const el = ref.current;
    console.log('el', el);
    const startPosition = 10;
    const endPosition = 50;

    const scrollListener = (): void => {
      const scrollTop = el?.scrollTop ?? 0;
      if (endPosition - startPosition === 0) {
        return;
      }

      if (scrollTop >= startPosition && scrollTop <= endPosition) {
        setProgress((scrollTop - startPosition) / (endPosition - startPosition));
      } else if (scrollTop < startPosition) {
        setProgress(0);
      } else {
        setProgress(1);
      }
    };

    el?.addEventListener('scroll', scrollListener);
    return (): void => {
      el?.removeEventListener('scroll', scrollListener);
    };
  }, []);

  return (
    <div
      style={{ overflow: 'auto', background: 'var(--tux-v2-color-ui-shape-secondary-4)', height: '100vh' }}
      ref={ref}
    >
      <TUXNavBar
        title="Navigation title"
        showTopSafeArea={true}
        fixed={true}
        showPlaceHolder={true}
        showSeparator={progress > 0.95}
        backgroundOpacity={progress}
        titleOpacity={progress}
      />
      <div
        style={{
          height: '150vh',
          display: 'flex',
          flexDirection: 'column',
          gap: '52px',
        }}
      >
        <div>first content</div>
        <div>second content</div>
        <div>third content</div>
      </div>
    </div>
  );
};

export default Example;
```
