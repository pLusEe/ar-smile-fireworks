<!-- tux-web · components/nav-bar/props -->
> **TUX `nav-bar` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/nav-bar)

## `TUXNavBar` props _(version: v1)_

_Props type: `TUXNavBarProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `React.ReactNode` |  | Main title of the nav bar. |
| `subtitle?` | `string` |  | Subtitle of the nav bar. |
| `customTitle?` | `React.ReactNode` |  | Custom title area of the nav bar. |
| `leading?` | `React.ReactNode` |  | Custom leading action area of the nav bar. |
| `trailing?` | `React.ReactNode` |  | Custom trailing action area of the nav bar. |
| `showSeparator?` | `boolean` | `false` | Whether to show separator below the nav bar. |
| `backgroundColor?` | `TColorWithToken` |  | Custom background color of the nav bar. |
| `zIndex?` | `number` | `1000` | Custom z-index of the nav bar. |
| `fixed?` | `boolean` | `false` | Whether the nav bar position is fixed. |
| `showTopSafeArea?` | `boolean` | `false` | Whether to include top safe area, usually used on mobile devices. |
| `topSafeAreaHeight?` | `string` |  | Custom height of the top safe area, usually used on mobile devices. |
| `showPlaceHolder?` | `boolean` | `false` | Whether to include a placeholder, only valid when fixed = true. |
| `backgroundOpacity?` | `number` |  | Opacity of the background color of the nav bar. |
| `titleOpacity?` | `number` |  | Opacity of the title of the nav bar. |
| `heightPreset?` | `52 \| 44` | `52` | Preset height of the nav bar (in pixels). |
| `titleAlign?` | `'center' \| 'start'` | `'center'` | The horizontal alignment of the title in the nav bar. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

> `heightPreset` — @remarks
>
> - `52` — standard nav bar height for primary screens
> - `44` — compact nav bar height for secondary or modal screens

## Additional exports



## `TUXNavBarTextAction` props

_Props type: `TUXNavBarTextActionProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `opacity?` | `number` |  | Opacity of the action button |
| `text?` | `string` |  | The text content inside the button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `themePreset?` | `'primary' \| 'secondary'` | `primary` | Preset themes of the button. |

### Detailed notes

> `themePreset` — @remarks
>
> - `primary` — UIShapePrimary (brand primary fill) background, UIShapeText1OnPrimary (high-contrast on primary) text; borderless variant: UITextPrimaryDisplay (brand-colored) text only
> - `secondary` — UIShapeNeutral4 (light neutral fill) background, UIText1 (primary text color) text; borderless variant: UIText1 text only

## `TUXNavBarIconAction` props

_Props type: `TUXNavBarIconActionProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `icon` | `React.ReactNode` |  | Icon displayed in the action button |
| `opacity?` | `number` |  | Opacity of the action button |
| `padding?` | `string` |  | Custom padding of the action button |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `width?` | `string` |  | Custom width of the button. |
| `height?` | `string` |  | Custom height of the button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

## `TUXNavBarCloseButton` props

_Props type: `TUXNavBarCloseButtonProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `color?` | `TColorWithToken` |  | Color of the nav bar close button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

### Detailed notes

> `color` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

## `TUXNavBarTitle` props

_Props type: `TUXNavBarTitleProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `React.ReactNode` |  | Main title of the nav bar. |
| `subtitle?` | `string` |  | Subtitle of the nav bar. |
| `leading?` | `React.ReactNode` |  | Leading area of the title. |
| `trailing?` | `React.ReactNode` |  | Trailing area of the title. |
| `trailingDefault?` | `'triangleUp' \| 'triangleDown'` |  | Default trailing icon of the title. |
| `onTitleClick?` | `() => void` |  | click handler of the title. |
