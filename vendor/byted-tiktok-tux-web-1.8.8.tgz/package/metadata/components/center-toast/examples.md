<!-- tux-web · components/center-toast/examples -->
> **TUX `center-toast` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md)

## Basic

<a id="basic"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXCenterToast } from '@byted-tiktok/tux-web';
import { IconTick } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text={visible ? 'Close Center Toast' : 'Open Center Toast'}
        onClick={(): void => {
          setVisible((prev) => !prev);
        }}
      />
      <TUXCenterToast icon={<IconTick />} text="Message" visible={visible} onVisibleChange={setVisible} />
    </>
  );
};

export default Example;
```
