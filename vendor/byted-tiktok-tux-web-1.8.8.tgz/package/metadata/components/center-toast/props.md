<!-- tux-web · components/center-toast/props -->
> **TUX `center-toast` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md)

## `TUXCenterToast` props

_Props type: `TUXCenterToastProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `zIndex?` | `number` | `2300` | Z-index of the center toast. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root to which the center toast are attached. |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the specific scope. |
| `text?` | `string` |  | Text to be displayed under the top icon. |
| `icon?` | `React.ReactNode` |  | Top icon of the center toast. |
| `visible?` | `boolean` | `false` | Controls whether the center toast is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the center toast is shown or hidden. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |

### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |

## `TUXCenterToastView` props

_Props type: `TUXCenterToastViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | Text to be displayed under the top icon. |
| `icon?` | `React.ReactNode` |  | Top icon of the center toast. |
| `showCloseButton?` | `boolean` |  | Whether to show the close button or not. |
| `visible?` | `boolean` | `false` | Controls whether the center toast is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the center toast is shown or hidden. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |
