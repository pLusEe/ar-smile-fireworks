<!-- tux-web · components/list-view/examples -->
> **TUX `list-view` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/list)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC } from 'react';
import { TUXListView, TUXListHeader, TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListView
      header={<TUXListHeader title="Title" />}
      footer={
        <div style={{ padding: '4px 16px' }}>
          <TUXText typographyPreset="P2-Regular" color={'UIText3'}>
            TikTok data also includes system files that help the app run smoothly and can’t be cleared
          </TUXText>
        </div>
      }
    >
      {Array(3)
        .fill(null)
        .map((index) => (
          <TUXListCell
            key={index}
            title="Label"
            description="Message"
            leadingIcon={<IconInfoCircle />}
            trailing={
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <TUXText typographyPreset="Headline-Regular">Action</TUXText>
                <IconChevronRightOffsetLTR />
              </div>
            }
          />
        ))}
    </TUXListView>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC } from 'react';
import { TUXListView, TUXListHeader, TUXListCell, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR, IconInfoCircle } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <TUXListView
      grouped={true}
      header={<TUXListHeader title="Title" />}
      footer={
        <div style={{ padding: '4px 16px' }}>
          <TUXText typographyPreset="P2-Regular" color={'UIText3'}>
            TikTok data also includes system files that help the app run smoothly and can’t be cleared
          </TUXText>
        </div>
      }
    >
      {Array(3)
        .fill(null)
        .map((index) => (
          <TUXListCell
            key={index}
            title="Label"
            description="Message"
            leadingIcon={<IconInfoCircle />}
            trailing={
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <TUXText typographyPreset="Headline-Regular">Action</TUXText>
                <IconChevronRightOffsetLTR />
              </div>
            }
          />
        ))}
    </TUXListView>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC } from 'react';
import { TUXListHeader, TUXListHeaderProps, TUXText } from '@byted-tiktok/tux-web';
import { IconChevronRightOffsetLTR } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const sizes: Array<TUXListHeaderProps['sizePreset']> = ['small', 'medium', 'large'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {sizes.map((size) => (
        <div key={size} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <TUXText typographyPreset="H3-Semibold">{size}</TUXText>
          <TUXListHeader
            title={'Title'}
            subtitle={size === 'small' ? undefined : 'Message'}
            sizePreset={size}
            trailingIcon={<IconChevronRightOffsetLTR />}
            trailing={
              <TUXText typographyPreset="P1-Semibold" color={'UIText3'}>
                more
              </TUXText>
            }
          />
        </div>
      ))}
    </div>
  );
};

export default Example;
```
