<!-- tux-web · components/list-view/props -->
> **TUX `list-view` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/list)

## `TUXListView` props _(version: v1)_

_Props type: `TUXListViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `header?` | `React.ReactNode` |  | Header of the list. |
| `footer?` | `React.ReactNode` |  | Footer of the list. |
| `showTopSeparator?` | `boolean` | `false` | Whether to show the top separator. |
| `grouped?` | `boolean` | `false` | Use standard grouped style. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

## `TUXListHeader` props _(version: v1)_

_Props type: `TUXListHeaderProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `string` |  | The title of the list header. |
| `subtitle?` | `string` |  | The description of the list header. |
| `trailingIcon?` | `React.ReactNode` |  | Icon displayed after the list header title. |
| `trailing?` | `React.ReactNode` |  | The Trailing area of the list header. |
| `sizePreset?` | `'small' \| 'medium' \| 'large'` | `small` | Preset sizes corresponding to different typography. |
| `onTitleClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Click event handler for the title. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `small` — P1-Semibold with muted text color
> - `medium` — Headline-Semibold with standard text color
> - `large` — H2-Bold with standard text color
