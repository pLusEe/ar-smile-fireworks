<!-- tux-web · components/button/examples -->
> **TUX `button` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/button)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXButton } from '@byted-tiktok/tux-web';
// import { IconStarRing } from '@byted-tiktok/tux-icons';

<TUXButton
  leadingIcon={<IconStarRing/>}
  text="Make your day"
/>
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXButton text="Button" sizePreset="large" />
      <TUXButton text="Button" sizePreset="medium" />
      <TUXButton text="Button" sizePreset="small" />
      <TUXButton text="Button" sizePreset="tiny" />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';
import { IconStarRing } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div style={{ display: 'flex', gap: '8px' }}>
        <TUXButton text="Button" themePreset="primary" />
        <TUXButton leadingIcon={<IconStarRing />} text="Button" themePreset="secondary" />
      </div>
      <div style={{ display: 'flex', gap: '40px' }}>
        <TUXButton text="Button" shapePreset="borderless" themePreset="primary" />
        <TUXButton text="Button" shapePreset="borderless" themePreset="secondary" />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div style={{ display: 'flex', gap: '8px' }}>
        <TUXButton text="Button" sizePreset="large" shapePreset="normal" />
        <TUXButton text="Button" sizePreset="medium" shapePreset="normal" />
        <TUXButton text="Button" sizePreset="small" shapePreset="normal" />
        <TUXButton text="Button" sizePreset="tiny" shapePreset="normal" />
      </div>
      <div style={{ display: 'flex', gap: '8px' }}>
        <TUXButton text="Button" sizePreset="large" shapePreset="capsule" />
        <TUXButton text="Button" sizePreset="medium" shapePreset="capsule" />
        <TUXButton text="Button" sizePreset="small" shapePreset="capsule" />
        <TUXButton text="Button" sizePreset="tiny" shapePreset="capsule" />
      </div>
      <div style={{ display: 'flex', gap: '40px' }}>
        <TUXButton text="Button" sizePreset="large" shapePreset="borderless" />
        <TUXButton text="Button" sizePreset="medium" shapePreset="borderless" />
        <TUXButton text="Button" sizePreset="small" shapePreset="borderless" />
        <TUXButton text="Button" sizePreset="tiny" shapePreset="borderless" />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return <TUXButton text="Button" block />;
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXButton themePreset="secondary" text="Button 1" shapePreset="normal" disabled />
      <TUXButton text="Button 2" themePreset="primary" shapePreset="capsule" disabled />
      <TUXButton text="Button 3" themePreset="primary" shapePreset="borderless" disabled />
    </div>
  );
};

export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <TUXButton
      themePreset="secondary"
      text="Disabled Button"
      shapePreset="normal"
      disabled
      onDisabledClick={() => {
        console.log('disabled click');
      }}
    />
  );
};

export default Example;
```

## Example example-8

<a id="example-8"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', gap: '8px' }}>
        <div style={{ width: '200px' }}>smoothRadius false (default)</div>
        <TUXButton text="Button" sizePreset="large" />
        <TUXButton text="Button" sizePreset="medium" />
        <TUXButton text="Button" sizePreset="small" />
        <TUXButton text="Button" sizePreset="tiny" />
      </div>

      <div style={{ display: 'flex', gap: '8px' }}>
        <div style={{ width: '200px' }}>smoothRadius true</div>
        <TUXButton text="Button" sizePreset="large" smoothRadius />
        <TUXButton text="Button" sizePreset="medium" smoothRadius />
        <TUXButton text="Button" sizePreset="small" smoothRadius />
        <TUXButton text="Button" sizePreset="tiny" smoothRadius />
      </div>
    </div>
  );
};

export default Example;
```

## Example example-9

<a id="example-9"></a>

```tsx
import { FC } from 'react';
import { TUXButton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXButton themePreset="secondary" text="Button 1" shapePreset="normal" loading />
      <TUXButton text="Button 2" themePreset="primary" shapePreset="capsule" loading />
      <TUXButton text="Button 3" themePreset="primary" shapePreset="borderless" loading />
    </div>
  );
};

export default Example;
```

## Example example-10

<a id="example-10"></a>

```tsx
import { FC } from 'react';
import { TUXButton, TUXText } from '@byted-tiktok/tux-web';
import { IconArrowRightLTR, IconStarRing } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', padding: '16px' }}>
      <TUXButton>
        <div style={{ paddingInline: 16 }}>
          <TUXText typographyPreset="Headline-Regular" as="div">
            Custom Title
          </TUXText>
          <TUXText typographyPreset="P2-Regular" as="div">
            Custom SubTitle
          </TUXText>
        </div>
      </TUXButton>
      <TUXButton
        width={'100%'}
        text={'Inspire creativity and bring joy'}
        textColor={'UIText3'}
        backgroundColor={'UIShapeInfo'}
        leadingIcon={<IconStarRing />}
        trailingIcon={<IconArrowRightLTR />}
      />
    </div>
  );
};

export default Example;
```
