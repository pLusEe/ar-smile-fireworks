<!-- tux-web · components/button/props -->
> **TUX `button` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/button)

## `TUXButton` props _(version: v1)_

_Props type: `TUXButtonProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | The text content inside the button. |
| `themePreset?` | `'primary' \| 'secondary'` | `primary` | Preset themes of the button. |
| `shapePreset?` | `'normal' \| 'capsule' \| 'borderless'` | `capsule` | Preset shapes of the button. |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `medium` | Preset sizes of the button, corresponding to different heights. |
| `leadingIcon?` | `React.ReactNode` |  | Icon displayed before the text. |
| `trailingIcon?` | `React.ReactNode` |  | Icon displayed after the text. |
| `loading?` | `boolean` |  | Whether the button is in a loading state. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `block?` | `boolean` |  | Whether the button should take up the full width of its container. `true` means the width will be `100%`, `false` mean the width will be `fit-content`, it's a shortcut for `width` prop. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `onDisabledClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Event handler for clicks when the button is in loading or disabled state. |
| `width?` | `string` |  | Custom width of the button. |
| `minWidth?` | `string` |  | Custom minimum width of the button. |
| `maxWidth?` | `string` |  | Custom maximum width of the button. |
| `height?` | `string` |  | Custom height of the button. |
| `backgroundColor?` | `TColorWithToken` |  | Custom background color of the button. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `textColor?` | `TColorWithToken` |  | Custom text color of the button. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `borderStyle?` | `string` |  | Custom border styles of the button. |
| `borderColor?` | `TColorWithToken` |  | Custom border color of the button. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `borderWidth?` | `string` |  | Custom border width of the button. |
| `borderRadius?` | `string` |  | Custom border radius of the button. |
| `paddingInline?` | `string` |  | Custom padding-inline of the button. |
| `hoveredColor?` | `TColorWithToken` |  | Text color to be displayed when the button is hovered in borderless shape. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `textResize?` | `boolean` |  | Whether to enable the text resize mode. |
| `smoothRadius?` | `boolean` |  | Whether to enable smooth SVG background rendering. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

_Also extends: `TPropsWithoutCustomStyle<React.ComponentPropsWithoutRef<'button'>>`_

#### Detailed notes

> `themePreset` — @remarks
>
> - `primary` — UIShapePrimary (brand primary fill) background, UIShapeText1OnPrimary (high-contrast on primary) text; borderless variant: UITextPrimaryDisplay (brand-colored) text only
> - `secondary` — UIShapeNeutral4 (light neutral fill) background, UIText1 (primary text color) text; borderless variant: UIText1 text only

> `shapePreset` — @remarks
>
> - `normal` — standard rounded corners sized to the sizePreset
> - `capsule` — fully rounded pill-shape
> - `borderless` — no background or border, text-only

> `sizePreset` — @remarks
>
> - `tiny` — 28px height
> - `small` — 32px height
> - `medium` — 44px height
> - `large` — 52px height

> `backgroundColor`, `textColor`, `borderColor`, `hoveredColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
