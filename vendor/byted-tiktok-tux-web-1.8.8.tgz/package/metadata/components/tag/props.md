<!-- tux-web · components/tag/props -->
> **TUX `tag` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/tag)

## `TUXTag` props _(version: v1)_

_Props type: `TUXTagProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | The text content inside the tag. |
| `themePreset?` | `TThemePreset` | `primary` | Preset themes of the tag. |
| `textSizePreset?` | `TTagTextSizePreset` | `P2` | Preset text sizes of the tag, controlling both text size and icon size. |
| `disabled?` | `boolean` |  | Whether the tag is in a disabled(not interactive) state. |
| `leadingIcon?` | `React.ReactNode` |  | Icon displayed before the text. |
| `trailingIcon?` | `React.ReactNode` |  | Icon displayed after the text. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Click event handler for the tag, set this to make the tag to be interactive. |
| `paddingBlock?` | `string` |  | Custom padding-block of the tag. |
| `paddingInline?` | `string` |  | Custom padding-inline of the tag. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `themePreset` — @remarks
>
> - `primary` — UIShapePrimary (brand primary fill) background, UIShapeText1OnPrimary (high-contrast on primary) text
> - `neutral` — UIShapeNeutral (dark neutral fill) background, UIShapeText1OnNeutral (high-contrast on neutral) text
> - `subtle` — UIShapeNeutral4 (light neutral fill) background, UIText1 (primary text color) text
> - `overlayWhite` — UIImageOverlayWhite (white overlay) background, UIImageOverlayBlackA80 (dark overlay) text (for use on images)
> - `overlayGray` — UIImageOverlayDarkGrayA60 (dark gray overlay) background, UIImageOverlayWhite (white overlay) text (for use on images)

> `textSizePreset` — @remarks
>
> - `H3` — 17px semibold text, 17px icon
> - `Headline` — 16px semibold text, 16px icon
> - `H4` — 15px semibold text, 15px icon
> - `P1` — 14px semibold text, 14px icon
> - `P2` — 13px semibold text, 13px icon
> - `P3` — 12px semibold text, 12px icon
> - `SmallText1` — 11px semibold text, 11px icon
> - `SmallText2` — 10px semibold text, 10px icon
