<!-- tux-web · components/tag/examples -->
> **TUX `tag` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/tag)

## Example example-1

<a id="example-1"></a>

```tsx
// import { TUXTag } from '@byted-tiktok/tux-web';
// import { IconPersonFill, IconXMark } from '@byted-tiktok/tux-icons';

<TUXTag
  text="Make your day"
  textSizePreset="Headline"
  leadingIcon={<IconPersonFill />}
  trailingIcon={<IconXMark />}
/>
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC } from 'react';
import { TUXTag } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTag text="Label" textSizePreset="H3" />
      <TUXTag text="Label" textSizePreset="Headline" />
      <TUXTag text="Label" textSizePreset="H4" />
      <TUXTag text="Label" textSizePreset="P1" />
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC } from 'react';
import { TUXTag } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTag text="Label" textSizePreset="H3" themePreset="primary" />
      <TUXTag text="Label" textSizePreset="H3" themePreset="neutral" />
      <TUXTag text="Label" textSizePreset="H3" themePreset="subtle" />
      <TUXTag text="Label" textSizePreset="H3" themePreset="overlayWhite" />
      <TUXTag text="Label" textSizePreset="H3" themePreset="overlayGray" />
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC } from 'react';
import { TUXTag } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '16px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXTag text="Non-interactive" textSizePreset="Headline" />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <TUXTag
          text="Interactive"
          textSizePreset="Headline"
          onClick={(e) => {
            console.log('This is an interactive tag');
          }}
        />
      </div>
    </div>
  );
};
export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC } from 'react';
import { TUXTag } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTag
        text="Label"
        textSizePreset="Headline"
        onClick={(e) => {
          console.log('This is a disabled tag');
        }}
        disabled
      />
    </div>
  );
};
export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC } from 'react';
import { TUXTag } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      <TUXTag text="Hello World" themePreset="subtle" textSizePreset="H4" paddingBlock="5px 10px" />
      <TUXTag text="Hello World" themePreset="overlayGray" textSizePreset="Headline" paddingInline="12px 4px" />
    </div>
  );
};
export default Example;
```
