<!-- tux-web · components/dialog-view/examples -->
> **TUX `dialog-view` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/dialog-view)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          actionType="button"
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';
import { IconBookmark } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={<IconBookmark />}
          imageType="icon"
          actionType="button"
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={
            <img
              src="https://sf16-scmcdn-va.ibytedtos.com/goofy/tiktok/web/node/_next/static/images/logo-whole-c555aa707602e714ec956ac96e9db366.svg"
              alt="TikTok logo"
              width="80%"
            />
          }
          imageType="banner"
          actionType="button"
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';
import { IllustrationMAddedToFavorites } from '@tiktok-arch/tux-illustration/web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={<IllustrationMAddedToFavorites />}
          imageType="illustration"
          actionType="button"
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXInput, TUXModal } from '@byted-tiktok/tux-web';
import { IconBookmark } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={<IconBookmark />}
          imageType="icon"
          actionType="button"
          accessory={<TUXInput placeholder="Placeholder" />}
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';
import { IconBookmark } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={<IconBookmark />}
          imageType="icon"
          actionType="text"
          actionDirection="vertical"
          footerActions={[
            { text: 'Primary', themePreset: 'primary', onClick: handleClose },
            { text: 'Secondary', themePreset: 'secondary', onClick: handleClose },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';
import { IconBookmark } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={<IconBookmark />}
          imageType="icon"
          showCloseButton
          onClose={handleClose}
          actionType="button"
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```

## Example example-8

<a id="example-8"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXDialogView, TUXModal } from '@byted-tiktok/tux-web';
import { IconBookmark } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  const handleClose = (e: React.MouseEvent<HTMLButtonElement>): void => {
    setVisible(false);
  };

  return (
    <div>
      <TUXButton
        text="Open Dialog"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal
        visible={visible}
        onVisibleChange={setVisible}
        closeOnOutsideClick={false}
        width="fit-content"
        minHeight="fit-content"
      >
        <TUXDialogView
          title="Added to Favorites"
          message="Sound added. Go to Favorites later to find or use it."
          image={<IconBookmark />}
          imageType="icon"
          actionType="text"
          footerActions={[
            {
              text: 'Primary',
              themePreset: 'primary',
              onClick: handleClose,
            },
            {
              text: 'Secondary',
              themePreset: 'secondary',
              onClick: handleClose,
            },
          ]}
        />
      </TUXModal>
    </div>
  );
};
export default Example;
```
