<!-- tux-web · components/dialog-view/props -->
> **TUX `dialog-view` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/dialog-view)

## `TUXDialogView` props _(version: v1)_

_Props type: `TUXDialogViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title?` | `string` |  | Title of the dialog view. |
| `message?` | `string` |  | Message of the dialog view. |
| `image?` | `React.ReactNode` |  | Top image of the dialog view. |
| `imageType?` | `'banner' \| 'icon' \| 'illustration'` |  | Image type of the dialog view. |
| `accessory?` | `React.ReactNode` |  | The accessory part of the dialog view. |
| `showCloseButton?` | `boolean` |  | Whether to have close button or not. |
| `closeButtonColor?` | `TColorWithToken` |  | Custom color of the close button. |
| `onClose?` | `(event: React.MouseEvent<HTMLButtonElement>) => void` |  | The handler of dismiss event, used in close button. |
| `actionType` | `'button' \| 'text'` |  | Action type of the dialog view. |
| `footerActions` | `\| [TUXDialogViewPrimaryButtonActionProps]         \| [TUXDialogViewPrimaryButtonActionProps, TUXDialogViewSecondaryButtonActionProps] \| TUXDialogViewTextActionProps[]` |  | Footer actions of the dialog view. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `actionDirection?` | `'horizontal' \| 'vertical'` | `horizontal` | Action direction of the dialog view. (Applied when actionType = 'text') |

#### Detailed notes

> `closeButtonColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TUXDialogViewPrimaryButtonActionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `themePreset?` | `'primary' \| 'secondary'` |  | Preset themes of the primary button action. |
| `shapePreset?` | `'normal' \| 'capsule'` |  | Preset shapes of the primary button action. |
| `text?` | `string` |  | The text content inside the button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

> `themePreset` — @remarks
>
> - `primary` — brand background color
> - `secondary` — neutral background color

> `shapePreset` — @remarks
>
> - `normal` — standard rounded corners
> - `capsule` — fully rounded pill-shape

#### `TUXDialogViewSecondaryButtonActionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `themePreset?` | `'secondary' \| 'destructive'` |  | Preset themes of the secondary button action. |
| `text?` | `string` |  | The text content inside the button. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking the button. |
| `onClick?` | `(e: React.MouseEvent<HTMLButtonElement>) => void` |  | Click event handler for the button. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

> `themePreset` — @remarks
>
> - `secondary` — regular muted text
> - `destructive` — semibold danger-colored text

#### `TUXDialogViewTextActionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text?` | `string` |  | The text content inside the text action. |
| `themePreset?` | `'primary' \| 'secondary' \| 'destructive'` | `primary` | Preset themes of the text action. |
| `disabled?` | `boolean` | `false` | Prevents the user from clicking text action. |
| `onClick?` | `React.MouseEventHandler<HTMLButtonElement>` |  | Click event handler for the text action. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

> `themePreset` — @remarks
>
> - `primary` — UIText1 (primary text color) text, 16px semibold
> - `secondary` — UIText2 (secondary/muted text color) text, 16px regular
> - `destructive` — UITextDangerDisplay (red/danger text) text, 16px semibold
