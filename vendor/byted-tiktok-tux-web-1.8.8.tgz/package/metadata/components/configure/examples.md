<!-- tux-web · components/configure/examples -->
> **TUX `configure` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/configure)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { useTUXContext, TUXConfigure } from '@byted-tiktok/tux-web';

const Content: FC = () => {
  const { theme } = useTUXContext();

  return (
    <div style={{ backgroundColor: 'var(--tux-v2-color-ui-page-flat-3)', color: 'var(--tux-v2-color-ui-text-1)' }}>
      <div data-testid="theme">theme: {theme}</div>
    </div>
  );
};

const Example: FC = () => {
  return (
    <>
      <Content />
      <TUXConfigure theme="dark" style={{ width: '100%', height: 100, backgroundColor: '#dedede' }}>
        <Content />
      </TUXConfigure>
    </>
  );
};

export default Example;
```
