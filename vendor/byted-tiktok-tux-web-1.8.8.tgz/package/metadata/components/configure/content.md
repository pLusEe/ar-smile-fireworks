<!-- tux-web · components/configure/content -->
> **TUX `configure` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/configure)

_See example: [example example-1](./examples.md#example-1)_
