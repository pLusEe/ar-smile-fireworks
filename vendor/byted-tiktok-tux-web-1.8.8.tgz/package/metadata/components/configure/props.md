<!-- tux-web · components/configure/props -->
> **TUX `configure` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/configure)

## `TUXConfigure` props _(version: v1)_

_Props type: `TUXConfigureProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme?` | `TTUXContextValue['theme']` |  | The theme for the specific scope. |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the specific scope. |
| `platform?` | `TTUXContextValue['platform']` |  | The platform information. |
| `breakpoint?` | `TTUXContextValue['breakpoint']` |  | The viewport breakpoint for the specific scope. |
| `highContrastColors?` | `Partial<TTUXColorMap>` |  | High-contrast color overrides scoped to this subtree. Merges on top of the colors inherited from the enclosing `TUXApp`/`TUXConfigure`. Requires importing `@byted-tiktok/tux-web/colors-v2-high-contrast.css` to apply the matching CSS variables. |
| `className?` | `string` |  | CSS class applied to the component. This can be used to provide additional styles (eg: margin). |
| `style?` | `React.CSSProperties` |  | Inline CSS styles applied to the component. This can be used to provide additional styles (eg: margin). |

#### Detailed notes

> `highContrastColors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
