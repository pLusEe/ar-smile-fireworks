<!-- tux-web · components/skeleton/props -->
> **TUX `skeleton` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/skeleton)

## `TUXSkeleton` props _(version: v1)_

_Props type: `TUXSkeletonProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `width?` | `string` | `64px` | Width of the skeleton. |
| `height?` | `string` | `64px` | Height of the skeleton. |
| `borderRadius?` | `string` | `2px` | Border radius of the skeleton. |
