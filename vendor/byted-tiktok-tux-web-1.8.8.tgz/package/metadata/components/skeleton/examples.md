<!-- tux-web · components/skeleton/examples -->
> **TUX `skeleton` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/skeleton)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC } from 'react';
import { TUXSkeleton } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', padding: '16px' }}>
      <TUXSkeleton width="128px" height="64px" />
      <TUXSkeleton width="128px" height="128px" />
      <TUXSkeleton width="64px" height="64px" borderRadius="999px" />
      <TUXSkeleton width="128px" height="64px" borderRadius="999px" />
    </div>
  );
};

export default Example;
```
