<!-- tux-web · components/select/content -->
> **TUX `select` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/select)

_See example: [example example-1](./examples.md#example-1)_

_See example: [example example-2](./examples.md#example-2)_

_See example: [example example-3](./examples.md#example-3)_

_See example: [example example-4](./examples.md#example-4)_

_See example: [example example-5](./examples.md#example-5)_

_See example: [example example-6](./examples.md#example-6)_
