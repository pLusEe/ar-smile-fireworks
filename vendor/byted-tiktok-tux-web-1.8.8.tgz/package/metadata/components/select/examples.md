<!-- tux-web · components/select/examples -->
> **TUX `select` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/select)

## Example example-1

<a id="example-1"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXFormItemFooter, TUXFormItemHeader, TUXSelect, TUXSelectOptionProps } from '@byted-tiktok/tux-web';
import { IconPersonFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [value, setValue] = useState<string>();

  const options: TUXSelectOptionProps[] = [
    {
      type: 'group',
      groupTitle: 'Account',
      groupOptions: [
        {
          type: 'item',
          text: 'Profile',
          value: 'profile',
          leadingIcon: <IconPersonFill />,
          onClick: () => setValue('profile'),
        },
        {
          type: 'item',
          text: 'Settings',
          value: 'settings',
          onClick: () => setValue('settings'),
        },
      ],
    },
    {
      type: 'item',
      text: 'option 1',
      value: 'option-1',
      onClick: () => setValue('option-1'),
    },
    {
      type: 'item',
      text: 'option 2',
      value: 'option-2',
      onClick: () => setValue('option-2'),
    },
  ];

  return (
    <>
      <TUXFormItemHeader title="Select" />
      <TUXSelect value={value} options={options} placeholder={'Click to Select'} />
      <TUXFormItemFooter message="Select Footer" />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXSelectBox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px', flexDirection: 'column' }}>
      <TUXSelectBox sizePreset={'large'} placeholder={'Click to Select'} onClick={() => {}} />
      <TUXSelectBox sizePreset={'medium'} placeholder={'Click to Select'} onClick={() => {}} />
      <TUXSelectBox sizePreset={'small'} placeholder={'Click to Select'} onClick={() => {}} />
      <TUXSelectBox sizePreset={'tiny'} placeholder={'Click to Select'} onClick={() => {}} />
    </div>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXSelectBox } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  return (
    <div style={{ display: 'flex', gap: '8px', flexDirection: 'column' }}>
      <TUXSelectBox placeholder={'Click to Select'} invalid onClick={() => {}} />
      <TUXSelectBox placeholder={'Click to Select'} disabled onClick={() => {}} />
      <TUXSelectBox placeholder={'Click to Select'} readOnly onClick={() => {}} />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXSelect, TUXSelectOptionProps } from '@byted-tiktok/tux-web';
import { IconPersonFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [value, setValue] = useState<string>();

  const options: TUXSelectOptionProps[] = [
    {
      type: 'group',
      groupTitle: 'Account',
      groupOptions: [
        {
          type: 'item',
          text: 'Profile',
          value: 'profile',
          leadingIcon: <IconPersonFill />,
          onClick: () => setValue('profile'),
        },
        {
          type: 'item',
          text: 'Settings',
          value: 'settings',
          onClick: () => setValue('settings'),
        },
      ],
    },
    {
      type: 'item',
      text: 'option 1',
      value: 'option-1',
      onClick: () => setValue('option-1'),
    },
    {
      type: 'item',
      text: 'option 2',
      value: 'option-2',
      onClick: () => setValue('option-2'),
    },
  ];

  return <TUXSelect value={value} options={options} placeholder={'Click to Select'} fitContent />;
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXSelect, TUXInput, TUXSelectOptionProps, TUXSeparator } from '@byted-tiktok/tux-web';
import { IconPersonFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [value, setValue] = useState<string>();

  const options: TUXSelectOptionProps[] = [
    {
      type: 'group',
      groupTitle: 'Account',
      groupOptions: [
        {
          type: 'item',
          text: 'Profile',
          value: 'profile',
          leadingIcon: <IconPersonFill />,
          onClick: () => setValue('profile'),
        },
        {
          type: 'item',
          text: 'Settings',
          value: 'settings',
          onClick: () => setValue('settings'),
        },
      ],
    },
    {
      type: 'item',
      text: 'option 1',
      value: 'option-1',
      onClick: () => setValue('option-1'),
    },
    {
      type: 'item',
      text: 'option 2',
      value: 'option-2',
      onClick: () => setValue('option-2'),
    },
  ];

  return (
    <TUXInput
      sizePreset={'large'}
      placeholder={'Feel Free to Type'}
      leading={
        <div style={{ display: 'flex', alignItems: 'center', marginInlineEnd: 8 }}>
          <TUXSelect
            inline
            value={value}
            options={options}
            sizePreset={'large'}
            placeholder={'Click to Select'}
            onClick={() => {
              console.log('select box clicked');
            }}
          />
          <div style={{ marginInlineStart: 12 }}>
            <TUXSeparator direction="vertical" height={'16px'} />
          </div>
        </div>
      }
    />
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import React, { FC, useState } from 'react';
import { TUXSelect, TUXSelectOptionProps } from '@byted-tiktok/tux-web';
import { IconPersonFill } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [value, setValue] = useState<string>();

  const options: TUXSelectOptionProps[] = [
    {
      type: 'group',
      groupTitle: 'Account',
      groupOptions: [
        {
          type: 'item',
          text: 'Profile',
          value: 'profile',
          leadingIcon: <IconPersonFill />,
          onClick: () => setValue('profile'),
        },
        {
          type: 'item',
          text: 'Settings',
          value: 'settings',
          onClick: () => setValue('settings'),
        },
      ],
    },
    {
      type: 'item',
      text: 'option 1',
      value: 'option-1',
      onClick: () => setValue('option-1'),
    },
    {
      type: 'item',
      text: 'option 2',
      value: 'option-2',
      onClick: () => setValue('option-2'),
    },
  ];

  return (
    <TUXSelect
      value={value}
      options={options}
      formatDisplayText={(selectedOption) => {
        return selectedOption?.text ?? 'Default Select Text';
      }}
    />
  );
};

export default Example;
```
