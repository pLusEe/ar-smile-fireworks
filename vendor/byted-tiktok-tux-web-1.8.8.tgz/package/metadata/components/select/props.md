<!-- tux-web · components/select/props -->
> **TUX `select` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/select)

## `TUXSelect` props _(version: v1)_

_Props type: `TUXSelectProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `fitContent?` | `boolean` | `false` | Whether the width of select follows the content. |
| `placeholder?` | `string` |  | Placeholder text to prompt user select. |
| `readOnly?` | `boolean` | `false` | Whether the select is read-only. |
| `inline?` | `boolean` | `false` | Inline mode, embedded within other components. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Callback event triggered when the select box is clicked. |
| `disabled?` | `boolean` |  | Whether the input is in a disabled(not interactive) state. |
| `value?` | `string` |  | Value of the input. Uses this prop with 'onChange' to make it in a controlled mode. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `invalid?` | `boolean` |  | Whether the input is in an error state. |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `large` | Preset sizes of the input, corresponding to different heights. |
| `leadingIcon?` | `React.ReactNode` |  | Leading icon of the input. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback when the popover is open or closed |
| `autoFlip?` | `boolean` | `false` | Whether to flip the popover when it is out of the viewport |
| `configForAll?` | `TConfigForAll` |  | config for all items in the menu |
| `options` | `TUXSelectOptionProps[]` |  |  |
| `formatDisplayText?` | `(selectedOption?: TUXSelectValueOptionProps) => string` |  | Custom display text in select |
| `dropdownMaxHeight?` | `string` |  | Max height of dropdown options |
| `placement?` | `TPopoverPlacement` | `'BlockEnd-Start'` | where to place the select options |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 28px height
> - `small` — 32px height
> - `medium` — 40px height
> - `large` — 48px height

> `placement` — TPopoverPlacement
>
> Logical placement of a floating element relative to its trigger.
> 
> Names use logical (writing-direction-aware) axes so the same value renders
> correctly under both LTR and RTL:
> - `Block*` — vertical axis. `BlockStart` is above the trigger;
>   `BlockEnd` is below.
> - `Inline*` — horizontal axis. `InlineStart` is the leading side
>   (left in LTR, right in RTL); `InlineEnd` is the trailing side.
> - Plain `BlockStart` / `BlockEnd` / `InlineStart` / `InlineEnd` center the
>   floating element along the cross axis of the trigger.
> - `-Start` / `-End` suffixes pin the floating element to the start or end of
>   the cross axis instead (e.g. `BlockEnd-Start` opens below the trigger,
>   aligned to its leading edge).

#### Referenced types

#### `TConfigForAll`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `showSeparator?` | `TUXMenuItemProps['showSeparator']` |  | whether show separator |
| `textDisplay?` | `TUXMenuItemProps['textDisplay']` |  | text overflow strategy |
| `themePreset?` | `TUXMenuItemProps['themePreset']` |  | theme preset |
| `disabled?` | `TUXMenuItemProps['disabled']` |  | whether the menu item is disabled |
| `preventCloseOnClick?` | `boolean` |  | prevent close menu when click |

#### `TUXSelectOptionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text` | `string` |  | text of the menu item |
| `disabled?` | `boolean` |  | whether the menu item is disabled |
| `type` | `'item' \| 'group'` |  | use to identify the menu item |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | click event of the menu item |
| `themePreset?` | `'normal' \| 'destructive'` | `'normal'` | theme preset of the menu item |
| `leadingIcon?` | `React.ReactNode` |  | leading icon of the menu item |
| `textDisplay?` | `'truncate' \| 'lineBreak'` | `'truncate'` | text overflow strategy |
| `leading?` | `React.ReactNode` |  | leading custom element of the menu item |
| `showSeparator?` | `boolean` |  | whether show separator under this item |
| `preventCloseOnClick?` | `boolean` | `false` | prevent close menu when click |
| `value` | `string` |  |  |
| `configForAll?` | `TConfigForAll` |  | config for all items in the menu group |
| `groupTitle` | `string` |  | title of the menu group |
| `groupOptions` | `TUXSelectValueOptionProps[]` |  |  |

> `themePreset` — @remarks
>
> - `normal` — neutral foreground color (`UIText1`), for standard menu items
> - `destructive` — danger foreground color (`UITextDangerDisplay`), for destructive or irreversible menu items

#### `TUXSelectValueOptionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `text` | `string` |  | text of the menu item |
| `disabled?` | `boolean` |  | whether the menu item is disabled |
| `type` | `'item'` |  | use to identify the menu item |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | click event of the menu item |
| `themePreset?` | `'normal' \| 'destructive'` | `'normal'` | theme preset of the menu item |
| `leadingIcon?` | `React.ReactNode` |  | leading icon of the menu item |
| `textDisplay?` | `'truncate' \| 'lineBreak'` | `'truncate'` | text overflow strategy |
| `leading?` | `React.ReactNode` |  | leading custom element of the menu item |
| `showSeparator?` | `boolean` |  | whether show separator under this item |
| `preventCloseOnClick?` | `boolean` | `false` | prevent close menu when click |
| `value` | `string` |  |  |

> `themePreset` — @remarks
>
> - `normal` — neutral foreground color (`UIText1`), for standard menu items
> - `destructive` — danger foreground color (`UITextDangerDisplay`), for destructive or irreversible menu items

#### Other referenced types

#### `TUXMenuItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `type` | `'item'` |  | use to identify the menu item |
| `text` | `string` |  | text of the menu item |
| `textDisplay?` | `'truncate' \| 'lineBreak'` | `'truncate'` | text overflow strategy |
| `leadingIcon?` | `React.ReactNode` |  | leading icon of the menu item |
| `leading?` | `React.ReactNode` |  | leading custom element of the menu item |
| `trailingIcon?` | `React.ReactNode` |  | trailing icon of the menu item |
| `trailing?` | `React.ReactNode` |  | trailing custom element of the menu item |
| `disabled?` | `boolean` |  | whether the menu item is disabled |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | click event of the menu item |
| `themePreset?` | `'normal' \| 'destructive'` | `'normal'` | theme preset of the menu item |
| `showSeparator?` | `boolean` |  | whether show separator under this item |
| `preventCloseOnClick?` | `boolean` | `false` | prevent close menu when click |

> `themePreset` — @remarks
>
> - `normal` — neutral foreground color (`UIText1`), for standard menu items
> - `destructive` — danger foreground color (`UITextDangerDisplay`), for destructive or irreversible menu items

## `TUXSelectBox` props _(version: v1)_

_Props type: `TUXSelectBoxProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `fitContent?` | `boolean` | `false` | Whether the width of select follows the content. |
| `placeholder?` | `string` |  | Placeholder text to prompt user select. |
| `readOnly?` | `boolean` | `false` | Whether the select is read-only. |
| `inline?` | `boolean` | `false` | Inline mode, embedded within other components. |
| `onClick?` | `(e: React.MouseEvent<HTMLDivElement>) => void` |  | Callback event triggered when the select box is clicked. |
| `disabled?` | `boolean` |  | Whether the input is in a disabled(not interactive) state. |
| `value?` | `string` |  | Value of the input. Uses this prop with 'onChange' to make it in a controlled mode. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `invalid?` | `boolean` |  | Whether the input is in an error state. |
| `sizePreset?` | `'tiny' \| 'small' \| 'medium' \| 'large'` | `large` | Preset sizes of the input, corresponding to different heights. |
| `leadingIcon?` | `React.ReactNode` |  | Leading icon of the input. |

#### Detailed notes

> `sizePreset` — @remarks
>
> - `tiny` — 28px height
> - `small` — 32px height
> - `medium` — 40px height
> - `large` — 48px height
