<!-- tux-web · components/floating-notice/examples -->
> **TUX `floating-notice` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/floating-notice)

## Example example-1

<a id="example-1"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton text={visible ? 'Hide Notice' : 'Show Notice'} onClick={(): void => setVisible((prev) => !prev)} />
      <TUXFloatingNotice
        visible={visible}
        message="Content goes here. More text will be wrapped."
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice } from '@byted-tiktok/tux-web';
import { IconFolder } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton text={visible ? 'Hide Notice' : 'Show Notice'} onClick={(): void => setVisible((prev) => !prev)} />
      <TUXFloatingNotice
        visible={visible}
        leading={<IconFolder />}
        title="Title"
        message="Content goes here."
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice } from '@byted-tiktok/tux-web';
import { IconTickCircleFill, IconExclamationMarkCircleFill, IconInfoCircleFill } from '@byted-tiktok/tux-icons';

type Preset = 'success' | 'error' | 'info';

const LEADING_ICONS: Record<Preset, React.ReactNode> = {
  success: <IconTickCircleFill />,
  error: <IconExclamationMarkCircleFill />,
  info: <IconInfoCircleFill />,
};

const Example: FC = () => {
  const [preset, setPreset] = useState<Preset | null>(null);

  return (
    <div style={{ display: 'flex', gap: '8px' }}>
      {(['success', 'error', 'info'] as Preset[]).map((p) => (
        <TUXButton key={p} themePreset="secondary" text={p} onClick={(): void => setPreset(p)} />
      ))}
      <TUXFloatingNotice
        visible={preset !== null}
        leading={preset ? LEADING_ICONS[preset] : undefined}
        title="Title"
        message="Content goes here."
        onVisibleChange={(v): void => {
          if (!v) {
            setPreset(null);
          }
        }}
      />
    </div>
  );
};

export default Example;
```

## Example example-4

<a id="example-4"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton text={visible ? 'Hide Notice' : 'Show Notice'} onClick={(): void => setVisible((prev) => !prev)} />
      <TUXFloatingNotice
        visible={visible}
        title="Add phone number"
        message="Let contacts find you on TikTok"
        action={
          <TUXButton
            sizePreset="tiny"
            minWidth="62px"
            maxWidth="124px"
            text="Add"
            onClick={(): void => setVisible(false)}
          />
        }
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```

## Example example-5

<a id="example-5"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice } from '@byted-tiktok/tux-web';
import { IconHeart } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton text={visible ? 'Hide Notice' : 'Show Notice'} onClick={(): void => setVisible((prev) => !prev)} />
      <TUXFloatingNotice
        visible={visible}
        leading={<IconHeart />}
        title="Title"
        message="The whole notice is a hotspot — tap the body to trigger onClick."
        onClick={(): void => setVisible(false)}
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```

## Example example-6

<a id="example-6"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice, TUXLink } from '@byted-tiktok/tux-web';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton text={visible ? 'Hide Notice' : 'Show Notice'} onClick={(): void => setVisible((prev) => !prev)} />
      <TUXFloatingNotice
        visible={visible}
        message={
          <>
            Content goes here. More text will be wrapped.{' '}
            <TUXLink
              text="Learn more"
              colorPreset="highlight"
              typographyPreset="P2-Semibold"
              onClick={(): void => setVisible(false)}
            />
          </>
        }
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```

## Example example-7

<a id="example-7"></a>

```tsx
import { FC, useState } from 'react';
import { TUXButton, TUXFloatingNotice } from '@byted-tiktok/tux-web';
import { IconHeart } from '@byted-tiktok/tux-icons';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton text={visible ? 'Hide Notice' : 'Show Notice'} onClick={(): void => setVisible((prev) => !prev)} />
      <TUXFloatingNotice
        visible={visible}
        leading={<IconHeart />}
        title="Ajouter un numéro de téléphone"
        message="When the combined title and message exceed three lines, the leading icon is hidden first and the title shrinks to keep the layout compact on small screens."
        onVisibleChange={setVisible}
      />
    </>
  );
};

export default Example;
```
