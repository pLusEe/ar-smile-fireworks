<!-- tux-web · components/floating-notice/props -->
> **TUX `floating-notice` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/floating-notice)

## `TUXFloatingNotice` props _(version: v1)_

_Props type: `TUXFloatingNoticeProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `visible?` | `boolean` | `false` | Controls whether the floating notice is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the floating notice is shown or hidden. |
| `title?` | `string` |  | Title text. Optional; rendered above the message. |
| `message?` | `ReactNode` |  | Message content. Accepts a string, or rich nodes (e.g. an inline `TUXLink`) for "Learn more" style inline actions. |
| `leading?` | `ReactNode` |  | Custom leading slot (e.g. a status icon). |
| `action?` | `ReactNode` |  | Optional CTA action slot, placed before the close button. Pass a `TUXButton` (or any node) — keeps the component contract minimal and lets callers control text, theme and handler. Clicks on the action do not trigger the whole-notice `onClick` handler. |
| `adaptiveLayout?` | `boolean` | `true` | Whether adaptive layout (icon auto-hide + title shrink on overflow) is on. |
| `maxContentLines?` | `number` | `3` | Max combined lines (title + message) before adaptive layout kicks in — hides the leading icon, then shrinks the title. Only effective when `adaptiveLayout` is on. |
| `duration?` | `number` |  | Auto-dismiss delay in milliseconds. Omit to keep the notice until the user acts. |
| `onClick?` | `(e: MouseEvent<HTMLElement>) => void` |  | Click handler for the whole notice. Clicks on the close button, CTA action slot, or inline links/buttons in the message are ignored. |
| `zIndex?` | `number` | `2300` | Z-index of the toast. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root to which the toast are attached. |
| `bottomOffset?` | `string` |  | `padding-block-end` of the portal — gap between the notice and the viewport bottom, above the device safe area. |

## Additional exports



## `TUXFloatingNoticeView` props

_Props type: `TUXFloatingNoticeViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `visible?` | `boolean` | `false` | Controls whether the floating notice is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Callback triggered when the floating notice is shown or hidden. |
| `title?` | `string` |  | Title text. Optional; rendered above the message. |
| `message?` | `ReactNode` |  | Message content. Accepts a string, or rich nodes (e.g. an inline `TUXLink`) for "Learn more" style inline actions. |
| `leading?` | `ReactNode` |  | Custom leading slot (e.g. a status icon). |
| `action?` | `ReactNode` |  | Optional CTA action slot, placed before the close button. Pass a `TUXButton` (or any node) — keeps the component contract minimal and lets callers control text, theme and handler. Clicks on the action do not trigger the whole-notice `onClick` handler. |
| `adaptiveLayout?` | `boolean` | `true` | Whether adaptive layout (icon auto-hide + title shrink on overflow) is on. |
| `maxContentLines?` | `number` | `3` | Max combined lines (title + message) before adaptive layout kicks in — hides the leading icon, then shrinks the title. Only effective when `adaptiveLayout` is on. |
| `duration?` | `number` |  | Auto-dismiss delay in milliseconds. Omit to keep the notice until the user acts. |
| `onClick?` | `(e: MouseEvent<HTMLElement>) => void` |  | Click handler for the whole notice. Clicks on the close button, CTA action slot, or inline links/buttons in the message are ignored. |
