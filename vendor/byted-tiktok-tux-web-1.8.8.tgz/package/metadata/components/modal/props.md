<!-- tux-web · components/modal/props -->
> **TUX `modal` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/modal)

## `TUXModal` props _(version: v1)_

_Props type: `TUXModalProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `landscape?` | `boolean` | `false` | Whether modal display in landscape mode. |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether clicking the overlay closes the modal. |
| `height?` | `string` |  | Custom height of the modal. |
| `minHeight?` | `string` |  | Custom minimum height of the modal. |
| `maxHeight?` | `string` |  | Custom maximum height of the modal. |
| `width?` | `string` |  | Width of the modal |
| `zIndex?` | `number` | `2100` | Z-index of the modal. |
| `overlayBackgroundColor?` | `TColorWithToken` |  | Background color of the overlay. |
| `modalBackgroundColor?` | `TColorWithToken` |  | Background color of the modal container. |
| `autoFocus?` | `boolean` | `true` | Whether to auto focus modal when open. |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `overlayBackgroundColor`, `modalBackgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.
