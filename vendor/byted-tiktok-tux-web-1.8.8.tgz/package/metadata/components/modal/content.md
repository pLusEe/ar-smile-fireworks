<!-- tux-web · components/modal/content -->
> **TUX `modal` component — content** (tux-web)
> See also: [props.md](./props.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/modal)

> **Note:** **`visible && <TUXModal visible={visible} />`**

_See example: [example example-1](./examples.md#example-1)_

_See example: [example example-2](./examples.md#example-2)_

_See example: [example example-3](./examples.md#example-3)_
