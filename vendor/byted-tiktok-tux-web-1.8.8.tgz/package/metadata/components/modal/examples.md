<!-- tux-web · components/modal/examples -->
> **TUX `modal` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/modal)

## Example example-1

<a id="example-1"></a>

```tsx
import { IconChevronLeftOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXModal, TUXNavBar, TUXNavBarIconAction } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Modal"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal visible={visible} onVisibleChange={setVisible}>
        <TUXNavBar
          title="Modal"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} />}
          trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <div style={{ padding: 16, display: 'flex', gap: 8 }}>
          <TUXButton text="Close" onClick={() => setVisible(false)} />
        </div>
        <p style={{ flex: '1 1 0%', paddingInline: 16, paddingBlock: 8, overflowY: 'auto' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illud quaero, quid ei, qui in voluptate summum bonum
          ponat, consentaneum sit dicere.
        </p>
      </TUXModal>
    </>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import { IconChevronLeftOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXModal, TUXNavBar, TUXNavBarIconAction } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Modal"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal visible={visible} onVisibleChange={setVisible} landscape>
        <TUXNavBar
          title="Modal"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} />}
          trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <div style={{ padding: 16, display: 'flex', gap: 8 }}>
          <TUXButton text="Close" onClick={() => setVisible(false)} />
        </div>
        <p style={{ flex: '1 1 0%', paddingInline: 16, paddingBlock: 8, overflowY: 'auto' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illud quaero, quid ei, qui in voluptate summum bonum
          ponat, consentaneum sit dicere.
        </p>
      </TUXModal>
    </>
  );
};

export default Example;
```

## Example example-3

<a id="example-3"></a>

```tsx
import { IconChevronLeftOffsetLTR, IconXMarkSmall } from '@byted-tiktok/tux-icons';
import { TUXButton, TUXModal, TUXNavBar, TUXNavBarIconAction } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const Example: FC = () => {
  const [visible, setVisible] = useState(false);

  return (
    <>
      <TUXButton
        text="Open Modal"
        onClick={(): void => {
          setVisible(true);
        }}
      />
      <TUXModal visible={visible} onVisibleChange={setVisible} width="80%" height="400px">
        <TUXNavBar
          title="Modal"
          leading={<TUXNavBarIconAction icon={<IconChevronLeftOffsetLTR />} />}
          trailing={<TUXNavBarIconAction icon={<IconXMarkSmall />} onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <div style={{ padding: 16, display: 'flex', gap: 8 }}>
          <TUXButton text="Close" onClick={() => setVisible(false)} />
        </div>
        <p style={{ flex: '1 1 0%', paddingInline: 16, paddingBlock: 8, overflowY: 'auto' }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Illud quaero, quid ei, qui in voluptate summum bonum
          ponat, consentaneum sit dicere.
        </p>
      </TUXModal>
    </>
  );
};

export default Example;
```
