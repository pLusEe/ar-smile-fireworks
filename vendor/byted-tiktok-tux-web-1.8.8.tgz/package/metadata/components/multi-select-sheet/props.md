<!-- tux-web · components/multi-select-sheet/props -->
> **TUX `multi-select-sheet` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/item-picker)

## `TUXSingleSelectSheet` props _(version: v1)_

_Props type: `TUXSingleSelectSheetProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue?` | `string` |  | Specified initial checked value in uncontrolled mode |
| `value?` | `string` |  | Specified checked value in controlled mode |
| `title?` | `string` |  | Main title of the NavBar in the Sheet. |
| `showNavBarSeparator?` | `boolean` | `false` | Whether to show separator of the NavBar |
| `options` | `TUXSingleSelectOptionProps[]` |  | Array of single select option data. TUXSingleSelectOptionProps: { title: string, description?: string, name: string, value: string, disabled?: boolean} |
| `onChange?` | `(value?: string) => void` |  | Callback event triggered when the checked value changes. |
| `onItemClick?` | `(e: React.MouseEvent<HTMLDivElement>, value?: string) => void` |  | Callback event triggered when the item clicked. |
| `position?` | `'bottom' \| 'left' \| 'right'` | `bottom` | Direction in which the sheet is displayed. |
| `heightModePreset?` | `'auto' \| 'fixed'` | `auto` | Preset height modes of the sheet if position = "bottom". |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether clicking the overlay closes the sheet. |
| `height?` | `string` |  | Height of the sheet, only valid if position = "bottom" |
| `snapHeights?` | `string[]` |  | Multiple snap heights for the sheet, only valid if position = "bottom" |
| `snapMinHeight?` | `string` | `166px` | Minimum snap height for the sheet, only valid if position = "bottom", will be applied when at least one of the snapHeights is smaller than snapMinHeight |
| `snapMaxHeight?` | `string` | `100%` | Maximum snap height for the sheet, only valid if position = "bottom", will be applied when at least one of the snapHeights is larger than snapMaxHeight |
| `minHeight?` | `string` |  | Minimum height of the sheet, only valid if position = "bottom" && draggable = false |
| `maxHeight?` | `string` |  | Maximum height of the sheet, only valid if position = "bottom" && draggable = false |
| `width?` | `string` |  | Width of the sheet, only valid if position = "left" or "right" |
| `minWidth?` | `string` |  | Minimum width of the sheet, only valid if position = "left" or "right" |
| `maxWidth?` | `string` |  | Maximum width of the sheet, only valid if position = "left" or "right" |
| `marginBottom?` | `string` |  | Margin-bottom value of the sheet. |
| `zIndex?` | `number` | `2000` | Z-index of the sheet. |
| `overlayBackgroundColor?` | `TColorWithToken` |  | Background color of the overlay. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `sheetBackgroundColor?` | `TColorWithToken` |  | Background color of the sheet container. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `sheetBackground?` | `string` |  | Any background of the sheet container. |
| `dragHandle?` | `'auto' \| 'hidden' \| 'visible'` | `auto` | Whether to show drag handle, only valid if position = "bottom" (In 'auto' mode, it will be shown when the sheet has multiple snap heights) |
| `draggable?` | `boolean` | `false` | Whether the sheet is draggable. |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `heightModePreset` — @remarks
>
> - `auto` — sizes to content height
> - `fixed` — uses the specified `height` value exactly

> `overlayBackgroundColor`, `sheetBackgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TUXSingleSelectOptionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `React.ReactNode` |  | The title of the list cell. |
| `disabled?` | `boolean` | `false` | Whether the list cell is disabled. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `description?` | `React.ReactNode` |  | The description of the list cell. |
| `name` | `string` |  | Name of the data that the radio is associated with. Radios with the same name are grouped and control the same set of data. |
| `value` | `string` |  | Value that the radio option represents. This should be unique for all radios with the same name. |

## `TUXMultiSelectSheet` props _(version: v1)_

_Props type: `TUXMultiSelectSheetProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `defaultValue?` | `string[]` |  | Specified initial checked value in uncontrolled mode |
| `value?` | `string[]` |  | Specified checked value in controlled mode |
| `title?` | `string` |  | Main title of the NavBar in the Sheet. |
| `showNavBarSeparator?` | `boolean` | `false` | Whether to show separator of the NavBar |
| `options` | `TUXMultiSelectOptionProps[]` |  | Array of single select option data. TUXMultiSelectOptionProps: { title: string, description?: string, name: string, value: string, disabled?: boolean} |
| `submitText?` | `string` | `'Submit'` | Default submit button text. |
| `renderFooter?` | `(props: { value: string[]; updateValue: (value: string[]) => void }) => React.ReactNode` |  | Custom render footer using internal value |
| `onSubmit?` | `(value: string[]) => void` |  | Callback event triggered when the submit button clicked. |
| `onChange?` | `(value: string[]) => void` |  | Callback event triggered when the checked value changes. |
| `onItemClick?` | `(e: React.MouseEvent<HTMLDivElement>, value?: string) => void` |  | Callback event triggered when the item clicked. |
| `position?` | `'bottom' \| 'left' \| 'right'` | `bottom` | Direction in which the sheet is displayed. |
| `heightModePreset?` | `'auto' \| 'fixed'` | `auto` | Preset height modes of the sheet if position = "bottom". |
| `closeOnOutsideClick?` | `boolean` | `true` | Whether clicking the overlay closes the sheet. |
| `height?` | `string` |  | Height of the sheet, only valid if position = "bottom" |
| `snapHeights?` | `string[]` |  | Multiple snap heights for the sheet, only valid if position = "bottom" |
| `snapMinHeight?` | `string` | `166px` | Minimum snap height for the sheet, only valid if position = "bottom", will be applied when at least one of the snapHeights is smaller than snapMinHeight |
| `snapMaxHeight?` | `string` | `100%` | Maximum snap height for the sheet, only valid if position = "bottom", will be applied when at least one of the snapHeights is larger than snapMaxHeight |
| `minHeight?` | `string` |  | Minimum height of the sheet, only valid if position = "bottom" && draggable = false |
| `maxHeight?` | `string` |  | Maximum height of the sheet, only valid if position = "bottom" && draggable = false |
| `width?` | `string` |  | Width of the sheet, only valid if position = "left" or "right" |
| `minWidth?` | `string` |  | Minimum width of the sheet, only valid if position = "left" or "right" |
| `maxWidth?` | `string` |  | Maximum width of the sheet, only valid if position = "left" or "right" |
| `marginBottom?` | `string` |  | Margin-bottom value of the sheet. |
| `zIndex?` | `number` | `2000` | Z-index of the sheet. |
| `overlayBackgroundColor?` | `TColorWithToken` |  | Background color of the overlay. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `sheetBackgroundColor?` | `TColorWithToken` |  | Background color of the sheet container. Accepts a TUX design token (e.g., `'UIShapePrimary'`) or any CSS color string. |
| `sheetBackground?` | `string` |  | Any background of the sheet container. |
| `dragHandle?` | `'auto' \| 'hidden' \| 'visible'` | `auto` | Whether to show drag handle, only valid if position = "bottom" (In 'auto' mode, it will be shown when the sheet has multiple snap heights) |
| `draggable?` | `boolean` | `false` | Whether the sheet is draggable. |
| `visible?` | `boolean` | `false` | Whether the floating component is visible. |
| `onVisibleChange?` | `(visible: boolean) => void` |  | Event callback triggered when the floating component visible state should change. |
| `autoFocus?` | `boolean` | `false` | Whether to auto focus floating element when overlay open |
| `root?` | `HTMLElement \| null \| React.MutableRefObject<HTMLElement \| null>` |  | Specifies the root node to which the floating component are attached. |
| `shouldCloseOnOutsideClick?` | `Exclude<UseDismissProps['outsidePress'], boolean>` |  | Pass function to customize condition to close the floating component when clicking outside. Reference: https://floating-ui.com/docs/usedismiss#outsidepress |
| `forceRender?` | `boolean` | `false` | Whether to force render the content before open. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |

#### Detailed notes

> `heightModePreset` — @remarks
>
> - `auto` — sizes to content height
> - `fixed` — uses the specified `height` value exactly

> `overlayBackgroundColor`, `sheetBackgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TUXMultiSelectOptionProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `title` | `React.ReactNode` |  | The title of the list cell. |
| `disabled?` | `boolean` | `false` | Whether the list cell is disabled. |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
| `description?` | `React.ReactNode` |  | The description of the list cell. |
| `name` | `string` |  | Name of the data that the checkbox is associated with. Checkboxes with the same name are grouped and control the same set of data. |
| `value` | `string` |  | Value that the checkbox option represents. This should be unique for all checkboxes with the same name. |

## `TUXItemPickerView` props _(version: v1)_

_Props type: `TUXItemPickerViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `header?` | `React.ReactNode` |  | Header of the item picker. |
| `footer?` | `React.ReactNode` |  | Footer of the item picker. |
