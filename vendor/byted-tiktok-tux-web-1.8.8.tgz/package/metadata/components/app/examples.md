<!-- tux-web · components/app/examples -->
> **TUX `app` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/app)

## Example example-1

<a id="example-1"></a>

```tsx
import { TUXApp } from '@byted-tiktok/tux-web';

<TUXApp theme="light" textDirection="ltr" platform="desktop">
  <YourApp />
</TUXApp>
```

## Example example-2

<a id="example-2"></a>

```tsx
import { TUXApp, useSystemTheme } from '@byted-tiktok/tux-web';

const theme = useSystemTheme();

<TUXApp theme={theme} textDirection="ltr" platform="desktop">
  <YourApp />
</TUXApp>
```

## Example example-3

<a id="example-3"></a>

```tsx
import { TUXApp, useViewportBreakpoint } from '@byted-tiktok/tux-web';

const App = () => {
  const breakpoint = useViewportBreakpoint();

  return (
    <TUXApp
      theme="light"
      textDirection="ltr"
      platform="desktop"
      breakpoint={breakpoint}
    >
      <YourApp />
    </TUXApp>
  );
};
```

## Example example-4

<a id="example-4"></a>

```tsx
import { useTheme } from '@byted-tiktok/tux-web';

const Example = () => {
  const { theme } = useTheme();

  return (
    <>
      <div>theme: {theme}</div>
    </>
  );
}
```

## Example example-5

<a id="example-5"></a>

```tsx
import { useTextDirection } from '@byted-tiktok/tux-web';

const Example = () => {
  const textDirection = useTextDirection();

  return (
    <div>
      {textDirection}
    </div>
  );
}
```

## Example example-6

<a id="example-6"></a>

```tsx
import { usePlatform } from '@byted-tiktok/tux-web';

const Example = () => {
  const platform = usePlatform();

  return (
    <div>
      {platform}
    </div>
  );
}
```

## Example example-7

<a id="example-7"></a>

```tsx
import { useBreakpoint } from '@byted-tiktok/tux-web';

const Example = () => {
  const breakpoint = useBreakpoint();

  return (
    <div>
      {breakpoint.horizontal} / {breakpoint.vertical}
    </div>
  );
}
```

## Example example-8

<a id="example-8"></a>

```tsx
import { useTUXContext } from '@byted-tiktok/tux-web';

const Example = () => {
  const { theme, textDirection, platform, breakpoint } = useTUXContext();

  return (
    <div>
      {theme}
    </div>
  );
}
```
