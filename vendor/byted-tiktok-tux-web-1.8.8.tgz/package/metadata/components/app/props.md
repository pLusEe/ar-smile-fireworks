<!-- tux-web · components/app/props -->
> **TUX `app` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/app)

## `TUXApp` props _(version: v1)_

_Props type: `TUXAppProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `TTUXContextValue['theme']` |  | The theme for the entire project |
| `textDirection?` | `TTUXContextValue['textDirection']` |  | The text direction for the entire project, the default value is 'ltr' |
| `platform` | `TTUXContextValue['platform']` |  | The platform information. |
| `breakpoint?` | `TTUXContextValue['breakpoint']` |  | The viewport breakpoint for the entire project. Defaults to `large`/`medium` on desktop and `small`/`medium` on mobile platforms. |
| `highContrastColors?` | `Partial<TTUXColorMap>` |  | Activates high-contrast accessibility mode for the subtree. Pass the high-contrast color map (typically `colorsV2HighContrastRgba` from `@byted-tiktok/tux-color`) to enable; omit to disable. Requires importing `@byted-tiktok/tux-web/colors-v2-high-contrast.css` to apply the matching CSS variable overrides. |

#### Detailed notes

> `highContrastColors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Referenced types

#### `TTUXContextValue`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `theme` | `'light' \| 'dark'` |  |  |
| `textDirection` | `'ltr' \| 'rtl'` |  |  |
| `platform` | `'iOS' \| 'android' \| 'desktop'` |  |  |
| `breakpoint` | `TUXBreakpoint` |  |  |
| `colors` | `TTUXColorMap` |  | Runtime color lookup table distributed to components. |

> `colors` — TTUXColorMap
>
> The full color lookup table distributed through `TUXContext`.

#### Other referenced types

#### `TUXBreakpoint`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `horizontal` | `TUXHorizontalBreakpoint` |  |  |
| `vertical` | `TUXVerticalBreakpoint` |  |  |
