<!-- tux-web · components/index-picker-view/props -->
> **TUX `index-picker-view` component — props** (tux-web)
> See also: [content.md](./content.md) · [examples.md](./examples.md) · [source page](https://tux.bytedance.net/v1/docs/components/index-picker-view)

## `TUXIndexPickerView` props _(version: v1)_

_Props type: `TUXIndexPickerViewProps`_

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `items` | `TUXIndexGroupItemProps[]` |  | Index groups of the index picker. |
| `showSearch?` | `boolean` | `true` | Whether to show search input. |
| `backgroundColor?` | `TColorWithToken` | `'UIPageFlat1'` | Background color of the index picker view. |
| `onChange?` | `(value: string) => void` |  | Callback function when an item is selected. |
| `searchFilter?` | `(searchText: string, itemText: string) => boolean` |  | Filter function for searching items. |
| `customText?` | `TIndexPickerCustomText` |  | Custom text for the index picker view. |

#### Detailed notes

> `backgroundColor` — TColorWithToken
>
> A color value: either a TUX design-system token name (a PascalCase
> `ColorV2Name`, e.g. `'UIShapePrimary'`) or a raw CSS color (e.g. `'#ff0000'`).
> For the full token list and meanings, see the ask-tux metadata
> `tokens/color.md`.

#### Referenced types

#### `TUXIndexGroupItemProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `anchorTitle` | `string` |  | Anchor title of the index group. |
| `groupTitle` | `string` |  | Group title of the index group. |
| `groupItems` | `({ text: string; value: string } & TTestProps)[]` |  | Items of the index group. |

#### `TIndexPickerCustomText`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `searchPlaceholder?` | `string` |  |  |
| `noResultTitle?` | `string` |  |  |
| `noResultMessage?` | `string` |  |  |

#### Other referenced types

#### `TTestProps`

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `testId?` | `string` |  | The test id of the component, setting data-testid attribute. |
