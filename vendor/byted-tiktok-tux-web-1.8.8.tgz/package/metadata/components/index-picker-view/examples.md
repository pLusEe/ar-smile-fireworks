<!-- tux-web · components/index-picker-view/examples -->
> **TUX `index-picker-view` component — examples** (tux-web)
> See also: [content.md](./content.md) · [props.md](./props.md) · [source page](https://tux.bytedance.net/v1/docs/components/index-picker-view)

## Example example-1

<a id="example-1"></a>

```tsx
import { TUXIndexPickerView, TUXIndexGroupItemProps, TUXText } from '@byted-tiktok/tux-web';
import { FC, useState } from 'react';

const groupItems: TUXIndexGroupItemProps[] = [
  {
    groupTitle: 'label1',
    anchorTitle: '1',
    groupItems: [
      { text: 'option1', value: 'option1' },
      { text: 'option2', value: 'option2' },
    ],
  },
  {
    groupTitle: 'label2',
    anchorTitle: '2',
    groupItems: [
      { text: 'option3', value: 'option3' },
      { text: 'option4', value: 'option4' },
    ],
  },
  {
    groupTitle: 'label3',
    anchorTitle: '3',
    groupItems: [
      { text: 'option5', value: 'option5' },
      { text: 'option6', value: 'option6' },
    ],
  },
];

const Example: FC = () => {
  const [value, setValue] = useState<string>('');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px', gap: '8px', border: 'solid 1px' }}>
      <TUXText typography="P1-Regular" as="div">
        value: {value}
      </TUXText>
      {/* <div style={{ height: '400px', border: 'solid 1px' }}> */}
      <TUXIndexPickerView items={groupItems} onChange={(value: string) => setValue(value)} />
      {/* </div> */}
    </div>
  );
};

export default Example;
```

## Example example-2

<a id="example-2"></a>

```tsx
import React, { FC, useState } from 'react';
import {
  TUXSheet,
  TUXNavBar,
  TUXNavBarCloseButton,
  TUXButton,
  TUXIndexPickerView,
  TUXIndexGroupItemProps,
  TUXText,
} from '@byted-tiktok/tux-web';

const groupItems: TUXIndexGroupItemProps[] = [
  {
    groupTitle: 'label1',
    anchorTitle: '1',
    groupItems: [
      { text: 'option1', value: 'option1' },
      { text: 'option2', value: 'option2' },
    ],
  },
  {
    groupTitle: 'label2',
    anchorTitle: '2',
    groupItems: [
      { text: 'option3', value: 'option3' },
      { text: 'option4', value: 'option4' },
    ],
  },
  {
    groupTitle: 'label3',
    anchorTitle: '3',
    groupItems: [
      { text: 'option5', value: 'option5' },
      { text: 'option6', value: 'option6' },
    ],
  },
];

const Example: FC = () => {
  const [visible, setVisible] = useState<boolean>(false);
  const [value, setValue] = useState<string>('');

  return (
    <>
      <TUXButton text="Open Index Picker Sheet" onClick={() => setVisible(true)} />
      <TUXText typographyPreset="P1-Regular" as="div">
        value: {value ?? 'unselect'}
      </TUXText>
      <TUXSheet visible={visible} onVisibleChange={setVisible} height={'500px'}>
        <TUXNavBar
          title="Index Picker"
          trailing={<TUXNavBarCloseButton onClick={() => setVisible(false)} />}
          backgroundColor={'UISheetFlat1'}
        />
        <TUXIndexPickerView
          items={groupItems}
          backgroundColor={'UISheetFlat1'}
          onChange={(value: string) => {
            setValue(value);
            setVisible(false);
          }}
        />
      </TUXSheet>
    </>
  );
};

export default Example;
```
