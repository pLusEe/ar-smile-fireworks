# `@byted-tiktok/tux-web` v1.8.8

Catalog of knowledge files for `@byted-tiktok/tux-web`. See [`GUIDELINES.md`](./GUIDELINES.md) for how to read them.

Find your target here, then open only the linked file(s) — a component under `components/<slug>/`, a design token in `tokens/<category>.md`, or a how-to in `guides/<slug>.md`. **Searching this file for an export name (e.g. `TUXButton`) maps it to its component** via the Exports column.

## Components

| Component | Exports | Files | Docs |
| --- | --- | --- | --- |
| `accordion` | `TUXAccordion` | [content](components/accordion/content.md) · [props](components/accordion/props.md) · [examples](components/accordion/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/accordion) |
| `action-sheet` | `TUXActionSheet` | [content](components/action-sheet/content.md) · [props](components/action-sheet/props.md) · [examples](components/action-sheet/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/action-sheet) |
| `app` | `TUXApp` | [content](components/app/content.md) · [props](components/app/props.md) · [examples](components/app/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/app) |
| `avatar` | `TUXAvatar` | [content](components/avatar/content.md) · [props](components/avatar/props.md) · [examples](components/avatar/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/avatar) |
| `avatar-stack` | `TUXAvatarStack` | [content](components/avatar-stack/content.md) · [props](components/avatar-stack/props.md) · [examples](components/avatar-stack/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/avatar-stack) |
| `button` | `TUXButton` | [content](components/button/content.md) · [props](components/button/props.md) · [examples](components/button/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/button) |
| `calendar` | `TUXCalendar` | [content](components/calendar/content.md) · [props](components/calendar/props.md) · [examples](components/calendar/examples.md) |  |
| `center-toast` | `TUXCenterToast`, `TUXCenterToastView` | [content](components/center-toast/content.md) · [props](components/center-toast/props.md) · [examples](components/center-toast/examples.md) |  |
| `checkbox` | `TUXCheckbox` | [content](components/checkbox/content.md) · [props](components/checkbox/props.md) · [examples](components/checkbox/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/checkbox) |
| `chip` | `TUXChip`, `TUXChipGroup` | [content](components/chip/content.md) · [props](components/chip/props.md) · [examples](components/chip/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/chip) |
| `configure` | `TUXConfigure` | [content](components/configure/content.md) · [props](components/configure/props.md) · [examples](components/configure/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/configure) |
| `date-picker` | `TUXDatePicker` | [content](components/date-picker/content.md) · [props](components/date-picker/props.md) · [examples](components/date-picker/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/date-picker) |
| `date-picker-sheet` | `TUXDatePickerSheet` | [content](components/date-picker-sheet/content.md) · [props](components/date-picker-sheet/props.md) · [examples](components/date-picker-sheet/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/date-picker-sheet) |
| `dialog-view` | `TUXDialogView` | [content](components/dialog-view/content.md) · [props](components/dialog-view/props.md) · [examples](components/dialog-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/dialog-view) |
| `dual-avatar` | `TUXDualAvatar` | [content](components/dual-avatar/content.md) · [props](components/dual-avatar/props.md) · [examples](components/dual-avatar/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/dual-avatar) |
| `floating-notice` | `TUXFloatingNotice`, `TUXFloatingNoticeView` | [content](components/floating-notice/content.md) · [props](components/floating-notice/props.md) · [examples](components/floating-notice/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/floating-notice) |
| `form-item-footer` | `TUXFormItemFooter` | [content](components/form-item-footer/content.md) · [props](components/form-item-footer/props.md) · [examples](components/form-item-footer/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/form-item-footer) |
| `form-item-header` | `TUXFormItemHeader` | [content](components/form-item-header/content.md) · [props](components/form-item-header/props.md) · [examples](components/form-item-header/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/form-item-header) |
| `form-view` | `TUXFormView` | [content](components/form-view/content.md) · [props](components/form-view/props.md) · [examples](components/form-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/form-view) |
| `grid` | `TUXGrid`, `TUXGridCell` | [content](components/grid/content.md) · [props](components/grid/props.md) · [examples](components/grid/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/grid) |
| `horizontal-steps` | `TUXHorizontalSteps` | [content](components/horizontal-steps/content.md) · [props](components/horizontal-steps/props.md) · [examples](components/horizontal-steps/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/horizontal-steps) |
| `icon-button` | `TUXIconButton` | [content](components/icon-button/content.md) · [props](components/icon-button/props.md) · [examples](components/icon-button/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/icon-button) |
| `index-picker-view` | `TUXIndexPickerView` | [content](components/index-picker-view/content.md) · [props](components/index-picker-view/props.md) · [examples](components/index-picker-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/index-picker-view) |
| `input` | `TUXInput`, `TUXInputIconAction`, `TUXInputLike` | [content](components/input/content.md) · [props](components/input/props.md) · [examples](components/input/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/input) |
| `interaction-container` | `TUXInteractionContainer` | [content](components/interaction-container/content.md) · [props](components/interaction-container/props.md) · [examples](components/interaction-container/examples.md) |  |
| `intro-panel` | `TUXIntroPanel` | [content](components/intro-panel/content.md) · [props](components/intro-panel/props.md) · [examples](components/intro-panel/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/intro-panel) |
| `intro-view` | `TUXIntroView` | [content](components/intro-view/content.md) · [props](components/intro-view/props.md) · [examples](components/intro-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/intro-view) |
| `item-picker-view` | `TUXItemPickerView` | [content](components/item-picker-view/content.md) · [props](components/item-picker-view/props.md) · [examples](components/item-picker-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/item-picker) |
| `link` | `TUXLink` | [content](components/link/content.md) · [props](components/link/props.md) · [examples](components/link/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/link) |
| `list-cell` | `TUXListCell` | [content](components/list-cell/content.md) · [props](components/list-cell/props.md) · [examples](components/list-cell/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/list-cell) |
| `list-header` | `TUXListHeader` | [content](components/list-header/content.md) · [props](components/list-header/props.md) · [examples](components/list-header/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/list) |
| `list-view` | `TUXListView` | [content](components/list-view/content.md) · [props](components/list-view/props.md) · [examples](components/list-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/list) |
| `loading-progress` | `TUXLoadingProgress` | [content](components/loading-progress/content.md) · [props](components/loading-progress/props.md) · [examples](components/loading-progress/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/loading-progress) |
| `loading-toast` | `TUXLoadingToast` | [content](components/loading-toast/content.md) · [props](components/loading-toast/props.md) · [examples](components/loading-toast/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/loading-toast) |
| `menu` | `TUXMenu` | [content](components/menu/content.md) · [props](components/menu/props.md) · [examples](components/menu/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/menu) |
| `modal` | `TUXModal` | [content](components/modal/content.md) · [props](components/modal/props.md) · [examples](components/modal/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/modal) |
| `multi-select-sheet` | `TUXMultiSelectSheet` | [content](components/multi-select-sheet/content.md) · [props](components/multi-select-sheet/props.md) · [examples](components/multi-select-sheet/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/item-picker) |
| `nav-bar` | `TUXNavBar`, `TUXNavBarTextAction`, `TUXNavBarIconAction`, `TUXNavBarCloseButton`, `TUXNavBarTitle` | [content](components/nav-bar/content.md) · [props](components/nav-bar/props.md) · [examples](components/nav-bar/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/nav-bar) |
| `overlay` | `TUXOverlay` | [content](components/overlay/content.md) · [props](components/overlay/props.md) · [examples](components/overlay/examples.md) |  |
| `pin` | `TUXPin` | [content](components/pin/content.md) · [props](components/pin/props.md) · [examples](components/pin/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/pin) |
| `popover` | `TUXPopover` | [content](components/popover/content.md) · [props](components/popover/props.md) · [examples](components/popover/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/popover) |
| `radio` | `TUXRadio` | [content](components/radio/content.md) · [props](components/radio/props.md) · [examples](components/radio/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/radio) |
| `segmented-control` | `TUXSegmentedControl` | [content](components/segmented-control/content.md) · [props](components/segmented-control/props.md) · [examples](components/segmented-control/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/segmented-control) |
| `select` | `TUXSelectBox`, `TUXSelect` | [content](components/select/content.md) · [props](components/select/props.md) · [examples](components/select/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/select) |
| `separator` | `TUXSeparator` | [content](components/separator/content.md) · [props](components/separator/props.md) · [examples](components/separator/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/separator) |
| `sheet` | `TUXSheet` | [content](components/sheet/content.md) · [props](components/sheet/props.md) · [examples](components/sheet/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/sheet) |
| `single-select-sheet` | `TUXSingleSelectSheet` | [content](components/single-select-sheet/content.md) · [props](components/single-select-sheet/props.md) · [examples](components/single-select-sheet/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/item-picker) |
| `skeleton` | `TUXSkeleton` | [content](components/skeleton/content.md) · [props](components/skeleton/props.md) · [examples](components/skeleton/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/skeleton) |
| `spinner` | `TUXSpinner` | [content](components/spinner/content.md) · [props](components/spinner/props.md) · [examples](components/spinner/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/spinner) |
| `status-view` | `TUXStatusView` | [content](components/status-view/content.md) · [props](components/status-view/props.md) · [examples](components/status-view/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/status-view) |
| `switch` | `TUXSwitch` | [content](components/switch/content.md) · [props](components/switch/props.md) · [examples](components/switch/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/switch) |
| `tab-bar` | `TUXTabBar` | [content](components/tab-bar/content.md) · [props](components/tab-bar/props.md) · [examples](components/tab-bar/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/tab-bar) |
| `tag` | `TUXTag` | [content](components/tag/content.md) · [props](components/tag/props.md) · [examples](components/tag/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/tag) |
| `text` | `TUXText` | [content](components/text/content.md) · [props](components/text/props.md) · [examples](components/text/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/text) |
| `textarea` | `TUXTextArea` | [content](components/textarea/content.md) · [props](components/textarea/props.md) · [examples](components/textarea/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/text-area) |
| `toast` | `TUXTopToast`, `TUXBottomToast`, `TUXToastPortal` | [content](components/toast/content.md) · [props](components/toast/props.md) · [examples](components/toast/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/toast) |
| `tooltip` | `TUXTooltip` | [content](components/tooltip/content.md) · [props](components/tooltip/props.md) · [examples](components/tooltip/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/tooltip) |
| `vertical-steps` | `TUXVerticalSteps` | [content](components/vertical-steps/content.md) · [props](components/vertical-steps/props.md) · [examples](components/vertical-steps/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/vertical-steps) |
| `wheel-picker` | `TUXWheelPickerColumn`, `TUXWheelPickerWrapper`, `useDateWheelPicker` | [content](components/wheel-picker/content.md) · [props](components/wheel-picker/props.md) · [examples](components/wheel-picker/examples.md) | [docs](https://tux.bytedance.net/v1/docs/components/wheel-picker) |

## Tokens

| Category | File | Docs |
| --- | --- | --- |
| color | [tokens/color.md](tokens/color.md) | [docs](https://tux.bytedance.net/v1/docs/colors) |
| typography | [tokens/typography.md](tokens/typography.md) | [docs](https://tux.bytedance.net/v1/docs/typography) |
| radius | [tokens/radius.md](tokens/radius.md) | [docs](https://tux.bytedance.net/v1/docs/radius) |
| shadow | [tokens/shadow.md](tokens/shadow.md) | [docs](https://tux.bytedance.net/v1/docs/shadow) |

## Guides

- [breakpoint](guides/breakpoint.md) · [docs](https://tux.bytedance.net/v1/docs/breakpoint)
- [component-map](guides/component-map.md) — Mapping table from legacy TUX libs (V0, tux-h5, tux-pc) to TUX Web V1 components. · [docs](https://tux.bytedance.net/v1/docs/component-map)
- [faq](guides/faq.md) — Common questions for out-of-app web (tux-web, tux-h5, tux-pc). · [docs](https://tux.bytedance.net/v1/docs/faq)
- [high-contrast](guides/high-contrast.md) — Opt-in accessibility high-contrast color palette and how to enable it. · [docs](https://tux.bytedance.net/v1/docs/high-contrast)
- [migration-others](guides/migration-others.md) — Migrating from other legacy libs (@byted-tiktok/tux-components, tux-pc) to TUX Web. · [docs](https://tux.bytedance.net/v1/docs/migration-others)
- [migration-web](guides/migration-web.md) — Migrating from TUX Web V0 to V1, one component at a time. · [docs](https://tux.bytedance.net/v1/docs/migration-web)
- [motion](guides/motion.md) — Animation/motion curves — the spring and pop models and their hooks. · [docs](https://tux.bytedance.net/v1/docs/motion)
- [optimal-text-resize](guides/optimal-text-resize.md) — Variable font sizing that scales text to fit its container. · [docs](https://tux.bytedance.net/v1/docs/optimal-text-resize)
- [overview](guides/overview.md) — What TUX is and the currently maintained TUX Web packages. · [docs](https://tux.bytedance.net/v1/docs/overview)
- [quick-start](guides/quick-start.md) — Install and first-render setup for TUX Web. · [docs](https://tux.bytedance.net/v1/docs/quick-start)
- [ssr](guides/ssr.md) — Server-side rendering setup (rootAttributes) to avoid first-screen flicker. · [docs](https://tux.bytedance.net/v1/docs/ssr)
- [static-resources](guides/static-resources.md) — Fonts, icons, illustrations, and colors — the packages that ship them, versions/CDNs, and FAQ. · [docs](https://tux.bytedance.net/v1/docs/static-resources)
- [tux-web-import-error-analysis](guides/tux-web-import-error-analysis.md) — Root cause and fixes for the TypeScript import error when combining tux-web with EdenX BFF. · [docs](https://tux.bytedance.net/v1/docs/tux-web-import-error-analysis)
- [d2c](guides/d2c.md) — Figma-to-React (D2C) code generation for TUX Web — setup, Figma token, and local/remote modes. · [docs](https://tux.bytedance.net/v1/docs/d2c)
- [get-figma-token](guides/get-figma-token.md) — Step-by-step guide to creating a Figma personal access token for D2C. · [docs](https://tux.bytedance.net/v1/docs/get-figma-token)
- [tux-fe-helper](guides/tux-fe-helper.md) — AI-assisted TUX FE toolkit — installing the tux-fe-helper skill and the @tiktok-mcp/tux MCP server. · [docs](https://tux.bytedance.net/v1/docs/tux-fe-helper)
- [tux-knowledge](guides/tux-knowledge.md) — Intelligent Q&A for TUX knowledge, locally via tux-fe-helper or online via TUX-Pert. · [docs](https://tux.bytedance.net/v1/docs/tux-knowledge)

