<!-- tux-web · tokens/typography -->
> **TUX tokens — typography** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/typography)

# Typography tokens

## Classes

| Name | Size | Line height | Letter spacing | CSS size variable | CSS line-height variable | CSS letter-spacing variable |
| --- | --- | --- | --- | --- | --- | --- |
| `H1` | 24px | 1.25em | 0.01em | `--tux-v2-typography-h1-size` | `--tux-v2-typography-h1-line-height` | `--tux-v2-typography-h1-letter-spacing` |
| `H2` | 20px | 1.25em | 0.015em | `--tux-v2-typography-h2-size` | `--tux-v2-typography-h2-line-height` | `--tux-v2-typography-h2-letter-spacing` |
| `H3` | 17px | 1.3em | 0em | `--tux-v2-typography-h3-size` | `--tux-v2-typography-h3-line-height` | `--tux-v2-typography-h3-letter-spacing` |
| `H4` | 15px | 1.3em | 0.004em | `--tux-v2-typography-h4-size` | `--tux-v2-typography-h4-line-height` | `--tux-v2-typography-h4-letter-spacing` |
| `P1` | 14px | 1.3em | 0.0067em | `--tux-v2-typography-p1-size` | `--tux-v2-typography-p1-line-height` | `--tux-v2-typography-p1-letter-spacing` |
| `P2` | 13px | 1.3em | 0.0097em | `--tux-v2-typography-p2-size` | `--tux-v2-typography-p2-line-height` | `--tux-v2-typography-p2-letter-spacing` |
| `P3` | 12px | 1.3em | 0.0134em | `--tux-v2-typography-p3-size` | `--tux-v2-typography-p3-line-height` | `--tux-v2-typography-p3-letter-spacing` |
| `SmallText1` | 11px | 1.3em | 0.0177em | `--tux-v2-typography-smalltext1-size` | `--tux-v2-typography-smalltext1-line-height` | `--tux-v2-typography-smalltext1-letter-spacing` |
| `SmallText2` | 10px | 1.3em | 0.0229em | `--tux-v2-typography-smalltext2-size` | `--tux-v2-typography-smalltext2-line-height` | `--tux-v2-typography-smalltext2-letter-spacing` |
| `Headline` | 16px | 1.3em | 0.0019em | `--tux-v2-typography-headline-size` | `--tux-v2-typography-headline-line-height` | `--tux-v2-typography-headline-letter-spacing` |
| `Longform` | 16px | 1.5em | 0.0019em | `--tux-v2-typography-longform-size` | `--tux-v2-typography-longform-line-height` | `--tux-v2-typography-longform-letter-spacing` |
| `LargeTitle` | 32px | 1.2em | 0em | `--tux-v2-typography-largetitle-size` | `--tux-v2-typography-largetitle-line-height` | `--tux-v2-typography-largetitle-letter-spacing` |

## From the docs page

### Font & Typography

#### Font

> TikTokSans in Web now is V4, we provide variable font: TikTokSans by default. If your browser does not support variable fonts, we provide static fonts, TikTokSans16pt(similar to TikTokFont) and TikTokSans36pt(similar to TikTokDisplayFont). Reference: [TikTokSans V4](https://bytedance.us.larkoffice.com/docx/AxEKdknXdo1wn3xW1Zdu29t0sIe)

**V4 Font Mapping:**
- `TikTokFont` → `TikTokSans16pt`
- `TikTokDisplayFont` → `TikTokSans36pt`

##### How to use

Import the TUX Web CSS correctly.

1. Font Family is correctly set in TUX Components, you don't need to care about the font in most TUX Components that display text.
2. If you want to use TikTokSans in your own code, you can use like this:

_See example: [How to use](#how-to-use)_

---

#### Typography

TUX Web provides a set of typography presets that can be used to style text following the latest [TUX Design](https://www.figma.com/design/9QKNBsHpKGJlJVD9TVpcXn/%E2%9C%85--Typography-v1.6?node-id=1-445&m=dev).

You can use the typography presets to style text in the following ways:

##### Via TUXText

The TUXText component integrates typography. For more features, please check the [TUXText](/v1/docs/components/text)

_See example: [Via TUXText](#via-tuxtext)_

##### Via CSS

TUX Web provides a set of CSS classes.

_See example: [Via CSS](#via-css)_

---

#### Variable Font

In V4 font, we support variable fonts. You can change the width by manipulating the wdth axis, adjust the weight using the wght axis, or even fine-tune optical size and slant for responsive typography. These axes allow you to create smooth transitions and adaptive text styles without loading multiple font files.

##### How to use

You can manipulating font weight, width, slant, optical sizes by manipulating font-variation-settings.

_See example: [How to use](#how-to-use-1)_

##### How to use

Import the TUX Web CSS correctly.

1. Font Family is correctly set in TUX Components, you don't need to care about the font in most TUX Components that display text.
2. If you want to use TikTokSans in your own code, you can use like this:

<a id="how-to-use"></a>

```tsx
// your.css

// global
:root {
font-family: var(--tux-v2-font-text); // TikTokFont, TikTokSans16pt in V4
font-family: var(--tux-v2-font-display); // TikTokDisplayFont, TikTokSans36pt in V4
}

// scoped
.component {
font-family: var(--tux-v2-font-text); // TikTokFont, TikTokSans16pt in V4
font-family: var(--tux-v2-font-display); // TikTokDisplayFont, TikTokSans36pt in V4
}
```

##### Via TUXText

The TUXText component integrates typography. For more features, please check the [TUXText](/v1/docs/components/text)

<a id="via-tuxtext"></a>

```tsx
<div style={{ display: 'flex', flexDirection: 'column'}}>
  <TUXText typographyPreset='H1-Bold'>H1-Bold</TUXText>
  <TUXText typographyPreset='H1-Semibold'>H1-Semibold</TUXText>
  <TUXText typographyPreset='H2-Bold'>H2-Bold</TUXText>
  <TUXText typographyPreset='H2-Semibold'>H2-Semibold</TUXText>
  <TUXText typographyPreset='H2-Regular'>H2-Regular</TUXText>
  <TUXText typographyPreset='H3-Bold'>H3-Bold</TUXText>
  <TUXText typographyPreset='H3-Semibold'>H3-Semibold</TUXText>
  <TUXText typographyPreset='H3-Regular'>H3-Regular</TUXText>
  <TUXText typographyPreset='H4-Bold'>H4-Bold</TUXText>
  <TUXText typographyPreset='H4-Semibold'>H4-Semibold</TUXText>
  <TUXText typographyPreset='H4-Regular'>H4-Regular</TUXText>
  <TUXText typographyPreset='P1-Semibold'>P1-Semibold</TUXText>
  <TUXText typographyPreset='P1-Regular'>P1-Regular</TUXText>
  <TUXText typographyPreset='P2-Semibold'>P2-Semibold</TUXText>
  <TUXText typographyPreset='P2-Regular'>P2-Regular</TUXText>
  <TUXText typographyPreset='P3-Semibold'>P3-Semibold</TUXText>
  <TUXText typographyPreset='P3-Regular'>P3-Regular</TUXText>
  <TUXText typographyPreset='SmallText1-Semibold'>SmallText1-Semibold</TUXText>
  <TUXText typographyPreset='SmallText1-Regular'>SmallText1-Regular</TUXText>
  <TUXText typographyPreset='SmallText2-Semibold'>SmallText2-Semibold</TUXText>
  <TUXText typographyPreset='SmallText2-Regular'>SmallText2-Regular</TUXText>
  <TUXText typographyPreset='Headline-Bold'>Headline-Bold</TUXText>
  <TUXText typographyPreset='Headline-Semibold'>Headline-Semibold</TUXText>
  <TUXText typographyPreset='Headline-Regular'>Headline-Regular</TUXText>
  <TUXText typographyPreset='Longform-Bold'>Longform-Bold</TUXText>
  <TUXText typographyPreset='Longform-Semibold'>Longform-Semibold</TUXText>
  <TUXText typographyPreset='Longform-Regular'>Longform-Regular</TUXText>
  <TUXText typographyPreset='LargeTitle-Bold'>LargeTitle-Bold</TUXText>
  <TUXText typographyPreset='LargeTitle-Semibold'>LargeTitle-Semibold</TUXText>
</div>
```

##### Via CSS

TUX Web provides a set of CSS classes.

<a id="via-css"></a>

```tsx
<>
  <div class='H1-Bold'>H1-Bold</div>
  <div class='H1-Semibold'>H1-Semibold</div>
  <div class='H2-Bold'>H2-Bold</div>
  <div class='H2-Semibold'>H2-Semibold</div>
  <div class='H2-Regular'>H2-Regular</div>
  <div class='H3-Bold'>H3-Bold</div>
  <div class='H3-Semibold'>H3-Semibold</div>
  <div class='H3-Regular'>H3-Regular</div>
  <div class='H4-Bold'>H4-Bold</div>
  <div class='H4-Semibold'>H4-Semibold</div>
  <div class='H4-Regular'>H4-Regular</div>
  <div class='P1-Semibold'>P1-Semibold</div>
  <div class='P1-Regular'>P1-Regular</div>
  <div class='P2-Semibold'>P2-Semibold</div>
  <div class='P2-Regular'>P2-Regular</div>
  <div class='P3-Semibold'>P3-Semibold</div>
  <div class='P3-Regular'>P3-Regular</div>
  <div class='SmallText1-Semibold'>SmallText1-Semibold</div>
  <div class='SmallText1-Regular'>SmallText1-Regular</div>
  <div class='SmallText2-Semibold'>SmallText2-Semibold</div>
  <div class='SmallText2-Regular'>SmallText2-Regular</div>
  <div class='Headline-Bold'>Headline-Bold</div>
  <div class='Headline-Semibold'>Headline-Semibold</div>
  <div class='Headline-Regular'>Headline-Regular</div>
  <div class='Longform-Bold'>Longform-Bold</div>
  <div class='Longform-Semibold'>Longform-Semibold</div>
  <div class='Longform-Regular'>Longform-Regular</div>
  <div class='LargeTitle-Bold'>LargeTitle-Bold</div>
  <div class='LargeTitle-Semibold'>LargeTitle-Semibold</div>
</>
```

##### How to use

You can manipulating font weight, width, slant, optical sizes by manipulating font-variation-settings.

<a id="how-to-use-1"></a>

```tsx
// import { TUXText } from '@byted-tiktok/tux-web';

const EXAMPLE_TEXT = 'Ray just bought 3 yellow roses yesterday. ';

const Example = () => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', padding: '16px' }}>
      <TUXText typographyPreset="H1-Bold" style={{ marginBlock: '8px' }}>
        font weight, use font-variation-settings: "wght" 300 ~ 900
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"wght" 475' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"wght" 725' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H1-Bold" style={{ marginBlock: '8px' }}>
        font width, use font-variation-settings: "wdth" 75 ~ 150
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"wdth" 110' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"wdth" 130' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H1-Bold" style={{ marginBlock: '8px' }}>
        font slant, use font-variation-settings: "slnt" -6 ~ 0
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"slnt" -3' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"slnt" -6' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H1-Bold" style={{ marginBlock: '8px' }}>
        optical size, use font-variation-settings: "opsz" 12 ~ 36
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"opsz" 20' }}>
        {EXAMPLE_TEXT}
      </TUXText>
      <TUXText typographyPreset="H3-Semibold" style={{ fontVariationSettings: '"opsz" 36' }}>
        {EXAMPLE_TEXT}
      </TUXText>
    </div>
  )
}
```

