<!-- tux-web · tokens/radius -->
> **TUX tokens — radius** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/radius)

# Radius tokens

| Name | CSS variable | Value |
| --- | --- | --- |
| `content-tiny` | `var(--tux-v2-radius-content-tiny)` | `4px` |
| `content-small` | `var(--tux-v2-radius-content-small)` | `6px` |
| `content-medium` | `var(--tux-v2-radius-content-medium)` | `8px` |
| `content-large` | `var(--tux-v2-radius-content-large)` | `10px` |
| `content-xlarge` | `var(--tux-v2-radius-content-xlarge)` | `12px` |
| `content-capsule` | `var(--tux-v2-radius-content-capsule)` | `9999px` |
| `container-level0-small` | `var(--tux-v2-radius-container-level0-small)` | `8px` |
| `container-level1-small` | `var(--tux-v2-radius-container-level1-small)` | `10px` |
| `container-level2-small` | `var(--tux-v2-radius-container-level2-small)` | `16px` |
| `container-level0-large` | `var(--tux-v2-radius-container-level0-large)` | `10px` |
| `container-level1-large` | `var(--tux-v2-radius-container-level1-large)` | `14px` |
| `container-level2-large` | `var(--tux-v2-radius-container-level2-large)` | `26px` |

## From the docs page

### Radius

Radius tokens define the corner rounding of shapes and containers, keeping the curvature consistent across components and custom UI.

Tokens fall into two groups:

- **Content** — for content-level elements such as buttons, chips, inputs and tags. Sizes scale from `Tiny` to `Xlarge`, plus a fully rounded `Capsule`.
- **Container** — for surfaces such as cards, sheets and modals. Each nesting level (`Level0`–`Level2`) has a `Small` and `Large` variant so nested corners stay visually aligned.

### How to use 

##### use `getRadiusCSSVar` method to get TUX radius CSS Variable

- Content Radius

_See example: [use `getRadiusCSSVar` method to get TUX radius CSS Variable](#use-getradiuscssvar-method-to-get-tux-radius-css-variable)_

- Container Radius

_See example: [use `getRadiusCSSVar` method to get TUX radius CSS Variable](#use-getradiuscssvar-method-to-get-tux-radius-css-variable-1)_

##### use `getRadiusCSSVar` method to get TUX radius CSS Variable

- Content Radius

<a id="use-getradiuscssvar-method-to-get-tux-radius-css-variable"></a>

```tsx
<div style={{ display: 'flex', flexWrap: 'wrap', gap: '24px' }}>
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContentTiny'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContentSmall'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContentMedium'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContentLarge'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContentXlarge'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContentCapsule'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
</div>
```

##### use `getRadiusCSSVar` method to get TUX radius CSS Variable

- Container Radius

<a id="use-getradiuscssvar-method-to-get-tux-radius-css-variable-1"></a>

```tsx
<div style={{ display: 'flex', flexWrap: 'wrap', gap: '24px' }}>
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContainerLevel0Small'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContainerLevel1Small'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContainerLevel2Small'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContainerLevel0Large'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContainerLevel1Large'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
    <div style={{ width: '120px', height: '120px', borderRadius: getRadiusCSSVar('ContainerLevel2Large'), backgroundColor: getColorCSSVar('UIShapePrimary') }} />
</div>
```

