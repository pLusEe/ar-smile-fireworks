<!-- tux-web · tokens/shadow -->
> **TUX tokens — shadow** (tux-web)
> See also: [../index.md](../index.md) · [source page](https://tux.bytedance.net/v1/docs/shadow)

# Shadow tokens

| Name | CSS variable | Light | Dark |
| --- | --- | --- | --- |
| `blocking` | `var(--tux-v2-shadow-blocking)` | `0 24px 120px rgba(0, 0, 0, 0.16)` | `0 24px 120px rgba(0, 0, 0, 0.24)` |
| `global-notice` | `var(--tux-v2-shadow-global-notice)` | `0 12px 50px rgba(0, 0, 0, 0.1)` | `0 12px 50px rgba(0, 0, 0, 0.15)` |
| `floating` | `var(--tux-v2-shadow-floating)` | `0 6px 24px rgba(0, 0, 0, 0.1)` | `0 6px 24px rgba(0, 0, 0, 0.15)` |
| `attached` | `var(--tux-v2-shadow-attached)` | `0 2px 10px rgba(0, 0, 0, 0.14)` | `0 2px 10px rgba(0, 0, 0, 0.21)` |
| `subtle` | `var(--tux-v2-shadow-subtle)` | `0 2px 10px rgba(0, 0, 0, 0.07)` | `0 2px 10px rgba(0, 0, 0, 0.07)` |
| `contrast` | `var(--tux-v2-shadow-contrast)` | `0 1px 5px rgba(0, 0, 0, 0.3)` | `0 1px 5px rgba(0, 0, 0, 0.3)` |

## From the docs page

### Shadow

Shadows are key design elements that define product style, create visual hierarchy, and improve usability.

### How to use 

##### use `getShadowCSSVar` method to get TUX shadow CSS Variable

- Box Shadow

_See example: [use `getShadowCSSVar` method to get TUX shadow CSS Variable](#use-getshadowcssvar-method-to-get-tux-shadow-css-variable)_

- Drop Shadow

_See example: [use `getShadowCSSVar` method to get TUX shadow CSS Variable](#use-getshadowcssvar-method-to-get-tux-shadow-css-variable-1)_

##### use `getShadowCSSVar` method to get TUX shadow CSS Variable

- Box Shadow

<a id="use-getshadowcssvar-method-to-get-tux-shadow-css-variable"></a>

```tsx
<div style={{ display: 'flex', gap: '10px' }}>
    <div style={{ width: '150px', height: '150px', boxShadow: getShadowCSSVar('Blocking') }} />
    <div style={{ width: '150px', height: '150px', boxShadow: getShadowCSSVar('GlobalNotice') }} />
    <div style={{ width: '150px', height: '150px', boxShadow: getShadowCSSVar('Floating') }} />
    <div style={{ width: '150px', height: '150px', boxShadow: getShadowCSSVar('Attached') }} />
    <div style={{ width: '150px', height: '150px', boxShadow: getShadowCSSVar('Subtle') }} />
    <div style={{ width: '150px', height: '150px', boxShadow: getShadowCSSVar('Contrast') }} />
</div>
```

##### use `getShadowCSSVar` method to get TUX shadow CSS Variable

- Drop Shadow

<a id="use-getshadowcssvar-method-to-get-tux-shadow-css-variable-1"></a>

```tsx
<div style={{ display: 'flex', gap: '10px' }}>
    <IconStarRing style={{ width: '150px', height: '150px', color: 'var(--tux-v2-color-creation-flash-light-cold)', 
    filter: `drop-shadow(${getShadowCSSVar('Blocking')})` }} />
    <IconStarRing style={{ width: '150px', height: '150px', color: 'var(--tux-v2-color-creation-flash-light-cold)', 
    filter: `drop-shadow(${getShadowCSSVar('GlobalNotice')})` }} />
    <IconStarRing style={{ width: '150px', height: '150px', color: 'var(--tux-v2-color-creation-flash-light-cold)', 
    filter: `drop-shadow(${getShadowCSSVar('Floating')})` }} />
    <IconStarRing style={{ width: '150px', height: '150px', color: 'var(--tux-v2-color-creation-flash-light-cold)', 
    filter: `drop-shadow(${getShadowCSSVar('Attached')})` }} />
    <IconStarRing style={{ width: '150px', height: '150px', color: 'var(--tux-v2-color-creation-flash-light-cold)', 
    filter: `drop-shadow(${getShadowCSSVar('Subtle')})` }} />
    <IconStarRing style={{ width: '150px', height: '150px', color: 'var(--tux-v2-color-creation-flash-light-cold)', 
    filter: `drop-shadow(${getShadowCSSVar('Contrast')})` }} />
</div>
```

