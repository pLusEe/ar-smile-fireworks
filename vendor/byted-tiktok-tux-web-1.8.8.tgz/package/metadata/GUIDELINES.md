# TUX metadata: how to read these files

This directory is a TUX package's reference for AI agents — its components, design
tokens, and guides. Read this file first, then navigate with `index.md`.

## Layout

```
metadata/
├── GUIDELINES.md            # this file
├── index.md                 # catalog of every component, token, and guide (start here)
├── components/<slug>/
│   ├── content.md           # what sections/variants the component has
│   ├── props.md             # props table for every export (the API contract)
│   └── examples.md          # copy-paste code blocks
├── tokens/<category>.md      # color | typography | radius | shadow
└── guides/<slug>.md          # quick-start, faq, migration, ssr, …
```

## Find what you need

**Don't read whole folders.** Map your need to one file via `index.md`, open it, and
follow links from there.

- **Have an export name** (e.g. `TUXButton`) **and want its component?** Search
  `index.md` for it — the Exports column maps every export to its slug.
- **Writing a component?** Open `components/<slug>/`: `props.md` for the API
  (props, types, defaults), `examples.md` for working code, `content.md` for what
  variants exist.
- **Need a design token?** Read `tokens/<category>.md` — each token's name, value(s),
  and (where applicable) CSS variable and light/dark hex.
- **Need a how-to, migration, FAQ, or troubleshooting?** The Guides list in `index.md`
  gives each `guides/<slug>.md` a one-line scope hint — pick from there.
- **Asked for a component/export this package doesn't list?** If it isn't in this
  package's `index.md`, this package doesn't provide it — say so. Don't substitute a
  same-named component from another TUX package, change the import specifier, or invent props.

## Check the changelog for fixes

These files are pinned to the installed version and carry no release history. When you
hit a bug, a prop that behaves wrong, a missing component, or off-looking styling,
check whether a newer release already fixes it — download the latest changelog fresh:

```
GET https://tux.bytedance.net/api/changelog/<platform>
```

`<platform>` is `tux-web` or `tux-react-lynx` (`tux-rlynx-components` is deprecated,
no endpoint). Scan for the relevant fix — bug fix, prop change, new/missing component,
style change — and if one lands in a later version, tell the user which version to
upgrade to.

Platform-specific rules — icons/illustrations, color-as-prop, typography — are in the **Platform notes** at the bottom of this file. Read them before writing UI.

## Platform notes — tux-web

### Color-as-prop (`TColorWithToken`)

Props typed `TColorWithToken` (`backgroundColor`, `color`, `borderColor` on `TUXButton` and other primitives) take a token name in **PascalCase**: split the kebab-case name on `-` and capitalize each segment independently, so acronyms stay upper-cased (`ui-shape-primary` → `UIShapePrimary`, not `UiShapePrimary`).

| `tokens/color.md` `Name` | Prop value       |
| ------------------------ | ---------------- |
| `ui-shape-primary`       | `UIShapePrimary` |
| `primary`                | `Primary`        |
| `text-secondary`         | `TextSecondary`  |
| `bg-input`               | `BgInput`        |

```tsx
<TUXButton backgroundColor="UIShapePrimary" color="TextInversePrimary" />
```

To resolve the underlying CSS variable or hex, look up the kebab-case name in `tokens/color.md` (`CSS variable`, `Light hex`, `Dark hex`).

### Typography

`tokens/typography.md` lists **font-family tokens** alongside size/weight tokens. Apply a font-family token high up (e.g. the app root) to set the global text style. For one-off text that shouldn't inherit it, use **`TUXText`** — it applies the right typography token without global CSS.

### Icons & illustrations

Both ship as **separate npm packages** of plain **React SVG components** (see `guides/static-resources.md` for versions and cadence).

**Icons — `@byted-tiktok/tux-icons`.** Import the named **`Icon<Name>`** component (e.g. `IconStarRing`) and render it directly; it's a plain SVG component styled with standard SVG attributes (`fontSize`, `color`, …). To color it from a design token, resolve the token with `getColorCSSVar` from `@byted-tiktok/tux-web`:

```tsx
import { IconStarRing } from '@byted-tiktok/tux-icons';
import { getColorCSSVar } from '@byted-tiktok/tux-web';

<IconStarRing fontSize={48} color={getColorCSSVar('UITextPrimaryDisplay')} />
```

To put an icon in a component's icon slot, pass the `Icon<Name>` element as JSX (slots are typed `React.ReactNode`):

```tsx
import { TUXIconButton } from '@byted-tiktok/tux-web';
import { IconArrowUpBold } from '@byted-tiktok/tux-icons';

<TUXIconButton sizePreset="medium" icon={<IconArrowUpBold />} onClick={onSubmit} />
```

See that component's `components/<slug>/` (e.g. `components/icon-button/`) for the slot's prop and more examples.

**Illustrations — `@tiktok-arch/tux-illustration/web`** (the `/web` subpath). Render directly or pass as JSX to an image slot:

```tsx
import { TUXStatusView } from '@byted-tiktok/tux-web';
import { IllustrationEmptyHumanChatBubble } from '@tiktok-arch/tux-illustration/web';

<TUXStatusView title="…" message="…" image={<IllustrationEmptyHumanChatBubble />} />
```

Using illustrations **without** `tux-web` (tux-illustration > 1.2.5): import the theming variables once at your app root — `import '@tiktok-arch/tux-illustration/styles.css';`
