# @byted-tiktok/tux-web

## 1.8.8
### 🌟 Feature

- feat: `TUXSelect` add prop placement [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/11049)

## 1.8.7
### 🌟 Feature

- feat: `TUXPopover` add prop matchTriggerWidth, `TUXSelect` add prop autoFlip [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10995)
- Updated dependencies
  - @byted-tiktok/tux-color@1.3.9 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10921)

## 1.8.6
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-color@1.3.8 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10516)

## 1.8.5
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-color@1.3.7 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/10097)


## 1.8.4
### 🌟 Feature

- feat: `TUXTopToast` limit maximum width to 430px [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9294)
- feat: add TUXBottomToast component [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9244)
- feat: `TUXIntroPanel` bottom-align large screens, unify motion with compact layout, and set max-width to 430px [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9248)
- feat: `TUXSheet` support resize mode. [Reference](https://bytedance.larkoffice.com/wiki/ALGbwCwHtiHJqNkSXGCcz5LFnGg) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9366)

## 1.8.3
### 🌟 Feature

- feat: added component `TUXFloatingNotice` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8508)
- Updated dependencies
  - @byted-tiktok/tux-color@1.3.6 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9256)

### 🐛 Fixed

- fix: `TUXDialogView` update fixed width from 280px to 302px [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9246)

## 1.8.2
### 🌟 Feature

- feat: add breakpoint context to TUXApp [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/9082)


## 1.8.1
### 🐛 Fixed

- fix: add inner stroke to avatar and avatar-stack components [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8542)

## 1.8.0
### 🌟 Feature

- feat: append version suffix to CSS Modules class names [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8467)
- Updated dependencies
  - @byted-tiktok/tux-color@1.3.5 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8455)

## 1.7.1
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-color@1.3.4 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/8202)

## 1.7.0
### 🐛 Fixed

- fix: replace framer-motion with motion-dom for React 17 / 18 compatibility [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7858)


## 1.6.2
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-color@1.3.2 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7679)

## 1.6.1
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-color@1.3.1 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7588)

## 1.6.0
### 🌟 Feature

- feat: add high contrast color support [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7225)

## 1.5.7
### 🌟 Feature

- feat: added metadata knowledge files to give agents more context on TUX usage [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7060)
- Updated dependencies
  - @byted-tiktok/tux-color@1.3.0 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/7187)

## 1.5.6
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-color@1.2.26 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6941)

## 1.5.5
### 🌟 Feature
- Updated dependencies [8c6327b]
  - @byted-tiktok/tux-icons@2.39.53 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6792)
  - @byted-tiktok/tux-color@1.2.25 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6765)

### 🐛 Fixed
- 🐛 `TUXRadio` & `TUXCheckbox` Fixed an issue where the border was not displayed correctly. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6598)

## 1.5.4
### 🌟 Feature

- feat: `TUXNavBar` design upgrade (reference: https://bytedance.larkoffice.com/wiki/O4F3wBMVaiRw4okBop2c8t9hnkh) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6235)
- fix: fix close button unclickable issue on `TUXIntroPanel` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6580)
- feat: `TUXButton` add prop smooth radius [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6576)

## 1.5.3
### 🌟 Feature

- Updated dependencies [31efd0e]
  - @byted-tiktok/tux-color@1.2.24 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6401)
  - @byted-tiktok/tux-icons@2.39.51 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6516)

## 1.5.2
### 🌟 Feature

- feat: `TUXTopToast` and `TUXCenterToast` design upgrade (reference: https://bytedance.larkoffice.com/wiki/SmfFwvoiMiJMpgk5Lo3cmaAhnWc) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6171)
- feat: add all.css output [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6218)

### 🐛 Fixed
- fix: fix border not showing issue on `TUXCheckbox`, `TUXRadio`, `TUXDatePicker` and `TUXDatePickerSheet` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6396)

## 1.5.1
### 🌟 Feature

- feat: add error-shaking motion to `TUXInput`, `TUXPin`, add spring motion to `TUXPopover`, `TUXSegmentedControl`(reference: https://bytedance.larkoffice.com/wiki/P64uwcr0iikXvfkly7fczlUEnmb) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5973/)
- feat: `TUXTooltip` radius, shadow design upgrade(reference: https://bytedance.sg.larkoffice.com/docx/H67idCMPqooQuHxD3lAllWtwgTe) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6041)
- Updated dependencies [57539bf]
  - @byted-tiktok/tux-icons@2.39.50 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6202)

## 1.5.0
### 🌟 Feature

- feat: design upgrade [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5731)
    - corner radius upgrade (reference: https://bytedance.us.larkoffice.com/docx/SfXydY6k0osfr7xhGrIuWRdjsmb)
    - **BREAK** `TUXButton` height changed, shapePreset default 'capsule', support custom borderRadius
    - `TUXStatusView` style changed
    - add `TUXNavBarCloseButton`
  
### 🔨 Changed
- chore: change compiled output from bundled to unbundled [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5966)
- chore: remove up-down icon on `TUXDatePicker` title, since this feature is not supported yet. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/6025)

## 1.4.10
### 🌟 Feature

- feat: `TUXSheet` add prop sheetBackground [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5963)

## 1.4.9
### 🌟 Feature

- Updated dependencies [5508973]
  - @byted-tiktok/tux-color@1.2.23 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5766)
  - @byted-tiktok/tux-icons@2.39.48 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5796)

### 🐛 Fixed

- fix: `TUXIntroView` title align center [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5837)

## 1.4.8
### 🔨 Changed

- chore: change font-display from 'fallback' to 'swap' to improve text rendering performance [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5739)

### 🌟 Feature

- Updated dependencies 
  - @tiktok-arch/tux-illustration@0.2.5 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5572)
  - @byted-tiktok/tux-color@1.2.22 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5736)
  - @byted-tiktok/tux-icons@2.39.47 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5718)

### 🐛 Fixed

- fix: `TUXWheelPicker` units now properly follow text direction [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5589)

## 1.4.7
### 🌟 Feature

- feat: add drag gesture on `TUXSheet`[MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5147)

### 🐛 Fixed

- fix: text-align logical value not convert properly [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5585)
- fix: fix useSpringMotion hook to jump to initial position when active [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5147)

## 1.4.6
### 🌟 Feature

- Updated dependencies [b129cce]
  - @byted-tiktok/tux-color@1.2.21 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5452)
  - @byted-tiktok/tux-icons@2.39.45 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5500)

### 🐛 Fixed

- fix: autoFocus not work on `TUXModal` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5474)

## 1.4.5
### 🌟 Feature

- Updated dependencies 
  - @byted-tiktok/tux-icons@2.39.44 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5407)
  - @tiktok-arch/tux-illustration@0.2.3 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5340)

## 1.4.4
### 🌟 Feature

- Updated dependencies [8defcdb]
  - @byted-tiktok/tux-color@1.2.20 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5128)

## 1.4.3
### 🌟 Feature

- Updated dependencies 
  - @byted-tiktok/tux-color@1.2.19 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5065)
  - @byted-tiktok/tux-icons@2.39.42 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/5091)

### 🐛 Fixed

- fix: footer button min width on status view [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4966)

## 1.4.2
### 🌟 Feature

- feat: add TUX motion hook - useSpringMotion and usePopMotion (reference: https://bytedance.sg.larkoffice.com/docx/L2JddNjOYowaPIxfl0fllZi1ghZ?302from=wiki) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4471)
- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.41[MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4887)

### 🐛 Fixed
- fix: fix `TUXLoadingToast` closeOnOutsideClick issue [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4930)

## 1.4.1
### 🌟 Feature
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.18 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4653)
  - @byted-tiktok/tux-icons@2.39.40 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4688)

### 🐛 Fixed
- fix: `TUXButton` set default value of prop `block` as `undefined`. `true` means the width will be 100%, which is same as version lower than 1.4.0; `false` mean the width will be fit-content; `undefined` means follow the default behavior of div. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4674)

## 1.4.0
### 🐛 Fixed
- fix: layout issues caused by large font-size on global [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4571)
    - **BREAK** `TUXButton` change from 'inline-flex' to 'flex', and update css in reset for button. The default layout behavior will be changed from 'inline' to 'block'.
    - **BREAK** ~~`TUXButton` set default value of block from `false` to `true`, `true` means the behavior will be same as `div`, false mean it will `fit-content`~~ **Updated in V1.4.1**
    - change some inner components & elements from 'inline-flex' to 'block' in `TUXDialogView` and `TUXInput`
    - add display prop for `TUXCheckbox`, `TUXRadio` and `TUXSpinner`, allow them to dispaly in block
- fix: fix font cdn spell issue [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4605)
- fix: fix TUXNavBar text styles, fix typography semibold token to 600px [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4533)
- fix: padding issue on `TUXActionSheet` item. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4572)
- fix: 3 issues on `TUXTabBar` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4432)
    - add scroll into view when click
    - fix gap between indicator and separator
    - remove initial indicator animation

## 1.3.0
### 🌟 Feature

- feat: support v4 fonts (reference: https://bytedance.us.larkoffice.com/docx/AxEKdknXdo1wn3xW1Zdu29t0sIe) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4026)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.17 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4260)

## 1.2.12
### 🌟 Feature

- feat: add hover state for `TUXMenu`, `TUXSegmentedControl`, `TUXTabBar` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4115)

### 🐛 Fixed

- fix: add focus trap on `TUXModal` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/4116)

## 1.2.11
### 🌟 Feature

- feat: `TUXIndexPicker` add custom text [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3966)

## 1.2.10

### 🌟 Feature

- feat: add new component `TUXHorizontalSteps` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3769)
- feat: add new component `TUXVerticalSteps` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3701)
- feat: `TUXListCell` title support ReactNode [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3875)

### 🐛 Fixed

- fix: fix `TUXDialogView` single button footer padding issue [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3876)

## 1.2.9
### 🌟 Feature

- feat: add new component `TUXDualAvatar` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3645)
- feat: add `useSingleLineOptimalTextResize` and `useMultiLineOptimalTextResize` hook, add textResize, titleResize prop on `TUXButton`, `TUXCenterToast`, `TUXIntroView`, `TUXStatusView`, `TUXTopToast`, and `TUXTooltip` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3459)
- feat: add getShadowCSSVar method [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3558)
- feat: `TUXSelect` support maxHeight. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3780)
- feat: `TUXPopover` allow users to customize the safe area [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3772)
- Updated dependencies 
  - @byted-tiktok/tux-icons@2.39.35 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3704)
  - @tiktok-arch/tux-illustration@0.2.1 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3629)

## 1.2.8
### 🌟 Feature
- Updated dependencies 
  - @byted-tiktok/tux-color@1.2.16 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3573)
  - @byted-tiktok/tux-icons@2.39.34 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3576)

### 🐛 Fixed

- fix: fix `TUXButton` issue [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3571)
  - fix children visible issue when loading
  - fix icon shrink issue in flex box
- fix: `TUXChip` lack min-width on text [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3485)

## 1.2.7
### 🌟 Feature

- feat: add new components `TUXIntroPanel` and `TUXIntroView` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3075)
- Updated dependencies 
  - @byted-tiktok/tux-color@1.2.14 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3343)
  - @byted-tiktok/tux-icons@2.39.32 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3295)

### 🐛 Fixed

- fix: fix `TUXSegmentedControl` background issue in dark mode, hide scrollbar. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3294)
- fix: `TUXModal` landscape layout, attach bottom first. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3325)
- fix: fix `TUXTabBar` indicator wrong width if fitContent=true and fading edge optimization [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3300)

## 1.2.6
### 🌟 Feature
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.13 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3186)

### 🐛 Fixed

- fix: fix `TUXDialogView` text action position [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3104)
- fix: `TUXDialogView` layout issue in landscape mode on mobile [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3161)
- fix: fix `TUXLoadingToast` wrong position issue [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3132)
- fix: add touch-actin: none for `TUXOverlay` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3214)

## 1.2.5
### 🌟 Feature

- feat: add customFooter prop on `TUXStatusView` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2961)
- feat: add hover state for `TUXListCell` and `TUXTag` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3068)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.12 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3025)
  - @byted-tiktok/tux-icons@2.39.30 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3061)
  - @tiktok-arch/tux-illustration@0.2.0 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2848)

### 🐛 Fixed

- fix: replace IceCreamIllustration with IllustrationEmptyIcecream on `TUXIndexPickerView` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2848)
- fix: useDateWheelPicker option display priority [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2962)
- fix: `TUXButton` in borderless mode, will not support hover on mobile [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3063)
- fix: fix 3 bugs [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/3003)
  - `TUXModal` width issue in small screen
  - `TUXSheet` lack anmation when close
  - 'justify-content' and 'align-items' compatible issue


## 1.2.4
### 🌟 Feature

- feat: css output transform logical props to traditional props [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2864)
- feat: `TUXSheet` and `TUXModal` support forceRender [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2901)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.11 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2857), [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2958)
  - @byted-tiktok/tux-icons@2.39.29 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2959)

### 🐛 Fixed

- fix: `TUXButton` won't show hover mask after click on mobile [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2937)

## 1.2.3
### 🌟 Feature

- chore: remove displayName on components, resolve side effects on tree shaking, optimize bundle size [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2671)
- feat: added new useDateWheelPicker hook [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2627)
- feat: add `getTUXAlias` & `getTUXAliasCompatible` that used in bundle tools. [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2691)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.10 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2628)
  - @byted-tiktok/tux-rlynx-icons@2.39.27 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2729)

## 1.2.2
### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.26 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2545), [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2629)

### 🐛 Fixed

- fix: remove redundant global CSS and unused radius styles [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2565)

## 1.2.1
### 🌟 Feature

- feat: add openDelay/closeDelay prop on `TUXTooltip` and `TUXPopover` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2443)
- feat: `TUXTopToast` add root prop in static method [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2501)
- feat: `TUXPopover` and `TUXTooltip` support use same trigger [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2456)
- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.25 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2424)
  - @byted-tiktok/tux-color@1.2.9 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2522)

## 1.2.0

### 💥 Breaking Changes

- feat: `TUXWheelPicker` - **remove** uncontrolled behavior support and prop 'defaultValue' (removed defaultValue prop) [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2337)

### 🐛 Fixed
  
  fix: `TUXWheelPicker` - fixed bugs with onValueChange and multiple animations at once [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2337)
- fix: `TUXActionSheet` - fixed action sheet color [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2417)
- fix: `TUXInput` - password dot size inconsistencies across platforms [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2415)

## 1.1.0

### 💥 Breaking Changes

- feat: add badge and ring on `TUXAvatar` and **remove** contentType prop [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2007)

### 🌟 Feature

- feat: add new component `TUXWheelPicker` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2006)
- feat: `TUXPopover` add configure [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2156)
- feat: `TUXPopover` add safePolygon [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2036)
- feat: add allowExceedMaxLength prop on `TUXInput` and `TUXTextArea` [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2172)
- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.24 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/176015), [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2278)
  - @byted-tiktok/tux-color@1.2.8 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/176014), [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2271)

### 🐛 Fixed

- fix: fix `TUXTextArea` selection overflow issue on mobile, fix `TUXInput` and `TUXTextArea` counter length initial value not set [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2172)
- fix: fix `TUXLoading` svg size [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2250)

## 1.0.0

### 💥 Breaking Changes
- change default export [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/1988)
   - Changed default export to use Canary components, import path: `@byted-tiktok/tux-web/canary` -> `@byted-tiktok/tux-web`
   - Moved all v0 version components to `deprecated` directory, import path: `@byted-tiktok/tux-web` -> `@byted-tiktok/tux-web/deprecated`
- `TUXIndexPickerView` groupItems add value prop [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/175268)

### 🌟 Feature
- feat: add new component `TUXAvatarStack` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/175112)
- feat: change throw error to warn in production env, only throw error in dev [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/175484)

### 🐛 Fixed

- fix: type cannot found in ts version lower than 5.0 [MR](https://code.byted.org/tiktok/arch_web_monorepo/merge_requests/2015)
- fix: fix `TUXTag` height to fit-content and set flex-shrink to 0 on leading and trailing icon [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/175625)

## 0.16.5(1.0.0-preview.8)

### Canary

- Canary: fix `TUXItemPicker` height issue in sheet [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174657)
- Canary: fix `TUXToast` incompatible with react 17 and below issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174719)
- Canary: add Component `TUXPin` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173512)
- Canary: add Component `TUXIndexPickerView` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174712)
- Canary: fix: disable user-select on `TUXButton` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/175129)
- Canary: fix word-break from break-all to break-word on `TUXFormItemFooter` and `TUXCenterToast` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/175100)
- Canary: `TUXChip` add hover state [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174700)

### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.23 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174570)

## 0.16.4(1.0.0-preview.7)

### Canary

- Canary: add hover effect on `TUXButton` and `TUXLink` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172161)
- Canary: add Component `TUXAccordion`. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173408)
- Canary: add Component `TUXSegmentedControl` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173024)
  Canary: change `TUXTabBar` onItemClick method params order [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173024)
- Canary: add no-image layout on `TUXDialogView` and make title and message part a block element [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174018)
- Canary: add interactive mode on `TUXListCell` and add text color on `TUXNavBar` title [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174514)
- Canary: `TUXListCell` make title and description block elements, change flex layout to grid layout on stacked mode, change description from string to ReactNode [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174123)
- Canary: fix `TUXFormItemFooter` message vertical align issue and make message icon not display when no message [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/174511)

## 0.16.3(1.0.0-preview.6)

### 🌟 Feature

- Updated dependencies [c7d235b]
  - @byted-tiktok/tux-icons@2.39.22 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173513)

### Canary

- Canary: fix `TUXTopToast` text align issue, add topSafeAreaHeight props. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173668)
- Canary: fix version `preview.5` types export error.

## 0.16.2(1.0.0-preview.5)

### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.21 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172766), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172894)

### Canary

- Canary: tux cjs output, change lodash-es to lodash [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/173103)
- Canary: add Component `TUXChip` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172792)
- Canary: add new component `TUXDatePickerSheet` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172353)

## 0.16.1(1.0.0-preview.4)

### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.20 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172646), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172049),[MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172143)

### Canary

- Canary: move colorsV2 from index to single file to avoid require esm module issue in tailwind configuration. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172527)
- Canary: `TUXPopover` remove className & style props, add minHeight, minWidth, maxHeight, maxWidth props [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172107)
- Canary: `TUXButton` add block and paddingInline props, roll back default preset padding for children [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/172219)

## 0.16.0(1.0.0-preview.3)

### 🌟 Feature

- feat: add a new component `TUXProviderSimple` that do not deal with the 'system' [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171986)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.7 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171642)
  - @byted-tiktok/tux-icons@2.39.19 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171423)

### Canary

- Canary: add Component `TUXIconButton` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171074)
- Canary: add Component `TUXLoadingProgress` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171549)
- Canary: support for tailwind and export colors object. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171866)

### 💥 Breaking Changes

- Canary: remove theme: 'system' [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171986)
  - prop theme change from optional to required in `TUXApp`
  - remove finalTheme in all related components and functions
  - encapsulate the system theme logic to a hook `useSystemTheme`

## 0.15.11(1.0.0-preview.2)

### Canary

- Canary: fix components resolve wrong color v1 token [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171326)
- Canary: fix font face url request not work issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171083)
- Canary: add minHeight and maxHeight prop to `TUXModal` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171153)
- Canary: add cursor on `TUXAvatar` and `TUXTag` if they are interactive [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170920)
- Canary: fix: canary reset css add more rules, and add lack classname in components [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/171096)
- Canary: fix placement value mismatch with floating-ui placement. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170994)

## 0.15.10(1.0.0-preview.1)

### Canary

- Canary: `TUXCenterToast` remove showCloseButton prop align to design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170866)
- Canary: fix `TUXLoadingToast`, `TUXSelectSheet` unexpected default auto focus issue. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170514)
- Canary: allow pass both ColorV2Name and any color value to color props [MR1](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170331),[MR2](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170780)
- Canary: event handler API redesign [Reference](https://bytedance.larkoffice.com/wiki/UUK4wkHALibjUTkrW6jchra4nhc) [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170564)
- Canary: rename `TUXTextarea` to `TUXTextArea` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170361)
- Canary: restrict custom style props from html attributes type [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170071)
- Canary: change `TUXSpinner` sizePreset xlarge to huge [Reference](https://bytedance.larkoffice.com/wiki/UUK4wkHALibjUTkrW6jchra4nhc) [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170860)
- Canary: fix: fix `TUXDialogView` text-action border issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170916)
- Canary: fix: add error state border on `TUXInput` when counter exceeds max length [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170579)
- Canary: adjust API according to the API guideline 7 ~ 10 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170487)

## 0.15.9

### 🌟 Feature

- feat: add openDelay prop on `TUXTooltip` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170262)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.5 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/169262)
  - @byted-tiktok/tux-icons@2.39.17 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170162)

### Canary

- Canary: rename components API [Reference](https://bytedance.larkoffice.com/wiki/UUK4wkHALibjUTkrW6jchra4nhc) [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170046)
- Canary: change canary style export path [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/170067)
- Canary: fix `TUXTopToast` createRoot in body issue, change portal structure [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168880)
- Canary: add component 'TUXActionSheet'. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168820)
- Canary: add Component `TUXCenterToast` and `TUXLoadingToast` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/169375)

## 0.15.8

### 🌟 Feature

- feat: `TUXSelect` add onOpenChange props [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168751)
- feat: `TUXSelect` add a new prop renderButtonLabelV2 to customize text when no item is selected. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168704)

### Canary

- Canary: remove useZindexConfig
- Canary: chore: rename `TUXProvider` to `TUXApp`, `TUXConfigProvider` to `TUXConfigure` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168696)
- Canary: merge `TUXText` sizePreset and weightPreset to typographyPreset props [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168511)
- Canary: add Component `TUXDialogView` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167927)
- Canary: add component `TUXSelect`, `TUXSelectBox`.[MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167968)
- Canary: fix: fix `TUXSkeleton` color token from v1 to v2 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168814)

## 0.15.7

### 🌟 Feature

- feat: add closeDelay prop on `TUXTooltip` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168292)
- feat: add forwardRef on `TUXTextArea` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168285)
- feat: add floatingGap in `TUXPopover` V1 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168134)

### 🐛 Fixed

- fix: `TUXFormField` error icon align issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168226)
- fix: fix `TUXSearchableSelect` search match issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/168211)

### Canary

- Canary: add Component `TUXStatusView` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167426)

## 0.15.6

### 🌟 Feature

- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.17 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167771)

### Canary

- Canary: rename `TUXInputLabel` to `TUXFormItemHeader`, `TUXInputFooter` to `TUXFormItemFooter`. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167518)
- Canary: add Component `TUXItemPicker`, `TUXSingleSelectSheet`, `TUXMultiSelectSheet`. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166273)
- Canary: add new component `TUXDatePicker` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/167360)

## 0.15.5

### Canary

- Canary: add Component `TUXAvatar` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166414)
- Canary: add Component `TUXFormView` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166895)
- Canary: add Component `TUXTextarea` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166016)
- Canary: add Component `TUXListCell` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166273)
- Canary: add Component `TUXListView` and `TUXListHeader` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166617)
- Canary: add Component `TUXTabBar`. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165734)
- Canary: add new component `TUXLink` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165602)

## 0.15.4

### 🌟 Feature

- feat: add select into zIndexConfig and fix `TUXSearchableSelect` zIndex issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/166172)

### Canary

- Canary: add Component `TUXInputLabel` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165097)

## 0.15.3

### 🌟 Feature

- feat: add 'id' prop to `TUXCheckbox`, `TUXRadio`, and `TUXSwitch`
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.4 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164672)
  - @byted-tiktok/tux-icons@2.39.14 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164961)

### 🐛 Fixed

- - fix: ltr icons support auto-flip in tux-web [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165017)
- fix: `TUXTableCell` align issue and word-break issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165059)

### Canary

- Canary: fix invalid reset style and remove global font style
- Canary: fix `TUXInteractionContainer` invalid pressed state on iOS [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164644)
- Canary: `TUXNavBar` add heightPreset props, default is 52 instead of depending on platform. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164848)
- Canary: add Component `TUXTopToast`. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164081)
- Canary: add canary component `TUXtooltip` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164865)
- Canary: fix flex-shrink issue on `TUXCheckbox`, `TUXRadio`, and `TUXSwitch` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/165288)
- Canary: add Component `TUXInput` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163994)

## 0.15.2

### 🐛 Fixed

- fix: fix `TUXTooltip` hovering delay and rm open/dismiss animation time [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163191)
- fix: fix `TUXDialog`, `TUXModal`, `TUXSheet` scrollable issue on Android [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164207)
- fix: `TUXTableCell` layout and `TUXDateWheelPicker` className [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164334)
- fix: `TUXTabBar` underline calculate bug. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/164313)

### Canary

- Canary: add `TUXPopover`, and add forwardRef for `TUXButton` and `TUXInteractionContainer` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163148)
- Canary: add scope reset css [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163520)
- Canary: add component `TUXConfigProvider` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163931)

## 0.15.1

### 🌟 Feature

- update dependencies
  - @byted-tiktok/tux-icons@2.39.14 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162313), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/161615)

### 🐛 Fixed

- fix: fix `TUXLoadingToast` unexpected focus issue in safari. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162971)
- fix: fix `TUXTextInput` auto-fill background color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/161512), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163429)
- fix: several oncalls [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/163345)
  - add prop root for TUXSheet, `TUXActionSheet`, `TUXTooltip`
  - add prop isDayDisabled for `TUXDatePicker`
  - add prop isError for `TUXTextInput`
  - fix `TUXButton` after press state on mobile

### Canary

- Canary: fix `TUXButton` size issue in flexbox [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162609)
- Canary: add Component `TUXCheckbox` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160382)
- Canary: add Component `TUXLoading` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162887)
- Canary: add Component `TUXRadio` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160419)
- Canary: add Component `TUXSkeleton` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162467)
- Canary: add Component `TUXSwitch` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160547)
- Canary: add Component `TUXTag` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160666)
- Canary: add Component `TUXNavBar` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/162188)
- Canary: add Component `TUXSeparator` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/161843)

## 0.15.0

### 🌟 Feature

- feat(Minor): change default shape for TUXButton, xs and s use 'capsule', m and l use 'normal' [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160911)

### 🐛 Fixed

- fix: fix TUXDateRangePicker, TUXDatePickerSheet, TUXDateRangePickerSheet to reset internalValue when value changes [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160449)

### Canary

- Canary: add Component TUXModal [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/160295)
- Canary: add Component TUXSheet [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158599)

## 0.14.4

### 🐛 Fixed

- fix: add dismiss control in TUXSheet [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/159706)

## 0.14.3

### 🌟 Feature

- feat: upgrade TUXAccordion design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156530)
  - add `leadingIcon` prop to `TUXAccordionSection`
  - fix `TUXAccordion` styles like padding and margin

### 🐛 Fixed

- fix: fix `TUXLoadingCircle` centered vertically when no label [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158794)
- fix: fix `TUXNavBar` title font-weight when no subtitle [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158629)
- fix: abnormal dismiss when using two `TUXModal` simultaneously [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158384)
- fix: add renderOptionLabel in `TUXSearchableSelect` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158972)
- fix: allow custom trigger add events in components: `TUXDatePicker`, `TUXDatePickerSheet`, `TUXDateRangePicker`, `TUXPopover` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158344)
- fix: upgrade `TUXStatusView` design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156720)
  - fix margin between image and title, title and message
  - fix `TUXStatusViewFixedHeightLayout` button position
  - fix `TUXStatusView` message text styles

### Canary

- Canary: add Component `TUXButton` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/155881)
- canary: add prop platform in `TUXProvider` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/158182)

## 0.14.2

### 🌟 Feature

- feat: canary provider add zIndexConfig [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/157131)
- feat: upgrade TUXTabBar design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/155334)
  - add `leadingIcon` and `hasTrailingArrow` prop to `TUXTabBar`
  - add active item underline moving animation
- feat: upgrade TUXTooltip design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/154805)
  - fix min-width and min-height of the `TUXTooltip`
  - add `leadingIcon`, `hasTrailingArrow` and `hideIndicator` prop to `TUXTooltip`
- feat: add canary components TUXGrid & TUXGridCell [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156405)
- Updated dependencies
  - @byted-tiktok/tux-color@1.2.3 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156748)

### 🐛 Fixed

- fix: fix menu lack of a11y focus issue after popup disappear [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/157689)
- fix: disable focus style for TUXTextAreaBox [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/157467)

### Canary

- canary: add Component TUXInteractionContainer [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/156459)

## 0.14.1

### Feature

- 🌟 upgrade TUXChip design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153652)

  - add `quietMode` prop to `TUXChip`
  - add `shape` prop to `TUXMultiSelectChip`
  - fix `TUXMultiSelectChip` background-color when selected

- 🌟 upgrade TUXMenu design [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/154914)

  - add `trailingIcon` prop to `TUXMenuItem`

### Canary

- 🌟 add Component TUXSpinner [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/154844)
- 🌟 add Component TUXText [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153986)

## 0.14.0

### 🔨 Changed

- refactor: remove type: module in package.json, and adjust output js. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/154075)

### 🐛 Fixed

- fix: adjust close icon size for TUXSheet [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153818)

## 0.13.1

### 🌟 Feature

- feat: add prop `flexTitle` on `TUXNavBar` to fix title cutoff issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150884)

### 🐛 Fixed

- fix: fix `TUXTopToast` and `TUXBottomToast` background color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153054)

### Canary

- feat: add Component TUXProvider [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/153566)

## 0.12.6

### 🌟 Feature

- feat: allow custom click in customTrigger [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/151650)

### 🐛 Fixed

- fix: `TUXSearchableSelect` do not clear input when focus [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/152229)

## 0.12.5

### 🌟 Feature

- feat: DatePickerSheet & DateRangePickerSheet [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150044)
  - add `onDismiss` callback prop.
  - add `selectableRange` prop.
  - fix some i18n issues.
- add z-index control in `TUXDialog` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150573)
- feat: add `hideLabel` in `TUXRadioGroup` & `TUXCheckboxGroup` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150819)
- feat: add disabled support in `TUXNavBarTextButton` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/150846)
- feat: `TUXSheet` add height and maxHeight props [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/151076)

### 🐛 Fixed

- fix: title width is too short in modal nav bar [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/149289)
- fix: Misc fixes for props types and onClick [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/147733)
  - Updated `onClick` props types to `MouseEventHandler` for `TUXGroupSelectOptionCell`, `TUXGroupSelectOptionCell`, `TUXGroupSelectOptionCell`
  - Passed click event to onClick in `TUXMenuItem`
  - Updated props types for `TUXPopover`, `TUXMenu`, `TUXModal` to also include base React props for `div`
  - Return type of TUXToastContextValue.addToast

## 0.12.4

### 🐛 Fixed

- fix: `TUXDatePicker` display wrong when `value` update [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/148514)

## 0.12.3

### 🌟 Feature

- 🌟 add bottomText, submitText, onSubmit prop to TUXDatePicker, TUXDateRangePicker, TUXDatePickerSheet, TUXDateRangePickerSheet [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/145260)
- 🌟 update dependencies
  - @byted-tiktok/tux-icons@2.39.8 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141104), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/147241)

### 🐛 Fixed

- fix: 'gap' doesn't work in flex box, when version is under iOS 14 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/146056)
- fix: 'locale' doesn't work in DatePicker Calender [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/146538)
- fix: `TUXSegmentedControl` active item background wrong. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/147402)

## 0.12.2

### Feature

- 🌟 add customTitle on `TUXNavBar` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/144403)

### Fixed

- 🐛 fix: css filter priority problem in `TUXButton` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/144357)

## 0.12.1

### Feature

- 🌟 expose `TUXToastContext` for external management [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142779)

### Fixed

- 🐛 `TUXText` Updated to use clsx instead of style [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142711)

## 0.12.0

### Feature

- 🌟 add Component `TUXAppBar`, `TUXScrollAppBar` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/140017)
- 🌟 add Component `TUXFullBleedLoadingPage` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141173)
- 🌟 `TUXSheet` support landscape orientation [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/140936)
- 🌟 `TUXModal` add outsidePressDismiss props [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141875)
- 🌟 `TUXModal` add `root` props [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142440)
- 🌟 add Component `TUXAvatar`, `TUXDualAvatar`, `TUXAvatarBadge` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142011)
- 🌟 update dependencies
  - @byted-tiktok/tux-icons@2.39.6 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141104), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142876)

### Fixed

- 🐛 fix: useId generated id do not match in server side and client side [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141160)
- 🐛 fix `TUXTextInput` maxLength issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/141922)
- 🐛 fix `TUXPopover`, `TUXTooltip` edge display issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/142516)

## 0.11.0

### Feature

- 🌟 add Component `TUXGroupSelector` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138183)
- 🌟 add 'root' prop to `TUXPopover` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138276)
- 🌟 add Component `TUXStickyTopLayout` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138416)
- 🌟 add Component `TUXRegionPicker` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138476)
- 🌟 add Component `TUXFlex` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138934)
- 🌟 add Component `TUXPaginationPC` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138960)
- 🌟 add Component `TUXAppBar`, `TUXScrollAppBar` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/140017)
- 🌟 add forwardRef support and add `onFocus` & `onBlur` description in component `TUXTextInput` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/139204)
- 🌟 add Component `TUXDatePickerSheet` and `TUXDateRangePickerSheet` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/133626)
- 🌟 modify component `TUXCheckbox` and `TUXRadio`: props 'checked' and 'onChange' to optional [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/139551)
- 🌟 add Component `TUXSingleItemPicker` and `TUXMultiItemPicker` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/138252)
- 🌟 update dependencies
  - @byted-tiktok/tux-icons@2.39.5 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/139156), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/140413)

### Fixed

- 🐛 fix `TUXButton` loading animation nonlinear issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/139091)

## 0.10.0

### Feature

- 🌟 add Component `TUXTableCell` (including TUXTableButtonCell, TUXTableCheckboxCell, TUXTableDisclosureCell, TUXTableLabelCell, TUXTableLabelCell, TUXTableSwitchCell) [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134694)
- 🌟 add Component `TUXStatusView` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/137262)
- 🌟 add Components `TUXDateWheelPicker` and `TUXWheelPickerGroup` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/137414)
- 🌟 update dependencies
  - @byted-tiktok/tux-icons@2.39.4 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/137015), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/137854)

## 0.9.0

### Feature

- 🌟 add Component `TUXIntro` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/135645)
- 🌟 add Component `TUXCenterToast`,`TUXLoadingToast` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134636)
- 🌟 `TUXToastManager` support `addToastSingleMode` method [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134636)
- 🌟 export all props types from each component and re-export all props types through index [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134678)
- 🌟 add Component `TUXPrice` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136326)
- 🌟 update dependencies
  - @byted-tiktok/tux-icons@2.39.3 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136302), [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136765)

### Fixed

- 🐛 fix `TUXButton` doesn't add "disabled" attribute [MR](https://bits.bytedance.net/code/ies/tiktok_web_monorepo/merge_requests/134686)
- 🐛 fix `TUXTextInput` and `TUXTextArea` selection color [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134209)
- 🐛 fix expose onChange event on `TUXTextInput` and `TUXTextArea` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134764)
- 🐛 fix `TUXTextInput` focus and design issue [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/132411)
- 🐛 fix `TUXDatePicker` cannot set to Jan. and Dec. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136344)
- 🐛 fix `TUXDatePicker` Calender text color wrong. [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/136815)

## 0.8.0

### Feature

- 🌟 add Component `TUXActionSheet` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/131997)
- 🌟 add Component `TUXDialog` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/132894)
- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.2 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/132337),[MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/134425)

### Feature

- 🌟 add calendar-sheet on `TUXDatePicker` and `TUXRangeDatePicker` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/133626)

### Fixed

- 🐛 fix TUXEnvironment do not init color scheme and ssr judgement [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/133146)
- 🐛 fix `TUXTabBar` click failed issue on safari version lower than 17 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/133352)
- 🐛 fix `TUXSheet` no bottom safe area issue on mobile [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/131997)

## 0.7.0

### Feature

- 🌟 add Component `TUXSeparator` [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/130790)
- 🌟 add 'positionStrategy prop to TuxMenu and TUXPopover' [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/130921)
- 🌟 add 'add zIndexConfig to TUXProvider to allow users to customize zIndex' [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/131607)
- Updated dependencies
  - @byted-tiktok/tux-icons@2.39.1 [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/131035)

### Fixed

- 🐛 fix TUXEnvironment ts error [MR](https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/132079)

## 0.6.16

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/126218

- fix: TUXTextInput clear icon color

## 0.6.15

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/127104

- fix: fix TUXPopover, TUXModal, TUXSheet z-index issues

## 0.6.14

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/125752

- fix: fix TUXDatePicker responsiveness
- fix: TUXIcon color type from 'TUXTextColorName' to 'TUXColorName'
- feat: add button element props to TUXNavBarTextButton
- feat: add 'onClear' prop to TUXTextInput

## 0.6.13

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/123801

- fix: fix TUXPinField numeric keyboard on mobile device
- feat: add 'onDisabledClick' prop for TUXButton

## 0.6.12

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/118147

- fix: safari < 14 crashing when detecting user color scheme preference

## 0.6.11

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/117065

- feat: allow accordions to be limited to just one open item

## 0.6.10

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/117339

- fix: clear inputs on TUXSearchableSelect when focused

## 0.6.9

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/117339

- fix: broken styles for TUXSearchableSelect

## 0.6.8

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/116812

- feat: add description and labelPosition prop to TUXCheckbox, TUXRadio and TUXSwitch
- TUXSwitch size prop now takes small and medium (not large), this is a breaking change

## 0.6.7

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/117063

- fix: stop className on TUXSheet from overwriting .TUXSheet class

## 0.6.6

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/115221

- feat: implement TUXDatePicker & TUXDateRangePicker

## 0.6.5

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/115219

- feat: add tux-web cjs configuration

## 0.6.4

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/114315

- feat: add TUXChip, TUXMultiSelectChip

## 0.6.3

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/115651

- fix: TUXNavBar class conflicts with tux-h5

## 0.6.2

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/115446

- fix: TUXNavBar background

## 0.6.1

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/114886

- fix: TUXAutocomplete suggestions not showing when input is empty

## 0.6.0

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/114334

- feat: add TUXColorScheme component to set color scheme locally
- feat: add createTUXRootAttributes to set global color and text direction for your app
  - This is a breaking change, server-rendered apps will now need to use this to avoid a flash of incorrectly styled content.

## 0.5.3

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/113880

- fix: TUXAutocomplete openable even when disabled

## 0.5.2

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/113567

- fix: focus rings visible sometimes when opening TUXModal and TUXSheet

## 0.5.1

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/113313

- feat: add 'autoComplete' prop for TUXTextInput
- fix: TUXTextInput and TUXTextArea showing an error when at the character limit, instead of only when above it

## 0.5.0

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/111064

- feat: add TUXModalCloseButton, TUXModalTitle, TUXModalNavBar
- removed 'title' prop from TUXModal, this is a breaking change

## 0.4.16

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/112765

- fix: remove an unneeded console.log

## 0.4.15

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/112534

- feat: add TUXPasswordInput

## 0.4.14

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/112229

- fix: TUXPinField 'backspace' behavior and onComplete disabled state
- fix: TUXloading not working on safari

## 0.4.13

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/111993

- feat: add 'compact' prop to TUXTabBar

## 0.4.12

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/111617

- fix: searchable select clear button, z-index and arrow

## 0.4.11

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/111591

- fix: checkbox/radio alignment and improve getting started docs

## 0.4.10

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/111526

- feat: implement TUXSearchableSelect

## 0.4.9

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/110694

- feat: add TUXSegmentedControl

## 0.4.8

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/111276

- chore: re-enable TUXAutocomplete

## 0.4.7

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/110685

- fix: fix UnstyledButton focus ring
- fix: fix TUXTooltip semi-transparent background-color to solid
- fix: fix TUXTextInput placeholder color, not selectable problem in iOS

## 0.4.6

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/110244/changes

- feat: add fontFamily to tailwindTheme
- fontFamily can be set to 'display' or 'body'

## 0.4.5

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/110257

- fix: remove TUXRadio hovering effect

## 0.4.4

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/110249

- fix: clear button for TUXTextInput not working in Safari

## 0.4.3

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/103775

- feat: add TUXListView

## 0.4.2

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/109751

- feat: add TUXAutocomplete

## 0.4.1

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/109632

- feat: add TUXPinField

## 0.4.0

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/109767

- feat: add TUXSheetCloseButton, TUXSheetTitle, TUXSheetNavBar
- removed 'title' prop from TUXSheet, this is a breaking change

## 0.3.9

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/109644

- fix: add TUXStyleProps to TUXProvider and TUXTextDirection

## 0.3.8

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/108354

- fix: various issues with TUXTextArea

## 0.3.7

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/108153

- feat: add rest props to all components

## 0.3.6

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/108152

- fix: bottom toasts are blocking clicks to the underlying page

## 0.3.5

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/108139

- add preventCloseOnClick prop to TUXMenuItem

## 0.3.4

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/107900

- add TUXCheckboxStandalone, TUXRadioStandalone
- use these standalone components if the layout offered by TUXCheckbox and TUXRadio isn't sufficient

## 0.3.3

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/107389

- add TUXFloatingNotice component

## 0.3.2

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/106680

- add topToastOffset and bottomToastOffset props to TUXProvider, used for manual adjustment of toast position if necessary

## v0.3.1

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/106654

- add optional safeAreaInsetTop prop to TUXProvider, used to manually avoid the camera notch or phone status bar if automatic detection fails

## v0.3.0

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/105966

- add spacing and font size, weight tokens for tailwind
- this is a breaking change from v0.2.9; tailwindColors is no longer exported, in favor of tailwindTheme

## v0.2.9

https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/105747

- add tailwindColors export
- TUXLink can be styled with more colors

## v0.2.8

- fix opening select causing page to jump to top (https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/105084)

## v0.2.7

- implement TUXPopover & TUXMenu (https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/104463)

## v0.2.6

- fix trailingArrow shrink issue on TUXAccordion (https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/103908)

## v0.2.5

- add TUXAccordion (https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/103860)

## v0.2.4

- standardize TUXStyleProps to className & style (https://code.byted.org/ies/tiktok_web_monorepo/merge_requests/102484)

## v0.0.1

- v0.0.1 is released.
